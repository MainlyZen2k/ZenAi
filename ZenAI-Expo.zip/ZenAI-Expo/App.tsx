import { StatusBar } from 'expo-status-bar';
import { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  BackHandler,
  Linking,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { WebView } from 'react-native-webview';

/**
 * Zen AI — Android wrapper (Expo)
 * --------------------------------
 * This shell loads the Zen AI web app. Deploy the web app (see the setup
 * guide §2) and paste its URL below. Everything — chat, terminal, sandbox,
 * themes — runs inside the WebView; the wrapper adds native feel:
 * splash, offline screen, Android back button, pull-to-refresh.
 */

// Deployed Zen AI web app URL (GitHub Pages — set by the workflow):
const ZEN_WEB_URL = 'https://mainlyzen2k.github.io/ZenAi';

// Already configured:
const CONFIGURED = true;

export default function App() {
  const webRef = useRef<WebView>(null);
  const [canGoBack, setCanGoBack] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [offline, setOffline] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);

  // Android hardware back button: navigate back in the app, don't exit
  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (canGoBack) {
        webRef.current?.goBack();
        return true;
      }
      return false;
    });
    return () => sub.remove();
  }, [canGoBack]);

  if (!CONFIGURED) {
    return (
      <SafeAreaProvider>
        <View style={s.center}>
          <Text style={s.logo}>Zen AI</Text>
          <Text style={s.title}>One step left</Text>
          <Text style={s.body}>
            Open App.tsx and set ZEN_WEB_URL to your deployed Zen AI web app
            address, then rebuild the APK.
          </Text>
          <Text style={s.body}>Full walkthrough: Zen AI Setup Guide, sections 2 & 8.</Text>
        </View>
      </SafeAreaProvider>
    );
  }

  if (offline) {
    return (
      <SafeAreaProvider>
        <View style={s.center}>
          <Text style={s.logo}>Zen AI</Text>
          <Text style={s.title}>You're offline</Text>
          <Text style={s.body}>
            Zen needs the internet to load the app shell the first time.
            Check your connection and try again.
          </Text>
          <TouchableOpacity style={s.button} onPress={() => { setOffline(false); setReloadKey((k) => k + 1); }}>
            <Text style={s.buttonText}>Retry</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaProvider>
    );
  }

  return (
    <SafeAreaProvider>
      <View style={s.root}>
        <StatusBar style="light" backgroundColor="#0b0d14" />
        <WebView
          key={reloadKey}
          ref={webRef}
          source={{ uri: ZEN_WEB_URL }}
          style={s.web}
          onLoadEnd={(e) => {
            setLoaded(true);
            setCanGoBack(e.nativeEvent.canGoBack ?? false);
          }}
          onNavigationStateChange={(state) => setCanGoBack(state.canGoBack)}
          onError={() => setOffline(true)}
          onRenderProcessGone={() => { setReloadKey((k) => k + 1); }}
          pullToRefreshEnabled
          allowsBackForwardNavigationGestures
          javaScriptEnabled
          domStorageEnabled
          originWhitelist={['*']}
          setSupportMultipleWindows={false}
          // allow file inputs (attachments) on Android
          allowFileAccess
          allowUniversalAccessFromFileURLs={false}
          // keep media playing when the app is backgrounded
          mediaPlaybackRequiresUserAction={false}
        />
        {!loaded && (
          <View style={s.splash}>
            <Text style={s.logo}>Zen AI</Text>
            <ActivityIndicator color="#8b5cf6" />
          </View>
        )}
      </View>
    </SafeAreaProvider>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#0b0d14' },
  web: { flex: 1, backgroundColor: '#0b0d14' },
  center: {
    flex: 1,
    backgroundColor: '#0b0d14',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 32,
    gap: 12,
  },
  splash: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: '#0b0d14',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 16,
  },
  logo: {
    color: '#8b5cf6',
    fontSize: 42,
    fontWeight: '800',
    letterSpacing: 1,
    marginBottom: 4,
  },
  title: { color: '#ffffff', fontSize: 20, fontWeight: '700' },
  body: { color: 'rgba(255,255,255,0.55)', fontSize: 14, textAlign: 'center', lineHeight: 21 },
  button: {
    backgroundColor: '#8b5cf6',
    paddingHorizontal: 28,
    paddingVertical: 12,
    borderRadius: 14,
    marginTop: 12,
  },
  buttonText: { color: '#fff', fontWeight: '700', fontSize: 15 },
});
