# Zen AI — Android wrapper (Expo)

This folder is the **Expo project** that turns your deployed Zen AI web app into
an installable APK. The brain, chat, terminal, sandbox and themes all live in
the web app — this shell wraps it natively.

## Before you build (2 edits)

Open `App.tsx` and:

1. Set `ZEN_WEB_URL` to your deployed Zen AI web app address (your Vercel URL).
2. Flip `CONFIGURED` from `false` to `true`.

The APK is just a wrapper — if the web app isn't deployed yet, do that first.

## Build the APK on GitHub Actions (recommended — no PC, no Expo account)

The workflow is included at `.github/workflows/build-apk.yml`. Once this folder
is pushed to GitHub, GitHub builds the APK for you automatically.

1. Make sure the repo contains this file: `.github/workflows/build-apk.yml`.
2. Push to `main` (or open **Actions → Build Zen AI APK → Run workflow**).
3. Wait ~15 minutes, click the finished run, scroll to **Artifacts**,
   download **Zen-AI-APK**, unzip, and install `Zen-AI.apk` on any Android
   phone (allow "install unknown apps" for sideloading).

Every new push rebuilds the APK, and the same signing key is reused between
builds, so updates install right over the old version.

Free tier notes: public repos build free; private repos get 2,000 free
Actions minutes per month (one build ≈ 15–20 min).

## Build with EAS instead (needs a free Expo account)

```bash
npm install
npx expo login        # create a free account at expo.dev first
npx eas build -p android --profile apk
```

Download the APK from the link EAS prints when the build finishes.

## Build locally instead (needs Android Studio + JDK 17)

```bash
npm install
npx expo prebuild -p android   # generates the android/ folder
cd android
./gradlew assembleRelease
# APK lands in android/app/build/outputs/apk/release/app-release.apk
```

## Files

- `App.tsx` — the native shell (splash, offline screen, back button, WebView)
- `app.json` — app name, package id `com.zenai.app`, icon, splash
- `eas.json` — build profiles (`apk` profile produces a sideloadable APK)
- `.github/workflows/build-apk.yml` — GitHub Actions APK build
- `assets/` — generated Zen icons (enso + Z, purple)

## Change the icon color later

Regenerate `assets/*.png` with any purple → your color, or edit them in any
image editor. The design (enso circle + Z) stays.
