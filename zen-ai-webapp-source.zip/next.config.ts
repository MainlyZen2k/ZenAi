import type { NextConfig } from "next";

// Zen AI ships as a pure static site (output: "export") so it can be hosted
// free on GitHub Pages: https://<user>.github.io/<repo>/
// NEXT_PUBLIC_BASE_PATH is set by the deploy workflow to "/<repo-name>" so
// every asset lands under the right sub-path. Leave it unset for local dev.
const basePath = process.env.NEXT_PUBLIC_BASE_PATH || "";

const nextConfig: NextConfig = {
  output: "export",
  basePath: basePath || undefined,
  images: { unoptimized: true },
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
};

export default nextConfig;
