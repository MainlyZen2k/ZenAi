import type { Metadata, Viewport } from "next";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

export const metadata: Metadata = {
  title: "Zen AI — Your On-Device AI",
  description:
    "Zen AI: a custom AI assistant with 3 minds (Mini, Think, Pro), a real terminal, code sandbox, live season themes and full on-device privacy.",
  keywords: ["Zen AI", "AI assistant", "on-device AI", "WebLLM", "chatbot"],
  authors: [{ name: "Zen AI" }],
  icons: {
    icon: "/zen-logo.svg",
  },
  openGraph: {
    title: "Zen AI",
    description: "Three minds. Real tools. Runs on your device.",
    type: "website",
  },
};

export const viewport: Viewport = {
  themeColor: "#0b0d14",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="antialiased bg-[#0b0d14] text-foreground">
        {children}
        <Toaster />
      </body>
    </html>
  );
}
