'use client';

import { ZenApp } from '@/components/zen/ZenApp';

export default function Home() {
  return <ZenApp />;
}
