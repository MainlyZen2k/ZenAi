'use client';

// Admin panel — list users, ban/unban with reason, promote, grant tokens.
// Live mode = real Firestore ops. Demo mode shows what it will look like.

import { useEffect, useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { Users, RefreshCw, Ban, CheckCircle2, Coins, ShieldCheck, Loader2 } from 'lucide-react';
import { useZen } from '@/lib/zen/store';
import { SEASONS } from '@/lib/zen/themes';
import { listUsers, setUserStatus, setUserRole, grantTokens, findUserByEmail, type AdminUserRow } from '@/lib/zen/firebase';

export function AdminPanel() {
  const [rows, setRows] = useState<AdminUserRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [banReason, setBanReason] = useState('');
  const [banTarget, setBanTarget] = useState<AdminUserRow | null>(null);
  const { toast } = useToast();
  const fbMode = useZen((s) => s.fbMode);
  const accent = useZen((s) => s.settings.accent) || '#8b5cf6';
  const season = useZen((s) => s.season);
  const info = SEASONS[season] || SEASONS.default;

  const refresh = async () => {
    if (fbMode !== 'live') return;
    setLoading(true);
    try {
      const u = await listUsers();
      setRows(u);
    } catch (e: any) {
      toast({ title: 'Could not list users', description: e?.message || 'Check Firestore rules + indexes.', variant: 'destructive' });
    }
    setLoading(false);
  };

  useEffect(() => {
    if (fbMode !== 'live') return;
    const t = setTimeout(() => {
      refresh();
    }, 0);
    return () => clearTimeout(t);
  }, [fbMode]);

  const filtered = rows.filter(
    (r) => !search || r.email.toLowerCase().includes(search.toLowerCase()) || r.name.toLowerCase().includes(search.toLowerCase())
  );

  const act = async (fn: () => Promise<void>, okMsg: string) => {
    try {
      await fn();
      toast({ title: okMsg });
      await refresh();
    } catch (e: any) {
      toast({ title: 'Action failed', description: e?.message || 'permission denied? Check firestore.rules', variant: 'destructive' });
    }
  };

  return (
    <Dialog open onOpenChange={(o) => !o && useZen.getState().setPanel(null)}>
      <DialogContent className="max-w-2xl max-h-[86dvh] bg-black/85 border-white/15 backdrop-blur-2xl text-white overflow-hidden p-0">
        <DialogHeader className="px-6 pt-5 pb-0">
          <DialogTitle className="flex items-center gap-2">
            <Users className="w-5 h-5" style={{ color: accent }} /> Zen Admin Panel
          </DialogTitle>
          <DialogDescription className="text-white/40 text-xs">
            Users, bans, roles and token grants — backed by Firestore in cloud mode.
          </DialogDescription>
        </DialogHeader>

        <div className="px-6 py-4 space-y-3 overflow-y-auto zen-scroll" style={{ maxHeight: 'calc(86dvh - 150px)' }}>
          {fbMode !== 'live' ? (
            <div className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-4 text-sm text-amber-200/80">
              <p className="font-medium mb-1">Demo view</p>
              <p className="text-[13px] leading-relaxed">
                Connect Firebase (Settings → Firebase) and sign in with an admin account to manage real users.
                Bans, roles and grants become live Firestore writes enforced by the security rules in the setup guide.
              </p>
            </div>
          ) : (
            <>
              <div className="flex gap-2">
                <Input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search by email or name…"
                  className="bg-white/5 border-white/10 text-white placeholder:text-white/30"
                />
                <Button variant="outline" size="icon" onClick={refresh} className="border-white/15 bg-white/5" aria-label="Refresh user list">
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
                </Button>
              </div>

              <div className="rounded-xl border border-white/10 divide-y divide-white/5">
                {filtered.length === 0 && <p className="p-4 text-sm text-white/35">{loading ? 'Loading…' : 'No users yet. Signups will appear here.'}</p>}
                {filtered.map((u) => (
                  <div key={u.uid} className="flex items-center gap-2 px-3 py-2.5">
                    <div className="flex-1 min-w-0">
                      <div className="text-sm text-white/85 truncate flex items-center gap-1.5">
                        {u.email}
                        {u.role === 'admin' && <ShieldCheck className="w-3.5 h-3.5 shrink-0" style={{ color: accent }} />}
                      </div>
                      <div className="text-[11px] text-white/40 truncate">
                        {u.status === 'banned' ? `⛔ banned — ${u.banReason || 'no reason'}` : '✅ active'} · {u.role}
                      </div>
                    </div>
                    <div className="flex gap-1 shrink-0">
                      {u.status === 'active' ? (
                        <Button size="sm" variant="ghost" className="h-8 text-red-300/80 hover:text-red-300 hover:bg-red-500/10" onClick={() => { setBanTarget(u); setBanReason(''); }}>
                          <Ban className="w-3.5 h-3.5" />
                        </Button>
                      ) : (
                        <Button size="sm" variant="ghost" className="h-8 text-emerald-300/80 hover:text-emerald-300" onClick={() => act(() => setUserStatus(u.uid, 'active'), `${u.email} unbanned`)}>
                          <CheckCircle2 className="w-3.5 h-3.5" />
                        </Button>
                      )}
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-8 text-white/50 hover:text-white"
                        title={u.role === 'admin' ? 'Demote to user' : 'Promote to admin'}
                        onClick={() => act(() => setUserRole(u.uid, u.role === 'admin' ? 'user' : 'admin'), `${u.email} → ${u.role === 'admin' ? 'user' : 'admin'}`)}
                      >
                        <ShieldCheck className="w-3.5 h-3.5" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-8 text-amber-300/70 hover:text-amber-300"
                        title="Grant 1000 tokens"
                        onClick={() => act(() => grantTokens(u.uid, 1000), `+1000 tokens → ${u.email}`)}
                      >
                        <Coins className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
              <p className="text-[11px] text-white/30">
                Banning flips users/{'{uid}'}.status → the app blocks banned users on next login/login check. Login logs live in the loginLogs collection (one doc per session).
              </p>
            </>
          )}
        </div>

        {banTarget && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/70 p-4" onClick={() => setBanTarget(null)}>
            <div className="rounded-2xl border border-white/15 bg-black/90 p-5 w-full max-w-sm space-y-3" onClick={(e) => e.stopPropagation()}>
              <h3 className="font-semibold text-white">Ban {banTarget.email}?</h3>
              <Input
                value={banReason}
                onChange={(e) => setBanReason(e.target.value)}
                placeholder="Reason (shown to the user)"
                className="bg-white/5 border-white/10 text-white placeholder:text-white/30"
                autoFocus
              />
              <div className="flex justify-end gap-2">
                <Button variant="ghost" onClick={() => setBanTarget(null)} className="text-white/60">Cancel</Button>
                <Button
                  className="bg-red-500 hover:bg-red-400"
                  onClick={() => {
                    act(async () => {
                      await setUserStatus(banTarget.uid, 'banned', banReason || 'Violation of the Zen rules');
                      setBanTarget(null);
                    }, `${banTarget.email} banned`);
                    setBanTarget(null);
                  }}
                >
                  Ban user
                </Button>
              </div>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
