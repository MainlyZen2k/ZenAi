'use client';

// Auth: Email + Google via Firebase, plus a Local Demo mode so the app works
// before Firebase is configured. Firebase config is entered once and stored.

import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import {
  Mail, Lock, User as UserIcon, Chrome, CloudOff, Cloud, ChevronDown, Loader2, KeyRound,
} from 'lucide-react';
import { ZenLogo } from './ZenLogo';
import { useZen } from '@/lib/zen/store';
import { SEASONS } from '@/lib/zen/themes';
import {
  initFirebase, emailSignIn, emailSignUp, googleSignIn, prettyFBError, hasConfigLive, ADMIN_EMAILS,
} from '@/lib/zen/firebase';
import type { FBConfig } from '@/lib/zen/types';

const CFG_KEY = 'zen-fb-config';

const EMPTY_CFG: FBConfig = {
  apiKey: '',
  authDomain: '',
  projectId: '',
  storageBucket: '',
  messagingSenderId: '',
  appId: '',
};

export function AuthScreen() {
  const [tab, setTab] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [showCfg, setShowCfg] = useState(false);
  const [cfg, setCfg] = useState<FBConfig>(EMPTY_CFG);
  const [hasCfg, setHasCfg] = useState(false);
  const { toast } = useToast();
  const season = useZen((s) => s.season);
  const signInDemo = useZen((s) => s.signInDemo);
  const fbMode = useZen((s) => s.fbMode);
  const accent = useZen((s) => s.settings.accent);

  useEffect(() => {
    const saved = localStorage.getItem(CFG_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved) as FBConfig;
        setCfg(parsed);
        setHasCfg(Boolean(parsed.apiKey && parsed.projectId));
        initFirebase(parsed);
      } catch {
        /* ignore */
      }
    }
  }, []);

  const saveCfg = () => {
    if (!cfg.apiKey || !cfg.projectId || !cfg.appId) {
      setError('apiKey, projectId and appId are the minimum required fields.');
      return;
    }
    localStorage.setItem(CFG_KEY, JSON.stringify(cfg));
    const ok = initFirebase(cfg);
    setHasCfg(ok);
    setError(ok ? '' : 'Init failed — check the values again.');
    if (ok) toast({ title: 'Firebase connected', description: 'Cloud mode active. Now sign in or create an account.' });
  };

  const runAuth = async (fn: () => Promise<void>) => {
    setBusy(true);
    setError('');
    try {
      await fn();
    } catch (err: any) {
      setError(prettyFBError(err?.code || err?.message || 'unknown error'));
    } finally {
      setBusy(false);
    }
  };

  const info = SEASONS[season] || SEASONS.default;

  return (
    <div className="min-h-dvh flex items-center justify-center p-4 relative">
      <div className="w-full max-w-md relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: 'easeOut' }}
          className="rounded-3xl border border-white/10 bg-black/40 backdrop-blur-2xl p-7 shadow-2xl"
          style={{ boxShadow: `0 20px 80px -20px ${info.glow}55` }}
        >
          <div className="flex flex-col items-center text-center gap-3">
            <motion.div
              animate={{ rotate: [0, -6, 6, 0], scale: [1, 1.06, 1] }}
              transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut' }}
            >
              <ZenLogo size={72} accent={accent || info.accent} />
            </motion.div>
            <div>
              <h1 className="text-3xl font-bold tracking-tight text-white">Zen AI</h1>
              <p className="text-sm text-white/50 mt-1">
                {info.emoji} {info.label} · On-device · No cloud brain required
              </p>
            </div>
          </div>

          <div className="flex gap-1 mt-6 p-1 rounded-xl bg-white/5 border border-white/10">
            {(['signin', 'signup'] as const).map((t) => (
              <button
                key={t}
                onClick={() => { setTab(t); setError(''); }}
                className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${
                  tab === t ? 'bg-white/15 text-white shadow' : 'text-white/50 hover:text-white'
                }`}
              >
                {t === 'signin' ? 'Sign in' : 'Create account'}
              </button>
            ))}
          </div>

          <div className="mt-5 space-y-3">
            {tab === 'signup' && (
              <div className="relative">
                <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
                <Input
                  placeholder="Display name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="pl-9 bg-white/5 border-white/10 text-white placeholder:text-white/30"
                />
              </div>
            )}
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
              <Input
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="pl-9 bg-white/5 border-white/10 text-white placeholder:text-white/30"
              />
            </div>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
              <Input
                type="password"
                placeholder="Password (6+ characters)"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    if (tab === 'signin') runAuth(() => emailSignIn(email, password));
                    else runAuth(() => emailSignUp(email, password, name || 'Zen User'));
                  }
                }}
                className="pl-9 bg-white/5 border-white/10 text-white placeholder:text-white/30"
              />
            </div>

            {error && <p className="text-sm text-red-400 bg-red-500/10 rounded-lg px-3 py-2">{error}</p>}

            <Button
              disabled={busy || !hasConfigLive()}
              onClick={() => {
                if (tab === 'signin') runAuth(() => emailSignIn(email, password));
                else runAuth(() => emailSignUp(email, password, name || 'Zen User'));
              }}
              className="w-full h-11 font-semibold"
              style={{ background: `linear-gradient(135deg, ${info.accent}, ${info.glow})` }}
            >
              {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : tab === 'signin' ? 'Sign in' : 'Create account'}
            </Button>

            <div className="flex items-center gap-3 py-1">
              <Separator className="flex-1 bg-white/10" />
              <span className="text-xs text-white/30">or</span>
              <Separator className="flex-1 bg-white/10" />
            </div>

            <Button
              variant="outline"
              disabled={busy || !hasConfigLive()}
              onClick={() => runAuth(googleSignIn)}
              className="w-full h-11 bg-white/5 border-white/10 text-white hover:bg-white/10"
            >
              <Chrome className="w-4 h-4 mr-2" /> Continue with Google
            </Button>

            <Button
              variant="ghost"
              onClick={() => { signInDemo(); toast({ title: 'Local mode', description: 'Everything stays on this device. Connect Firebase anytime in Settings.' }); }}
              className="w-full h-11 text-white/60 hover:text-white hover:bg-white/5"
            >
              <CloudOff className="w-4 h-4 mr-2" /> Use Local Mode (no cloud)
            </Button>
          </div>

          <button
            onClick={() => setShowCfg((v) => !v)}
            className="mt-5 w-full flex items-center justify-center gap-1.5 text-xs text-white/40 hover:text-white/70 transition-colors"
          >
            <KeyRound className="w-3.5 h-3.5" />
            {hasCfg ? 'Firebase connected — tap to edit config' : 'Connect Firebase (paste your config)'}
            <ChevronDown className={`w-3.5 h-3.5 transition-transform ${showCfg ? 'rotate-180' : ''}`} />
          </button>

          {showCfg && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              className="overflow-hidden"
            >
              <div className="mt-3 space-y-2 rounded-xl border border-white/10 bg-white/5 p-3">
                <p className="text-xs text-white/40 leading-relaxed">
                  From <span className="text-white/70">Firebase console → Project settings → Your apps → Web app → Config</span>. See the setup guide for the 2-minute walkthrough.
                </p>
                {(Object.keys(EMPTY_CFG) as (keyof FBConfig)[]).map((k) => (
                  <div key={k} className="space-y-1">
                    <Label className="text-[10px] uppercase tracking-wide text-white/40">{k}</Label>
                    <Input
                      value={cfg[k]}
                      onChange={(e) => setCfg({ ...cfg, [k]: e.target.value })}
                      className="h-8 text-xs bg-black/30 border-white/10 text-white"
                      placeholder={k === 'authDomain' ? 'your-app.firebaseapp.com' : ''}
                    />
                  </div>
                ))}
                <Button size="sm" onClick={saveCfg} className="w-full">Save & connect</Button>
                <p className="text-[10px] text-white/30">
                  Admin tip: add your email to ADMIN_EMAILS in <code>src/lib/zen/firebase.ts</code> to auto-promote yourself.
                </p>
              </div>
            </motion.div>
          )}

          <div className="mt-4 flex items-center justify-center gap-1.5 text-[11px] text-white/30">
            {fbMode === 'live' || hasConfigLive() ? (
              <><Cloud className="w-3 h-3" /> Firebase ready</>
            ) : (
              <><CloudOff className="w-3 h-3" /> No Firebase — Local Mode available</>
            )}
          </div>
        </motion.div>

        <p className="text-center text-[11px] text-white/25 mt-4">
          Zen AI runs its brain on your device. Your chats never leave without your say-so.
        </p>
      </div>
    </div>
  );
}
