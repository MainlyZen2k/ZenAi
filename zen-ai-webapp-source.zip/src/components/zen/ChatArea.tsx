'use client';

// Main chat area: greeting screen (quotes + suggestions) or message list.

import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { RotateCcw, Quote as QuoteIcon, Terminal } from 'lucide-react';
import { useZen } from '@/lib/zen/store';
import { greeting } from '@/lib/zen/quotes';
import { SEASONS } from '@/lib/zen/themes';
import { MessageBubble } from './MessageBubble';
import { ZenLogo } from './ZenLogo';

export function ChatArea() {
  const chats = useZen((s) => s.chats);
  const activeChatId = useZen((s) => s.activeChatId);
  const user = useZen((s) => s.user);
  const season = useZen((s) => s.season);
  lastQuoteNonce();
  const chat = chats.find((c) => c.id === activeChatId);
  const bottomRef = useRef<HTMLDivElement>(null);
  const info = SEASONS[season] || SEASONS.default;
  const accent = useZen((s) => s.settings.accent) || info.accent;
  const [greet, setGreet] = useState('');

  useEffect(() => {
    setGreet(greeting(user?.name?.split(' ')[0] || 'friend'));
  }, [user?.name]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chat?.msgs.length, chat?.msgs[chat.msgs.length - 1]?.content]);

  const lastAssistantIdx = chat ? [...chat.msgs].reverse().findIndex((m) => m.role === 'assistant') : -1;
  const regenerateIdx = lastAssistantIdx >= 0 ? chat!.msgs.length - 1 - lastAssistantIdx : -1;

  const regenerate = () => {
    if (!chat || regenerateIdx < 0) return;
    const prevUser = [...chat.msgs.slice(0, regenerateIdx)].reverse().find((m) => m.role === 'user');
    if (!prevUser) return;
    // remove the last assistant msg, resend
    useZen.setState((s) => ({
      chats: s.chats.map((c) =>
        c.id === chat.id
          ? { ...c, msgs: c.msgs.filter((m, i) => !(i === regenerateIdx && m.role === 'assistant')) }
          : c
      ),
      generating: false,
    }));
    useZen.getState().send(prevUser.content, prevUser.attachments);
  };

  if (!chat) {
    return (
      <div className="flex-1 flex items-center justify-center p-6">
        <p className="text-white/40 text-sm">Open a chat from the sidebar or create a new one.</p>
      </div>
    );
  }

  if (chat.msgs.length === 0) {
    const quote = useZen.getState().lastQuote;
    return (
      <div className="flex-1 flex items-center justify-center p-6 overflow-y-auto zen-scroll">
        <div className="max-w-lg w-full text-center space-y-5">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: 'spring', damping: 15 }}
            className="mx-auto w-fit"
          >
            <ZenLogo size={84} accent={accent} />
          </motion.div>
          <div>
            <h1 className="text-2xl font-bold text-white">{greet}</h1>
            <p className="text-white/40 text-sm mt-1">{info.emoji} {info.label} · everything runs on this device</p>
          </div>

          {quote && (
            <motion.div
              key={quote.text}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="rounded-2xl border border-white/10 bg-white/5 backdrop-blur p-5 relative"
            >
              <QuoteIcon className="w-4 h-4 absolute left-3 top-3" style={{ color: accent }} />
              <p className={`text-[15px] leading-relaxed ${quote.tone === 'deep' ? 'text-white/80 italic' : 'text-white/70'}`}>
                “{quote.text}”
              </p>
              <button
                onClick={() => useZen.getState().rerollQuote()}
                className="mt-3 inline-flex items-center gap-1 text-[11px] text-white/40 hover:text-white/80 transition-colors"
              >
                <RotateCcw className="w-3 h-3" /> another one
              </button>
            </motion.div>
          )}

          <div className="flex flex-wrap justify-center gap-2">
            {[
              { label: '🐍 Create a snake game', text: 'create a snake game in html' },
              { label: '🔥 Who won the latest Super Bowl?', text: 'who is the current US president?' },
              { label: '🌌 Explain black holes', text: 'explain black holes' },
              { label: '🎲 Run Python', text: 'create a python password generator' },
            ].map((s) => (
              <button
                key={s.label}
                onClick={() => useZen.getState().send(s.text)}
                className="rounded-full border border-white/15 bg-white/5 px-3.5 py-2 text-xs text-white/70 hover:bg-white/10 hover:text-white hover:border-white/30 transition-all"
              >
                {s.label}
              </button>
            ))}
          </div>

          <button
            onClick={() => useZen.getState().setPanel('terminal')}
            className="inline-flex items-center gap-1.5 text-[11px] text-white/30 hover:text-white/60 transition-colors"
          >
            <Terminal className="w-3 h-3" /> power users: open the AI terminal
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto zen-scroll px-4 py-5 space-y-4">
      <AnimatePresence initial={false}>
        {chat.msgs.map((m, i) => (
          <MessageBubble
            key={m.id}
            msg={m}
            onRegenerate={i === regenerateIdx ? regenerate : undefined}
          />
        ))}
      </AnimatePresence>
      <div ref={bottomRef} />
    </div>
  );
}

// Avoid SSR/CSR mismatch for the random greeting + quote ordering.
function lastQuoteNonce() {}
