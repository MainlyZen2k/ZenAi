'use client';

// Composer: input, attachments, model selector pills, send/stop, token cost.

import { useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Paperclip, Send, Square, Sparkles, BrainCircuit, Hammer, Coins } from 'lucide-react';
import { useZen, TOKEN_COSTS } from '@/lib/zen/store';
import type { ModelMode } from '@/lib/zen/types';
import { readTextFile } from './fileUtils';

const MODES: { id: ModelMode; label: string; icon: typeof Sparkles; hint: string }[] = [
  { id: 'mini', label: 'Mini', icon: Sparkles, hint: 'Quick answers · 1 token' },
  { id: 'think', label: 'Think', icon: BrainCircuit, hint: 'Reasons it through · 4 tokens' },
  { id: 'pro', label: 'Pro', icon: Hammer, hint: 'Tools + self-checks · 10 tokens' },
];

export function Composer() {
  const [text, setText] = useState('');
  const [attachments, setAttachments] = useState<{ name: string; type: string; size: number; dataUrl?: string; text?: string }[]>([]);
  const taRef = useRef<HTMLTextAreaElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const chats = useZen((s) => s.chats);
  const activeChatId = useZen((s) => s.activeChatId);
  const generating = useZen((s) => s.generating);
  const tokens = useZen((s) => s.tokens);
  const cloudReady = useZen((s) => s.settings.cloud.enabled && !!s.settings.cloud.apiKey.trim());
  const season = useZen((s) => s.season);
  const accent = useZen((s) => s.settings.accent) || '#8b5cf6';
  const chat = chats.find((c) => c.id === activeChatId);
  const mode = chat?.mode || 'mini';
  const send = useZen((s) => s.send);
  const stop = useZen((s) => s.stop);
  const setChatMode = useZen((s) => s.setChatMode);

  const doSend = async () => {
    const value = text.trim();
    const atts = attachments;
    if (!value && atts.length === 0) return;
    setText('');
    setAttachments([]);
    if (taRef.current) taRef.current.style.height = 'auto';
    await send(value, atts);
  };

  const onFiles = async (files: FileList | null) => {
    if (!files) return;
    const next = [...attachments];
    for (const f of Array.from(files).slice(0, 5)) {
      if (f.size > 8 * 1024 * 1024) {
        toast({ title: `${f.name} is too big (max 8MB)`, variant: 'destructive' });
        continue;
      }
      const isImage = f.type.startsWith('image/');
      if (isImage) {
        const dataUrl = await new Promise<string>((res) => {
          const r = new FileReader();
          r.onload = () => res(String(r.result));
          r.readAsDataURL(f);
        });
        next.push({ name: f.name, type: f.type, size: f.size, dataUrl });
      } else {
        const txt = await readTextFile(f);
        next.push({ name: f.name, type: f.type || 'text/plain', size: f.size, text: txt });
      }
    }
    setAttachments(next);
    if (fileRef.current) fileRef.current.value = '';
  };

  return (
    <div className="px-3 pb-4 pt-1 shrink-0">
      {/* attachments preview */}
      {attachments.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-2">
          {attachments.map((a, i) => (
            <span key={i} className="inline-flex items-center gap-1.5 rounded-lg bg-white/10 border border-white/15 px-2.5 py-1 text-[11px] text-white/70">
              {a.name.slice(0, 24)}
              <button
                onClick={() => setAttachments(attachments.filter((_, j) => j !== i))}
                className="text-white/40 hover:text-red-400"
                aria-label={`Remove ${a.name}`}
              >
                ×
              </button>
            </span>
          ))}
        </div>
      )}

      {/* mode pills */}
      <div className="flex items-center gap-1.5 mb-2 overflow-x-auto zen-scroll-hidden">
        {MODES.map((m) => (
          <button
            key={m.id}
            title={m.hint}
            onClick={() => activeChatId && setChatMode(activeChatId, m.id)}
            className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium border transition-all shrink-0 ${
              mode === m.id
                ? 'border-transparent text-white shadow-lg'
                : 'border-white/15 text-white/50 hover:text-white/80 bg-white/5'
            }`}
            style={mode === m.id ? { background: `linear-gradient(135deg, ${accent}, ${accent}88)` } : undefined}
          >
            <m.icon className="w-3.5 h-3.5" /> {m.label}
            <span className="text-[10px] opacity-60 hidden sm:inline">{m.hint.split('·')[0]}</span>
          </button>
        ))}
        <span className="ml-auto inline-flex items-center gap-1 text-[11px] text-white/35 shrink-0">
          <Coins className="w-3 h-3" /> {tokens.balance.toLocaleString()}
        </span>
      </div>

      {/* input row */}
      <div className="flex items-end gap-2 rounded-2xl border border-white/15 bg-black/40 backdrop-blur p-2 shadow-2xl">
        <input ref={fileRef} type="file" multiple hidden onChange={(e) => onFiles(e.target.files)} />
        <Button
          variant="ghost" size="icon"
          onClick={() => fileRef.current?.click()}
          className="h-10 w-10 shrink-0 text-white/50 hover:text-white hover:bg-white/10"
          aria-label="Attach files"
        >
          <Paperclip className="w-4 h-4" />
        </Button>
        <textarea
          ref={taRef}
          value={text}
          onChange={(e) => {
            setText(e.target.value);
            const el = e.target;
            el.style.height = 'auto';
            el.style.height = Math.min(140, el.scrollHeight) + 'px';
          }}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              doSend();
            }
          }}
          rows={1}
          placeholder={`Message Zen (${MODES.find((m) => m.id === mode)?.hint})…`}
          className="flex-1 resize-none bg-transparent text-sm text-white placeholder:text-white/30 outline-none py-2.5 max-h-[140px]"
          aria-label="Message Zen AI"
        />
        {generating ? (
          <Button
            size="icon"
            onClick={stop}
            className="h-10 w-10 shrink-0 bg-red-500/90 hover:bg-red-500 text-white rounded-xl"
            aria-label="Stop generating"
          >
            <Square className="w-4 h-4" />
          </Button>
        ) : (
          <motion.button
            whileTap={{ scale: 0.92 }}
            onClick={doSend}
            disabled={!text.trim() && attachments.length === 0}
            className="h-10 w-10 shrink-0 rounded-xl flex items-center justify-center text-white disabled:opacity-30 transition-opacity"
            style={{ background: `linear-gradient(135deg, ${accent}, ${accent}aa)` }}
            aria-label="Send message"
          >
            <Send className="w-4 h-4" />
          </motion.button>
        )}
      </div>
      <p className="text-[10px] text-white/25 mt-1.5 px-1">
        Enter to send · Shift+Enter for a new line · files up to 8MB ·{' '}
        {cloudReady
          ? 'cloud brain on — your API key never leaves this device'
          : 'offline brain — private and local, add a free API key in Settings → AI Engine for full power'}
      </p>
    </div>
  );
}
