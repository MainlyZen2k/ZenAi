'use client';

// Message bubble: markdown rendering, collapsible thinking trace, source
// chips, and per-code-block actions (copy / run / open in sandbox).

import { memo, useState, type ReactNode } from 'react';
import ReactMarkdown from 'react-markdown';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import {
  Copy, Play, FlaskConical, ChevronDown, Link2, RefreshCw, FileText, ImageIcon, Check,
} from 'lucide-react';
import { useZen } from '@/lib/zen/store';
import { runJavaScript, runPython, type ExecResult } from '@/lib/zen/executor';
import { ZenLogo } from './ZenLogo';
import type { Msg } from '@/lib/zen/types';

function CodeBlock({ lang, code }: { lang: string; code: string }) {
  const [runState, setRunState] = useState<ExecResult | null>(null);
  const [running, setRunning] = useState(false);
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();
  const setPanel = useZen((s) => s.setPanel);
  const setSandboxInput = useZen((s) => s.setSandboxInput);
  const accent = useZen((s) => s.settings.accent) || '#8b5cf6';

  const l = lang.toLowerCase();
  const canRun = l === 'javascript' || l === 'js' || l === 'python' || l === 'py';
  const canSandbox = l === 'html' || l === 'js' || l === 'javascript';

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      toast({ title: 'Copy failed', variant: 'destructive' });
    }
  };

  const run = async () => {
    setRunning(true);
    setRunState(null);
    const r = l === 'python' || l === 'py' ? await runPython(code) : await runJavaScript(code);
    setRunState(r);
    setRunning(false);
  };

  const openSandbox = () => {
    setSandboxInput({ tab: l === 'html' ? 'html' : 'js', code });
    setPanel('sandbox');
  };

  return (
    <div className="my-3 rounded-xl border border-white/10 bg-black/50 overflow-hidden">
      <div className="flex items-center justify-between px-3 py-1.5 bg-white/5 border-b border-white/10">
        <span className="text-[10px] font-mono uppercase tracking-wider text-white/40">{lang || 'code'}</span>
        <div className="flex items-center gap-1">
          {canRun && (
            <Button size="sm" variant="ghost" onClick={run} disabled={running} className="h-7 px-2 text-[11px] text-white/60 hover:text-white">
              {running ? <span className="animate-pulse">running…</span> : <><Play className="w-3 h-3 mr-1" /> Run</>}
            </Button>
          )}
          {canSandbox && (
            <Button size="sm" variant="ghost" onClick={openSandbox} className="h-7 px-2 text-[11px] text-white/60 hover:text-white">
              <FlaskConical className="w-3 h-3 mr-1" /> Sandbox
            </Button>
          )}
          <Button size="sm" variant="ghost" onClick={copy} className="h-7 px-2 text-[11px] text-white/60 hover:text-white">
            {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
          </Button>
        </div>
      </div>
      <pre className="overflow-x-auto p-3 text-[12px] leading-relaxed max-h-96 zen-scroll">
        <code className="font-mono text-white/90 whitespace-pre">{code}</code>
      </pre>
      {runState && (
        <div className={`px-3 py-2 border-t text-[11px] font-mono whitespace-pre-wrap ${runState.ok ? 'border-emerald-500/20 bg-emerald-500/5 text-emerald-200/90' : 'border-red-500/20 bg-red-500/5 text-red-200/90'}`}>
          {runState.error ? `⚠ ${runState.error}\n` : ''}{runState.output}
          <span className="text-white/30"> ({runState.durationMs}ms)</span>
        </div>
      )}
      <span className="sr-only">code accent {accent}</span>
    </div>
  );
}

function Markdown({ text }: { text: string }) {
  return (
    <ReactMarkdown
      components={{
        pre: ({ children }: { children?: ReactNode }) => {
          const arr = Array.isArray(children) ? children : [children];
          const child: any = arr[0];
          const cls: string = child?.props?.className || '';
          const lang = /language-(\w+)/.exec(cls)?.[1] || '';
          const code = String(child?.props?.children || '').replace(/\n$/, '');
          if (!code && !lang) return <pre>{children}</pre>;
          return <CodeBlock lang={lang} code={code} />;
        },
        p: ({ children }) => <p className="mb-2 last:mb-0 leading-relaxed">{children}</p>,
        ul: ({ children }) => <ul className="mb-2 space-y-1 pl-4 list-disc">{children}</ul>,
        ol: ({ children }) => <ol className="mb-2 space-y-1 pl-4 list-decimal">{children}</ol>,
        blockquote: ({ children }) => (
          <blockquote className="border-l-2 pl-3 my-2 italic text-white/70" style={{ borderColor: 'var(--zen-accent)' }}>
            {children}
          </blockquote>
        ),
        a: ({ href, children }) => (
          <a href={href} target="_blank" rel="noreferrer" className="underline underline-offset-2" style={{ color: 'var(--zen-accent)' }}>
            {children}
          </a>
        ),
        strong: ({ children }) => <strong className="font-semibold text-white">{children}</strong>,
        h1: ({ children }) => <h3 className="font-bold text-white mt-1">{children}</h3>,
        h2: ({ children }) => <h3 className="font-bold text-white mt-1">{children}</h3>,
        h3: ({ children }) => <h4 className="font-semibold text-white/90 mt-1">{children}</h4>,
        code: ({ children }) => (
          <code className="bg-white/10 rounded px-1 py-0.5 text-[12px] font-mono text-white/90">{children}</code>
        ),
      }}
    >
      {text}
    </ReactMarkdown>
  );
}

export const MessageBubble = memo(function MessageBubble({
  msg, onRegenerate,
}: {
  msg: Msg;
  onRegenerate?: () => void;
}) {
  const [showThinking, setShowThinking] = useState(true);
  const accent = useZen((s) => s.settings.accent) || '#8b5cf6';

  if (msg.role === 'user') {
    return (
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex justify-end"
      >
        <div className="max-w-[85%] md:max-w-[70%] space-y-1.5">
          {msg.attachments && msg.attachments.length > 0 && (
            <div className="flex flex-wrap gap-1.5 justify-end">
              {msg.attachments.map((a, i) => (
                <span key={i} className="inline-flex items-center gap-1 rounded-lg bg-white/10 border border-white/10 px-2 py-1 text-[11px] text-white/70">
                  {a.dataUrl ? <ImageIcon className="w-3 h-3" /> : <FileText className="w-3 h-3" />}
                  {a.name}
                </span>
              ))}
            </div>
          )}
          <div
            className="rounded-2xl rounded-br-md px-4 py-2.5 text-sm text-white shadow-lg whitespace-pre-wrap"
            style={{
              background: `linear-gradient(135deg, ${accent}dd, ${accent}99)`,
              boxShadow: `0 4px 24px -6px ${accent}66`,
            }}
          >
            {msg.content}
          </div>
          {msg.attachments?.some((a) => a.dataUrl) && (
            <div className="flex flex-wrap gap-2 justify-end">
              {msg.attachments.filter((a) => a.dataUrl).map((a, i) => (
                <img key={i} src={a.dataUrl} alt={a.name} className="rounded-lg max-h-32 border border-white/10" />
              ))}
            </div>
          )}
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="flex gap-2.5">
      <div className="shrink-0 pt-1">
        <ZenLogo size={28} accent={accent} />
      </div>
      <div className="max-w-[88%] md:max-w-[75%] min-w-0">
        {msg.thinking && (
          <div className="mb-2 rounded-xl border border-white/10 bg-white/5 overflow-hidden">
            <button
              onClick={() => setShowThinking((v) => !v)}
              className="w-full flex items-center justify-between px-3 py-1.5 text-[11px] text-white/50 hover:text-white/80"
            >
              <span className="flex items-center gap-1.5">
                <RefreshCw className="w-3 h-3 animate-spin" style={{ animationDuration: '3s' }} /> Thought process
              </span>
              <ChevronDown className={`w-3 h-3 transition-transform ${showThinking ? '' : '-rotate-90'}`} />
            </button>
            {showThinking && (
              <div className="px-3 pb-2 text-[11px] font-mono text-white/45 whitespace-pre-wrap">{msg.thinking}</div>
            )}
          </div>
        )}

        <div className="rounded-2xl rounded-tl-md border border-white/10 bg-white/5 backdrop-blur px-4 py-3 text-sm text-white/90 shadow-xl">
          {msg.content ? (
            <Markdown text={msg.content} />
          ) : (
            <span className="inline-flex gap-1 items-center py-1">
              {[0, 1, 2].map((i) => (
                <motion.span
                  key={i}
                  className="w-1.5 h-1.5 rounded-full bg-white/50"
                  animate={{ opacity: [0.2, 1, 0.2] }}
                  transition={{ duration: 1.1, repeat: Infinity, delay: i * 0.18 }}
                />
              ))}
            </span>
          )}
        </div>

        {msg.sources && msg.sources.length > 0 && (
          <div className="flex flex-wrap gap-1.5 mt-2">
            {msg.sources.map((s, i) => (
              <a
                key={i}
                href={s.url}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1 rounded-full border border-white/15 bg-white/5 px-2.5 py-1 text-[11px] text-white/60 hover:text-white hover:border-white/30 transition-colors"
              >
                <Link2 className="w-3 h-3" /> {s.title.slice(0, 40)}
              </a>
            ))}
          </div>
        )}

        {msg.meta && <p className="text-[10px] text-white/35 mt-1.5 px-1">{msg.meta}</p>}

        {msg.content && onRegenerate && (
          <div className="mt-1.5">
            <Button size="sm" variant="ghost" onClick={onRegenerate} className="h-7 px-2 text-[11px] text-white/40 hover:text-white">
              <RefreshCw className="w-3 h-3 mr-1" /> Regenerate
            </Button>
          </div>
        )}
      </div>
    </motion.div>
  );
});
