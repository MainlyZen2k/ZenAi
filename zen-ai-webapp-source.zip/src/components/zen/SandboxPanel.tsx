'use client';

// Sandbox panel — run HTML games in a live iframe, Python via Pyodide,
// JavaScript in a worker. This is where generated code comes alive.

import { useEffect, useMemo, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Play, X, FlaskConical, Loader2 } from 'lucide-react';
import { useZen } from '@/lib/zen/store';
import { buildSandboxDoc, runJavaScript, runPython } from '@/lib/zen/executor';
import { SANDBOX_PRESETS } from '@/lib/zen/engine';

type Tab = 'html' | 'py' | 'js';

const DEFAULT_HTML = SANDBOX_PRESETS.snake;

export function SandboxPanel() {
  const [tab, setTab] = useState<Tab>('html');
  const [html, setHtml] = useState<string>(() => DEFAULT_HTML);
  const [js, setJs] = useState<string>(
    () => "const squares = [1,2,3,4,5].map(n => n * n);\nconsole.log('squares:', squares);\nreturn squares;"
  );
  const [py, setPy] = useState<string>(
    () =>
      'import math\n\nfor n in range(2, 12):\n    print(n, "is prime" if all(n % i for i in range(2, n)) else "is not")'
  );
  const [docKey, setDocKey] = useState<number>(1);
  const [doc, setDoc] = useState<string>(() => buildSandboxDoc(DEFAULT_HTML));
  const [output, setOutput] = useState('');
  const [running, setRunning] = useState(false);
  const [pyStatus, setPyStatus] = useState('');
  const panelInput = useZen((s) => s.sandboxInput);
  const accent = useZen((s) => s.settings.accent) || '#8b5cf6';

  // consume input sent from chat code blocks / terminal (deferred so the
  // state updates happen outside the effect body)
  useEffect(() => {
    if (!panelInput) return;
    const t = setTimeout(() => {
      const incoming = panelInput;
      useZen.getState().setSandboxInput(null);
      setTab(incoming.tab);
      if (incoming.tab === 'html') {
        const code = incoming.code.startsWith('PRESET:')
          ? SANDBOX_PRESETS[incoming.code.slice(7)] || DEFAULT_HTML
          : incoming.code;
        setHtml(code);
        setDoc(buildSandboxDoc(code));
        setDocKey((k) => k + 1);
      } else if (incoming.tab === 'js') setJs(incoming.code);
      else setPy(incoming.code);
    }, 0);
    return () => clearTimeout(t);
  }, [panelInput]);

  const runHtml = () => {
    setDoc(buildSandboxDoc(html));
    setDocKey((k) => k + 1);
  };

  const runJs = async () => {
    setRunning(true);
    setOutput('');
    const r = await runJavaScript(js);
    setOutput(`${r.error ? '⚠ ' + r.error + '\n' : ''}${r.output}  (${r.durationMs}ms)`);
    setRunning(false);
  };

  const runPy = async () => {
    setRunning(true);
    setOutput('');
    setPyStatus('loading python…');
    const r = await runPython(py, (s) => setPyStatus(s));
    setPyStatus('');
    setOutput(`${r.error ? '⚠ ' + r.error + '\n' : ''}${r.output}  (${r.durationMs}ms)`);
    setRunning(false);
  };

  const presets = useMemo(() => ['snake', 'catch', 'calc', 'todo'], []);

  return (
    <motion.div
      initial={{ y: 60, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      exit={{ y: 60, opacity: 0 }}
      className="fixed bottom-0 left-0 right-0 z-50 md:left-[280px] h-[52vh] min-h-[360px] border-t border-white/15 bg-black/85 backdrop-blur-2xl flex flex-col"
    >
      <div className="flex items-center justify-between px-4 h-11 border-b border-white/10 shrink-0">
        <div className="flex items-center gap-2 text-sm text-white/70">
          <FlaskConical className="w-4 h-4" style={{ color: accent }} />
          Zen Sandbox <span className="text-white/30 text-xs">— real execution, isolated</span>
        </div>
        <Button variant="ghost" size="icon" onClick={() => useZen.getState().setPanel(null)} className="h-8 w-8 text-white/50 hover:text-white" aria-label="Close sandbox">
          <X className="w-4 h-4" />
        </Button>
      </div>

      <div className="flex gap-1 px-3 pt-2 shrink-0">
        {([['html', 'HTML game'], ['py', 'Python'], ['js', 'JavaScript']] as [Tab, string][]).map(([t, label]) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`rounded-lg px-3 py-1.5 text-xs font-medium transition-colors ${
              tab === t ? 'text-white bg-white/15' : 'text-white/45 hover:text-white/75 bg-white/5'
            }`}
          >
            {label}
          </button>
        ))}
        {tab === 'html' && (
          <div className="ml-auto flex gap-1">
            {presets.map((p) => (
              <button
                key={p}
                onClick={() => {
                  setHtml(SANDBOX_PRESETS[p]);
                  setDoc(buildSandboxDoc(SANDBOX_PRESETS[p]));
                  setDocKey((k) => k + 1);
                }}
                className="rounded-full border border-white/15 px-2.5 py-1 text-[11px] text-white/50 hover:text-white hover:border-white/40 transition-colors"
              >
                {p}
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="flex-1 min-h-0 grid grid-cols-1 md:grid-cols-2 gap-3 p-3">
        <textarea
          value={tab === 'html' ? html : tab === 'py' ? py : js}
          onChange={(e) => {
            if (tab === 'html') setHtml(e.target.value);
            else if (tab === 'py') setPy(e.target.value);
            else setJs(e.target.value);
          }}
          spellCheck={false}
          className="h-full w-full resize-none rounded-xl border border-white/10 bg-black/50 p-3 font-mono text-[12px] text-white/90 outline-none zen-scroll"
          aria-label="Code editor"
        />
        <div className="h-full rounded-xl border border-white/10 bg-black/50 overflow-hidden flex flex-col">
          {tab === 'html' ? (
            <iframe
              key={docKey}
              title="Sandbox preview"
              sandbox="allow-scripts allow-pointer-lock"
              srcDoc={doc}
              className="w-full h-full bg-white"
            />
          ) : (
            <div className="w-full h-full overflow-auto zen-scroll p-3 font-mono text-[12px] text-white/80 whitespace-pre-wrap">
              {running ? (
                <span className="flex items-center gap-2 text-white/50">
                  <Loader2 className="w-3 h-3 animate-spin" /> {pyStatus || 'running…'}
                </span>
              ) : (
                output || '▶ hit Run — output appears here.\n\nPython runs on a real CPython (WASM) runtime.\nJS runs in a sandboxed Web Worker.\nHTML runs in a live sandboxed iframe.'
              )}
            </div>
          )}
        </div>
      </div>

      <div className="flex items-center justify-between px-3 h-12 border-t border-white/10 shrink-0">
        <p className="text-[10px] text-white/30">
          {tab === 'html' ? 'live iframe — games actually play' : tab === 'py' ? 'first Python run downloads ~10MB runtime, cached after' : 'sandboxed worker, 8s timeout'}
        </p>
        <Button
          size="sm"
          onClick={tab === 'html' ? runHtml : tab === 'py' ? runPy : runJs}
          disabled={running}
          style={{ background: `linear-gradient(135deg, ${accent}, ${accent}88)` }}
        >
          <Play className="w-3 h-3 mr-1" /> Run
        </Button>
      </div>
    </motion.div>
  );
}
