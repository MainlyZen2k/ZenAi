'use client';

// Live season background — animated canvas particles layered over the
// seasonal gradient. Covers the whole app, reacts to effects setting.

import { useEffect, useRef } from 'react';
import { SEASONS } from '@/lib/zen/themes';
import { useZen } from '@/lib/zen/store';

interface P {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  rot: number;
  vr: number;
  hue?: string;
  life?: number;
  burst?: number;
}

export function SeasonBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const season = useZen((s) => s.season);
  const effects = useZen((s) => s.settings.effects);
  const reduceMotion = useZen((s) => s.settings.reduceMotion);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const info = SEASONS[season] || SEASONS.default;
    const intensity = effects === 'off' || reduceMotion ? 0 : effects === 'low' ? 0.4 : 1;
    let raf = 0;
    let W = 0;
    let H = 0;
    const dpr = Math.min(window.devicePixelRatio || 1, 1.5);

    const resize = () => {
      W = window.innerWidth;
      H = window.innerHeight;
      canvas.width = W * dpr;
      canvas.height = H * dpr;
      canvas.style.width = `${W}px`;
      canvas.style.height = `${H}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    window.addEventListener('resize', resize);

    const rand = (a: number, b: number) => a + Math.random() * (b - a);
    const LEAF_COLORS = ['#e8833a', '#c2410c', '#f59e0b', '#b45309', '#dc6b1f'];
    const FW_COLORS = ['#ff6b9d', '#fbbf24', '#34d399', '#38bdf8', '#c084fc'];
    let particles: P[] = [];
    let fireworks: P[] = [];
    let fwTimer = 0;

    const seed = () => {
      particles = [];
      const n = Math.round(
        (info.particle === 'snow' ? 110 : info.particle === 'leaves' ? 46 : info.particle === 'hearts' ? 26 : info.particle === 'zen' ? 7 : info.particle === 'sun' ? 10 : 14) *
          (intensity || 0)
      );
      for (let i = 0; i < n; i++) {
        particles.push({
          x: rand(0, W),
          y: info.particle === 'hearts' || info.particle === 'sun' ? rand(0, H) : rand(-H, H),
          vx: rand(-0.3, 0.3),
          vy: info.particle === 'hearts' || info.particle === 'sun' ? rand(-0.5, -0.2) : rand(0.4, 1.4),
          size: info.particle === 'snow' ? rand(1.2, 3.4) : info.particle === 'bats' ? rand(6, 11) : rand(4, 10),
          rot: rand(0, Math.PI * 2),
          vr: rand(-0.02, 0.02),
          hue: info.particle === 'leaves' ? LEAF_COLORS[Math.floor(Math.random() * LEAF_COLORS.length)] : undefined,
        });
      }
    };
    seed();

    const drawLeaf = (p: P) => {
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(p.rot);
      ctx.fillStyle = p.hue || '#e8833a';
      ctx.globalAlpha = 0.75;
      ctx.beginPath();
      ctx.ellipse(0, 0, p.size, p.size * 0.45, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    };

    const drawHeart = (p: P) => {
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(Math.sin(p.rot) * 0.3);
      ctx.fillStyle = 'rgba(255,107,157,0.55)';
      const s = p.size / 6;
      ctx.beginPath();
      ctx.moveTo(0, s * 2);
      ctx.bezierCurveTo(s * 4, -s * 2, s * 8, s * 3, 0, s * 8);
      ctx.bezierCurveTo(-s * 8, s * 3, -s * 4, -s * 2, 0, s * 2);
      ctx.fill();
      ctx.restore();
    };

    const drawBat = (p: P) => {
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.strokeStyle = 'rgba(20,16,28,0.85)';
      ctx.lineWidth = 2;
      const flap = Math.sin(p.rot * 6) * p.size * 0.4;
      ctx.beginPath();
      ctx.moveTo(-p.size, flap * 0.4);
      ctx.quadraticCurveTo(-p.size / 2, -flap, 0, 0);
      ctx.quadraticCurveTo(p.size / 2, -flap, p.size, flap * 0.4);
      ctx.stroke();
      ctx.restore();
    };

    const drawOrb = (p: P, color: string, alpha: number) => {
      const g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.size * 8);
      g.addColorStop(0, color.replace('ALPHA', String(alpha)));
      g.addColorStop(1, color.replace('ALPHA', '0'));
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size * 8, 0, Math.PI * 2);
      ctx.fill();
    };

    const burst = () => {
      const cx = rand(W * 0.15, W * 0.85);
      const cy = rand(H * 0.1, H * 0.5);
      const color = FW_COLORS[Math.floor(Math.random() * FW_COLORS.length)];
      const count = Math.round(rand(26, 44) * intensity);
      for (let i = 0; i < count; i++) {
        const a = (Math.PI * 2 * i) / count;
        const sp = rand(1.5, 4.5);
        fireworks.push({
          x: cx,
          y: cy,
          vx: Math.cos(a) * sp,
          vy: Math.sin(a) * sp,
          size: rand(1.5, 2.6),
          rot: 0,
          vr: 0,
          hue: color,
          life: 1,
        });
      }
    };

    const tick = () => {
      ctx.clearRect(0, 0, W, H);

      if (intensity > 0) {
        for (const p of particles) {
          p.rot += p.vr;
          if (info.particle === 'leaves') {
            p.x += p.vx + Math.sin(p.y * 0.012 + p.rot) * 0.7;
            p.y += p.vy * 0.7;
            drawLeaf(p);
          } else if (info.particle === 'snow') {
            p.x += p.vx + Math.sin(p.y * 0.01) * 0.4;
            p.y += p.vy * 0.5;
            ctx.fillStyle = 'rgba(255,255,255,0.7)';
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
            ctx.fill();
          } else if (info.particle === 'hearts') {
            p.y += p.vy * 0.55;
            p.x += Math.sin(p.y * 0.015) * 0.5;
            drawHeart(p);
          } else if (info.particle === 'bats') {
            p.x += rand(0.6, 1.6);
            p.y += Math.sin(p.rot * 3) * 0.8;
            drawBat(p);
          } else if (info.particle === 'sun') {
            p.y += p.vy * 0.18;
            drawOrb(p, 'rgba(255,209,102,ALPHA)', 0.16);
          } else if (info.particle === 'zen') {
            p.x += Math.sin(p.rot * 0.5) * 0.25;
            p.y += Math.cos(p.rot * 0.4) * 0.2;
            p.rot += 0.002;
            drawOrb(p, 'rgba(124,156,255,ALPHA)', 0.1);
          }
          // wrap
          if (p.y > H + 20) {
            p.y = -20;
            p.x = rand(0, W);
          }
          if (p.y < -30) {
            p.y = H + 20;
            p.x = rand(0, W);
          }
          if (p.x > W + 30) p.x = -30;
          if (p.x < -30) p.x = W + 30;
        }

        // fireworks
        if (info.particle === 'fireworks') {
          fwTimer++;
          if (fwTimer % 90 === 0) burst();
          for (const f of fireworks) {
            f.x += f.vx;
            f.y += f.vy;
            f.vy += 0.035;
            f.life = (f.life || 1) - 0.014;
            ctx.globalAlpha = Math.max(0, f.life || 0);
            ctx.fillStyle = f.hue || '#fff';
            ctx.beginPath();
            ctx.arc(f.x, f.y, f.size, 0, Math.PI * 2);
            ctx.fill();
            ctx.globalAlpha = 1;
          }
          fireworks = fireworks.filter((f) => (f.life || 0) > 0);
        }
      }

      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
    };
  }, [season, effects, reduceMotion]);

  const info = SEASONS[season] || SEASONS.default;

  return (
    <>
      <div
        aria-hidden
        className="fixed inset-0 -z-20"
        style={{
          background: `radial-gradient(1200px 700px at 20% -10%, ${info.glow}22, transparent 60%),
                       radial-gradient(1000px 600px at 90% 110%, ${info.accent}1f, transparent 55%),
                       linear-gradient(160deg, ${info.bgFrom} 0%, ${info.bgTo} 100%)`,
        }}
      />
      <canvas ref={canvasRef} aria-hidden className="fixed inset-0 -z-10 pointer-events-none" />
    </>
  );
}
