'use client';

// Settings modal: profile, appearance (accent/logo/themes/effects),
// AI engine + model manager, memory, firebase config, data, about.

import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import {
  User, Palette, Cpu, BrainCircuit, Cloud, Database, Info, Plus, Trash2,
  Loader2, Check, Download, CloudOff, ShieldCheck, Zap, KeyRound, ExternalLink,
} from 'lucide-react';
import { useZen, todayKey, DAILY_GRANT } from '@/lib/zen/store';
import { SEASONS, ACCENTS } from '@/lib/zen/themes';
import { ZenLogo } from './ZenLogo';
import { MODEL_CATALOG, hasWebGPU } from '@/lib/zen/webllm';
import { CLOUD_PROVIDERS, cloudTestKey, defaultModelsFor } from '@/lib/zen/cloud';
import { initFirebase, hasConfigLive, ADMIN_EMAILS } from '@/lib/zen/firebase';
import type { FBConfig, CloudProvider } from '@/lib/zen/types';

const CFG_KEY = 'zen-fb-config';

type TabId = 'profile' | 'appearance' | 'engine' | 'memory' | 'firebase' | 'data' | 'about';

const TABS: { id: TabId; label: string; icon: typeof User }[] = [
  { id: 'profile', label: 'Profile', icon: User },
  { id: 'appearance', label: 'Appearance', icon: Palette },
  { id: 'engine', label: 'AI Engine', icon: Cpu },
  { id: 'memory', label: 'Memory', icon: BrainCircuit },
  { id: 'firebase', label: 'Firebase', icon: Cloud },
  { id: 'data', label: 'Data', icon: Database },
  { id: 'about', label: 'About', icon: Info },
];

const EMPTY_CFG: FBConfig = {
  apiKey: '',
  authDomain: '',
  projectId: '',
  storageBucket: '',
  messagingSenderId: '',
  appId: '',
};

export function SettingsPanel({ initialTab = 'profile' }: { initialTab?: TabId }) {
  const [tab, setTab] = useState<TabId>(initialTab);
  const [memInput, setMemInput] = useState('');
  const [cfg, setCfg] = useState<FBConfig>(() => {
    try {
      return JSON.parse(localStorage.getItem(CFG_KEY) || 'null') || EMPTY_CFG;
    } catch {
      return EMPTY_CFG;
    }
  });
  const { toast } = useToast();
  const settings = useZen((s) => s.settings);
  const cloud = useZen((s) => s.settings.cloud);
  const updateCloud = useZen((s) => s.updateCloud);
  const [testing, setTesting] = useState(false);
  const season = useZen((s) => s.season);
  const memory = useZen((s) => s.memory);
  const engine = useZen((s) => s.engine);
  const user = useZen((s) => s.user);
  const fbMode = useZen((s) => s.fbMode);
  const tokens = useZen((s) => s.tokens);
  const updateSettings = useZen((s) => s.updateSettings);
  const refreshSeason = useZen((s) => s.refreshSeason);
  const accent = settings.accent || SEASONS[season]?.accent || '#8b5cf6';

  const info = SEASONS[season] || SEASONS.default;

  const saveCfg = () => {
    if (!cfg.apiKey || !cfg.projectId || !cfg.appId) {
      toast({ title: 'Missing fields', description: 'apiKey, projectId and appId are required.', variant: 'destructive' });
      return;
    }
    localStorage.setItem(CFG_KEY, JSON.stringify(cfg));
    const ok = initFirebase(cfg);
    toast({
      title: ok ? 'Firebase connected' : 'Init failed',
      description: ok ? 'Sign out and sign in to activate cloud sync.' : 'Double-check every value.',
      variant: ok ? 'default' : 'destructive',
    });
  };

  const testCloudKey = async () => {
    setTesting(true);
    try {
      const r = await cloudTestKey(cloud.provider, cloud.apiKey.trim(), cloud.baseUrl);
      toast({
        title: r.ok ? 'Key works' : 'Key test failed',
        description: r.detail,
        variant: r.ok ? 'default' : 'destructive',
      });
    } finally {
      setTesting(false);
    }
  };

  const exportData = () => {
    const blob = new Blob(
      [JSON.stringify({ chats: useZen.getState().chats, memory, settings, exportedAt: new Date().toISOString() }, null, 2)],
      { type: 'application/json' }
    );
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'zen-ai-data.json';
    a.click();
    URL.revokeObjectURL(a.href);
    toast({ title: 'Exported', description: 'zen-ai-data.json saved.' });
  };

  return (
    <Dialog open onOpenChange={(o) => !o && useZen.getState().setPanel(null)}>
      <DialogContent className="max-w-2xl max-h-[86dvh] bg-black/85 border-white/15 backdrop-blur-2xl text-white overflow-hidden p-0 zen-scroll">
        <DialogHeader className="px-6 pt-5 pb-0">
          <DialogTitle className="flex items-center gap-2">
            <ZenLogo size={22} accent={accent} /> Settings
          </DialogTitle>
          <DialogDescription className="text-white/40 text-xs">
            Themes, engine, memory and cloud — everything in one place.
          </DialogDescription>
        </DialogHeader>

        <div className="flex gap-1 px-4 pt-3 pb-1 flex-wrap">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium transition-colors ${
                tab === t.id ? 'bg-white/15 text-white' : 'text-white/45 hover:text-white/80 bg-white/5'
              }`}
            >
              <t.icon className="w-3.5 h-3.5" /> {t.label}
            </button>
          ))}
        </div>

        <div className="px-6 py-4 overflow-y-auto zen-scroll" style={{ maxHeight: 'calc(86dvh - 150px)' }}>
          {tab === 'profile' && (
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl flex items-center justify-center text-xl font-bold" style={{ background: `linear-gradient(135deg, ${accent}, ${accent}88)` }}>
                  {(user?.name || 'Z')[0].toUpperCase()}
                </div>
                <div>
                  <div className="font-semibold">{user?.name}</div>
                  <div className="text-sm text-white/50">{user?.email}</div>
                  <div className="text-xs text-white/35 mt-0.5 flex items-center gap-1">
                    {user?.role === 'admin' && <ShieldCheck className="w-3 h-3" style={{ color: accent }} />}
                    {user?.role} · {fbMode === 'live' ? 'cloud synced' : 'local only'}
                  </div>
                </div>
              </div>
              <div className="rounded-xl border border-white/10 bg-white/5 p-4 text-sm text-white/60">
                <div className="flex justify-between py-1"><span>Tokens</span><span className="text-white font-semibold tabular-nums">{tokens.balance.toLocaleString()}</span></div>
                <div className="flex justify-between py-1"><span>Daily grant</span><span className="text-white">+{DAILY_GRANT}</span></div>
                <div className="flex justify-between py-1"><span>Last claimed</span><span className="text-white">{tokens.claimedAt === todayKey() ? 'today ✓' : 'not yet'}</span></div>
                <div className="flex justify-between py-1"><span>Chats stored</span><span className="text-white">{useZen.getState().chats.length}</span></div>
                <div className="flex justify-between py-1"><span>Memories</span><span className="text-white">{memory.length}</span></div>
              </div>
            </div>
          )}

          {tab === 'appearance' && (
            <div className="space-y-5">
              <div>
                <div className="text-xs uppercase tracking-wide text-white/40 mb-2">Accent color (logo + UI)</div>
                <div className="flex flex-wrap gap-2">
                  {ACCENTS.map((a) => (
                    <button
                      key={a.value}
                      onClick={() => updateSettings({ accent: a.value })}
                      className={`w-9 h-9 rounded-xl border-2 transition-transform hover:scale-110 ${settings.accent === a.value ? 'border-white scale-110' : 'border-transparent'}`}
                      style={{ background: a.value }}
                      title={a.name}
                      aria-label={a.name}
                    >
                      {settings.accent === a.value && <Check className="w-4 h-4 text-white mx-auto" />}
                    </button>
                  ))}
                  <div className="flex items-center gap-2 ml-1">
                    <ZenLogo size={36} accent={accent} />
                    <span className="text-[11px] text-white/40">live preview — design stays, color changes</span>
                  </div>
                </div>
              </div>

              <div>
                <div className="text-xs uppercase tracking-wide text-white/40 mb-2">Live theme</div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[{ id: null, label: 'Auto (season)' }, ...Object.values(SEASONS)].map((s: any) => (
                    <button
                      key={s.id || 'auto'}
                      onClick={() => {
                        updateSettings({ themeOverride: s.id });
                        refreshSeason();
                      }}
                      className={`rounded-xl border px-2.5 py-2 text-xs transition-colors ${
                        (s.id ? settings.themeOverride === s.id : !settings.themeOverride)
                          ? 'border-white/60 bg-white/10 text-white'
                          : 'border-white/10 text-white/50 hover:border-white/30'
                      }`}
                    >
                      {s.id ? `${s.emoji} ${s.label}` : '🗓 Auto (today: ' + info.emoji + ')'}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="text-xs uppercase tracking-wide text-white/40 mb-2">Background effects</div>
                <div className="flex gap-2">
                  {(['off', 'low', 'high'] as const).map((e) => (
                    <button
                      key={e}
                      onClick={() => updateSettings({ effects: e })}
                      className={`rounded-lg px-4 py-2 text-xs capitalize transition-colors ${
                        settings.effects === e ? 'bg-white/15 text-white' : 'bg-white/5 text-white/50 hover:text-white'
                      }`}
                    >
                      {e}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between rounded-xl border border-white/10 bg-white/5 p-3">
                <div>
                  <div className="text-sm">Reduce motion</div>
                  <div className="text-[11px] text-white/40">Disables particles + most animations</div>
                </div>
                <Switch checked={settings.reduceMotion} onCheckedChange={(v) => updateSettings({ reduceMotion: v })} />
              </div>
            </div>
          )}

          {tab === 'engine' && (
            <div className="space-y-4">
              {/* ---- cloud brain (priority) ---- */}
              <div className="rounded-xl border border-white/10 bg-white/5 p-4">
                <div className="flex items-center justify-between gap-3">
                  <div className="text-sm font-semibold flex items-center gap-2">
                    <Zap className="w-4 h-4" style={{ color: accent }} />
                    Cloud brain — real AI with your own API key
                  </div>
                  <Switch
                    checked={cloud.enabled}
                    onCheckedChange={(v) => updateCloud({ enabled: v })}
                    aria-label="Use cloud brain"
                  />
                </div>
                <p className="text-[11px] text-white/45 mt-1 mb-3">
                  Recommended — answers stream from a real model. <span className="text-white/70">Google AI Studio keys are free, no credit card needed.</span> The key is stored only on this device and sent only to the provider you pick.
                </p>

                <div className="flex flex-wrap gap-2 mb-2">
                  {(Object.keys(CLOUD_PROVIDERS) as CloudProvider[]).map((p) => (
                    <button
                      key={p}
                      onClick={() => updateCloud({ provider: p, ...defaultModelsFor(p) })}
                      className={`rounded-lg px-3 py-1.5 text-xs transition-colors ${
                        cloud.provider === p ? 'bg-white/15 text-white' : 'bg-white/5 text-white/50 hover:text-white'
                      }`}
                    >
                      {CLOUD_PROVIDERS[p].label}
                    </button>
                  ))}
                </div>
                <p className="text-xs text-white/55 mb-2">{CLOUD_PROVIDERS[cloud.provider].blurb}</p>

                <div className="flex gap-2">
                  <Input
                    type="password"
                    value={cloud.apiKey}
                    onChange={(e) => updateCloud({ apiKey: e.target.value })}
                    placeholder={
                      cloud.provider === 'gemini'
                        ? 'Paste your free Gemini key (starts with AIza…)'
                        : cloud.provider === 'openrouter'
                          ? 'sk-or-v1-…'
                          : 'API key for this endpoint'
                    }
                    className="h-9 text-xs bg-white/5 border-white/10 text-white font-mono placeholder:text-white/25"
                    aria-label="API key"
                  />
                  <Button
                    size="sm"
                    disabled={testing || !cloud.apiKey.trim()}
                    onClick={testCloudKey}
                    className="shrink-0"
                    style={{ background: `linear-gradient(135deg, ${accent}, ${accent}88)` }}
                  >
                    {testing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <KeyRound className="w-3.5 h-3.5" />}
                    Test
                  </Button>
                </div>

                {CLOUD_PROVIDERS[cloud.provider].keyUrl && (
                  <a
                    href={CLOUD_PROVIDERS[cloud.provider].keyUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 mt-2 text-xs font-medium hover:underline"
                    style={{ color: accent }}
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    {CLOUD_PROVIDERS[cloud.provider].keyUrlLabel} — free, opens in a new tab
                  </a>
                )}

                {CLOUD_PROVIDERS[cloud.provider].needsBaseUrl && (
                  <div className="mt-2 space-y-1">
                    <div className="text-[10px] uppercase tracking-wide text-white/40">Base URL (OpenAI-compatible)</div>
                    <Input
                      value={cloud.baseUrl}
                      onChange={(e) => updateCloud({ baseUrl: e.target.value })}
                      placeholder={CLOUD_PROVIDERS.custom.baseUrlPlaceholder}
                      className="h-8 text-xs bg-white/5 border-white/10 text-white font-mono"
                    />
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mt-3">
                  {(['Mini', 'Think', 'Pro'] as const).map((label) => (
                    <div key={label} className="space-y-1">
                      <div className="text-[10px] uppercase tracking-wide text-white/40">{label} model</div>
                      <Input
                        value={cloud[`model${label}` as 'modelMini']}
                        onChange={(e) => updateCloud({ [`model${label}` as 'modelMini']: e.target.value } as any)}
                        className="h-8 text-[11px] bg-white/5 border-white/10 text-white font-mono"
                        aria-label={`${label} model id`}
                      />
                    </div>
                  ))}
                </div>
                <p className="text-[11px] text-white/35 mt-2">
                  Switching providers resets the model fields to that provider's defaults. If a model name stops existing (free tiers change), just type another one — e.g. <code className="text-white/55">gemini-2.0-flash</code>.
                </p>

                <div className="mt-3 rounded-lg bg-white/5 border border-white/10 px-3 py-2 text-[11px] text-white/50">
                  Next message answers with:{' '}
                  <span className="text-white font-semibold">
                    {cloud.enabled && cloud.apiKey.trim()
                      ? `Cloud · ${cloud.provider === 'gemini' ? 'Gemini' : cloud.provider === 'openrouter' ? 'OpenRouter' : 'Custom endpoint'}`
                      : engine.status === 'ready'
                        ? 'On-device model (offline)'
                        : 'Built-in engine (offline)'}
                  </span>
                  — cloud fails → auto-fallback to the offline brain, so chat never dies.
                </div>
              </div>

              <div className={`rounded-xl border p-4 ${engine.status === 'error' ? 'border-red-500/30 bg-red-500/5' : 'border-white/10 bg-white/5'}`}>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-sm font-semibold flex items-center gap-2">
                      <Cpu className="w-4 h-4" style={{ color: accent }} />
                      WebGPU {hasWebGPU() ? 'available' : 'not found'}
                    </div>
                    <div className="text-xs text-white/50 mt-0.5">{engine.progressText || (hasWebGPU() ? 'Ready to install an on-device model' : 'Chrome/Edge 121+ on desktop or Android Chrome supports WebGPU')}</div>
                    {engine.error && <div className="text-xs text-red-300 mt-1">{engine.error}</div>}
                  </div>
                </div>
                {(engine.status === 'downloading' || engine.status === 'loading') && (
                  <div className="mt-3">
                    <Progress value={Math.round(engine.progress * 100)} className="h-2" />
                    <div className="text-[11px] text-white/40 mt-1">{Math.round(engine.progress * 100)}% — {engine.status === 'downloading' ? 'downloading (one-time)' : 'compiling for your GPU'}</div>
                  </div>
                )}
                {engine.status === 'ready' && (
                  <div className="mt-2 text-xs text-emerald-300">✓ On-device brain active: {engine.modelId}</div>
                )}
              </div>

              <div>
                <div className="text-xs uppercase tracking-wide text-white/40 mb-2">Default engine</div>
                <div className="flex flex-wrap gap-2">
                  {([['auto', 'Auto (recommended)'], ['builtin', 'Built-in only'], ['device', 'On-device LLM']] as const).map(([v, l]) => (
                    <button
                      key={v}
                      onClick={() => updateSettings({ engineMode: v })}
                      className={`rounded-lg px-4 py-2 text-xs transition-colors ${
                        settings.engineMode === v ? 'bg-white/15 text-white' : 'bg-white/5 text-white/50 hover:text-white'
                      }`}
                    >
                      {l}
                    </button>
                  ))}
                </div>
                <p className="text-[11px] text-white/35 mt-2">
                  Offline brains. The built-in engine is instant and private; the on-device model downloads once and answers with a real (small) LLM. They take over when the cloud brain is off, out of quota, or unreachable — the cloud brain (if enabled + key saved) always goes first.
                </p>
              </div>

              <div className="space-y-2">
                <div className="text-xs uppercase tracking-wide text-white/40">On-device models</div>
                {MODEL_CATALOG.map((m, i) => (
                  <div key={m.id} className="flex items-center justify-between rounded-xl border border-white/10 bg-white/5 p-3">
                    <div>
                      <div className="text-sm font-medium">{i + 1}. {m.label}</div>
                      <div className="text-[11px] text-white/40">{m.size} · {m.note}</div>
                    </div>
                    {engine.status === 'ready' && engine.modelId === m.id ? (
                      <span className="text-xs text-emerald-300 flex items-center gap-1"><Check className="w-3.5 h-3.5" /> active</span>
                    ) : (
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          disabled={engine.status === 'downloading' || engine.status === 'loading' || !hasWebGPU()}
                          onClick={() => useZen.getState().downloadModel(m.id)}
                          style={{ background: `linear-gradient(135deg, ${accent}, ${accent}88)` }}
                        >
                          {(engine.status === 'downloading' || engine.status === 'loading') && engine.modelId === m.id ? (
                            <Loader2 className="w-3 h-3 animate-spin" />
                          ) : (
                            <Download className="w-3 h-3 mr-1" />
                          )}
                          Install
                        </Button>
                        <Button size="sm" variant="ghost" className="text-white/40" onClick={() => useZen.getState().deleteModel(m.id)} aria-label={`Delete ${m.label}`}>
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    )}
                  </div>
                ))}
                {!hasWebGPU() && <p className="text-[11px] text-amber-300/80">Your browser doesn't expose WebGPU — the app keeps working with the built-in engine. In the Android build, the native runtime handles this (see the guide).</p>}
              </div>
            </div>
          )}

          {tab === 'memory' && (
            <div className="space-y-3">
              <div className="flex gap-2">
                <Input
                  value={memInput}
                  onChange={(e) => setMemInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && memInput.trim()) {
                      useZen.getState().addMemory(memInput.trim());
                      setMemInput('');
                    }
                  }}
                  placeholder="Teach Zen something: 'I'm building a Roblox game called Zen Kingdom'…"
                  className="bg-white/5 border-white/10 text-white placeholder:text-white/30"
                />
                <Button
                  onClick={() => {
                    if (memInput.trim()) { useZen.getState().addMemory(memInput.trim()); setMemInput(''); }
                  }}
                  style={{ background: `linear-gradient(135deg, ${accent}, ${accent}88)` }}
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              <div className="rounded-xl border border-white/10 divide-y divide-white/5 max-h-72 overflow-y-auto zen-scroll">
                {memory.length === 0 && <p className="p-4 text-sm text-white/35">Memory is empty. Zen uses it to personalize answers — say "remember that …" in chat or add above.</p>}
                {memory.map((m) => (
                  <div key={m.id} className="flex items-center gap-2 px-3 py-2.5 group">
                    <span className="flex-1 text-sm text-white/80">{m.text}</span>
                    <span className="text-[10px] text-white/30 shrink-0">{new Date(m.ts).toLocaleDateString()}</span>
                    <button onClick={() => useZen.getState().deleteMemory(m.id)} className="text-white/30 group-hover:text-red-400 transition-colors" aria-label="Delete memory">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
              {memory.length > 0 && (
                <Button variant="ghost" size="sm" className="text-red-300/70 hover:text-red-300" onClick={() => useZen.getState().clearMemory()}>
                  <Trash2 className="w-3 h-3 mr-1" /> Clear all memory
                </Button>
              )}
            </div>
          )}

          {tab === 'firebase' && (
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-sm">
                {hasConfigLive() ? <Cloud className="w-4 h-4 text-emerald-300" /> : <CloudOff className="w-4 h-4 text-white/40" />}
                Status: {fbMode === 'live' ? 'connected + signed in' : hasConfigLive() ? 'config loaded — sign in on the next launch' : 'not configured'}
              </div>
              <p className="text-xs text-white/45 leading-relaxed">
                Paste the web app config from <span className="text-white/70">Firebase console → Project settings → General → Your apps</span>. Cloud mode enables: email + Google sign-in, chat sync, login logs, ban system, and the admin panel. Full walkthrough lives in the setup guide.
              </p>
              {(Object.keys(EMPTY_CFG) as (keyof FBConfig)[]).map((k) => (
                <div key={k} className="space-y-1">
                  <div className="text-[10px] uppercase tracking-wide text-white/40">{k}</div>
                  <Input
                    value={cfg[k]}
                    onChange={(e) => setCfg({ ...cfg, [k]: e.target.value })}
                    className="h-8 text-xs bg-white/5 border-white/10 text-white font-mono"
                  />
                </div>
              ))}
              <Button onClick={saveCfg} className="w-full" style={{ background: `linear-gradient(135deg, ${accent}, ${accent}88)` }}>
                Save & connect
              </Button>
              <p className="text-[11px] text-white/35">
                Admin auto-promotion list: <code className="text-white/60">{ADMIN_EMAILS.length ? ADMIN_EMAILS.join(', ') : '(empty — edit ADMIN_EMAILS in src/lib/zen/firebase.ts)'}</code>
              </p>
            </div>
          )}

          {tab === 'data' && (
            <div className="space-y-3">
              <Button onClick={exportData} variant="outline" className="w-full bg-white/5 border-white/15">
                <Database className="w-4 h-4 mr-2" /> Export everything as JSON
              </Button>
              <Button
                variant="outline"
                className="w-full bg-white/5 border-white/15 text-red-300 hover:text-red-200"
                onClick={() => {
                  if (confirm('Delete ALL chats? This cannot be undone.')) {
                    useZen.setState({ chats: [], activeChatId: null });
                    toast({ title: 'All chats deleted' });
                  }
                }}
              >
                <Trash2 className="w-4 h-4 mr-2" /> Delete all chats
              </Button>
              <Button
                variant="outline"
                className="w-full bg-white/5 border-white/15 text-red-300 hover:text-red-200"
                onClick={() => {
                  if (confirm('Factory reset: chats, memory, tokens, settings?')) {
                    localStorage.removeItem('zen-ai-store');
                    location.reload();
                  }
                }}
              >
                <Trash2 className="w-4 h-4 mr-2" /> Factory reset (wipes local store)
              </Button>
            </div>
          )}

          {tab === 'about' && (
            <div className="space-y-3 text-sm text-white/60 leading-relaxed">
              <div className="flex items-center gap-3">
                <ZenLogo size={44} accent={accent} />
                <div>
                  <div className="font-bold text-white">Zen AI</div>
                  <div className="text-xs text-white/40">v1.1 · cloud + offline assistant</div>
                </div>
              </div>
              <p>
                Zen AI answers with a real cloud model when you add your own free API key (Settings → AI Engine); without one it still runs on-device: the built-in brain never phones home, the optional on-device LLM downloads once and runs locally, and every tool (terminal, sandbox, GitHub reader, deobfuscator) executes in isolated sandboxes.
              </p>
              <ul className="list-disc pl-5 space-y-1 text-[13px]">
                <li>Three minds: Zen-Mini, Zen-Think, Zen-Pro</li>
                <li>Cloud brain: bring your own free Gemini / OpenRouter key, streaming + thinking traces</li>
                <li>Live season themes that cover the whole UI</li>
                <li>Real Python (Pyodide) + JavaScript (worker) + HTML sandbox</li>
                <li>GitHub repo reader + JS deobfuscator</li>
                <li>Tokens, memory, quotes, admin panel & ban system via Firebase</li>
              </ul>
              <p className="text-xs text-white/30">Built with Next.js 16 · WebLLM · Pyodide · Firebase · Tailwind 4 · framer-motion</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
