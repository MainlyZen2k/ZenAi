'use client';

// Animated sidebar: chats, tools, theme badge, token balance, user chip.

import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import {
  Plus, Terminal, FlaskConical, Settings, Users, Trash2, LogOut,
  BrainCircuit, Coins, ChevronLeft, X, Sparkles, Gift, CloudOff, Cloud,
} from 'lucide-react';
import { useZen, todayKey } from '@/lib/zen/store';
import { SEASONS } from '@/lib/zen/themes';
import { ZenLogo } from './ZenLogo';
import type { ModelMode } from '@/lib/zen/types';

function ModeIcon({ mode }: { mode: ModelMode }) {
  if (mode === 'mini') return <Sparkles className="w-3 h-3 text-amber-300" />;
  if (mode === 'think') return <BrainCircuit className="w-3 h-3 text-sky-300" />;
  return <Terminal className="w-3 h-3 text-emerald-300" />;
}

export function Sidebar() {
  const {
    chats, activeChatId, sidebarOpen, panel, season, tokens, user, fbMode,
    newChat, openChat, deleteChat, setPanel, setSidebar, claimDaily, logout,
  } = useZen();
  const { toast } = useToast();
  const info = SEASONS[season] || SEASONS.default;
  const accent = useZen((s) => s.settings.accent) || info.accent;
  const memoryCount = useZen((s) => s.memory.length);
  const canClaim = tokens.claimedAt !== todayKey();

  return (
    <>
      {/* scrim */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSidebar(false)}
            className="fixed inset-0 bg-black/50 z-30 md:hidden"
          />
        )}
      </AnimatePresence>

      <AnimatePresence initial={false}>
        {sidebarOpen && (
          <motion.aside
            initial={{ x: -300, opacity: 0.5 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: -300, opacity: 0.5 }}
            transition={{ type: 'spring', damping: 26, stiffness: 260 }}
            className="fixed md:relative z-40 h-dvh w-[280px] flex flex-col border-r border-white/10 bg-black/55 backdrop-blur-2xl"
          >
            {/* header */}
            <div className="flex items-center justify-between px-4 h-16 shrink-0">
              <div className="flex items-center gap-2.5">
                <ZenLogo size={30} accent={accent} />
                <div>
                  <div className="font-bold text-white leading-none">Zen AI</div>
                  <div className="text-[10px] text-white/40 mt-0.5">{info.emoji} {info.label} season</div>
                </div>
              </div>
              <Button
                variant="ghost" size="icon"
                onClick={() => setSidebar(false)}
                className="text-white/50 hover:text-white hover:bg-white/10 h-8 w-8"
                aria-label="Close sidebar"
              >
                <ChevronLeft className="w-4 h-4" />
              </Button>
            </div>

            {/* new chat */}
            <div className="px-3">
              <Button
                onClick={() => { newChat(); if (window.innerWidth < 768) setSidebar(false); }}
                className="w-full h-10 font-semibold"
                style={{ background: `linear-gradient(135deg, ${accent}, ${info.glow})` }}
              >
                <Plus className="w-4 h-4 mr-1" /> New chat
              </Button>
            </div>

            {/* chats */}
            <div className="flex-1 overflow-y-auto px-3 py-3 zen-scroll">
              <div className="text-[10px] uppercase tracking-wider text-white/30 px-2 mb-2">Chats</div>
              <div className="space-y-1">
                {chats.length === 0 && (
                  <p className="text-xs text-white/30 px-2 py-3">No chats yet. Say something to Zen.</p>
                )}
                {chats.map((c) => (
                  <div
                    key={c.id}
                    onClick={() => { openChat(c.id); if (window.innerWidth < 768) setSidebar(false); }}
                    className={`group flex items-center gap-2 rounded-lg px-2.5 py-2 cursor-pointer transition-colors ${
                      activeChatId === c.id ? 'bg-white/15' : 'hover:bg-white/8'
                    }`}
                    style={activeChatId === c.id ? { boxShadow: `inset 2px 0 0 ${accent}` } : undefined}
                  >
                    <ModeIcon mode={c.mode} />
                    <span className="flex-1 text-xs text-white/80 truncate">{c.title}</span>
                    <button
                      onClick={(e) => { e.stopPropagation(); deleteChat(c.id); }}
                      className="opacity-0 group-hover:opacity-100 text-white/40 hover:text-red-400 transition-opacity"
                      aria-label={`Delete chat ${c.title}`}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* tools */}
            <div className="px-3 pb-2 space-y-1 shrink-0">
              {[
                { id: 'terminal' as const, icon: Terminal, label: 'AI Terminal', hint: 'run js / py / git' },
                { id: 'sandbox' as const, icon: FlaskConical, label: 'Sandbox', hint: 'run html games & code' },
                { id: 'memory' as const, icon: BrainCircuit, label: 'Memory', hint: `${memoryCount} facts` },
                { id: 'settings' as const, icon: Settings, label: 'Settings', hint: 'themes · engine · data' },
                ...(user?.role === 'admin' ? [{ id: 'admin' as const, icon: Users, label: 'Admin Panel', hint: 'users · ban · tokens' }] : []),
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => { setPanel(item.id); if (window.innerWidth < 768) setSidebar(false); }}
                  className={`w-full flex items-center gap-3 rounded-lg px-2.5 py-2 text-left transition-colors ${
                    panel === item.id ? 'bg-white/15' : 'hover:bg-white/8'
                  }`}
                >
                  <item.icon className="w-4 h-4 text-white/60" />
                  <div className="flex-1">
                    <div className="text-xs font-medium text-white/85">{item.label}</div>
                    <div className="text-[10px] text-white/35">{item.hint}</div>
                  </div>
                </button>
              ))}
            </div>

            {/* tokens */}
            <div className="px-3 pb-3 shrink-0">
              <div className="rounded-xl border border-white/10 bg-white/5 p-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Coins className="w-4 h-4" style={{ color: accent }} />
                    <span className="text-xs text-white/50">Tokens</span>
                  </div>
                  <span className="text-sm font-bold text-white tabular-nums">{tokens.balance.toLocaleString()}</span>
                </div>
                <Button
                  size="sm"
                  variant={canClaim ? 'default' : 'ghost'}
                  disabled={!canClaim}
                  onClick={() => {
                    if (claimDaily()) toast({ title: '+500 tokens claimed', description: 'Come back tomorrow for more.' });
                  }}
                  className={`w-full mt-2 h-8 text-xs ${canClaim ? '' : 'text-white/30'}`}
                  style={canClaim ? { background: `linear-gradient(135deg, ${accent}, ${info.glow})` } : undefined}
                >
                  <Gift className="w-3 h-3 mr-1" /> {canClaim ? 'Claim daily +500' : 'Claimed today'}
                </Button>
              </div>

              {/* user */}
              <div className="flex items-center gap-2 mt-3 px-1">
                <div
                  className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold text-white shrink-0"
                  style={{ background: `linear-gradient(135deg, ${accent}, ${info.glow})` }}
                >
                  {(user?.name || 'Z')[0].toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-medium text-white truncate">{user?.name}</div>
                  <div className="text-[10px] text-white/40 flex items-center gap-1">
                    {fbMode === 'live' ? <Cloud className="w-3 h-3" /> : <CloudOff className="w-3 h-3" />}
                    {user?.role === 'admin' ? 'admin' : 'member'} · {fbMode === 'live' ? 'cloud' : 'local'}
                  </div>
                </div>
                <Button variant="ghost" size="icon" onClick={logout} className="h-8 w-8 text-white/40 hover:text-red-400" aria-label="Sign out">
                  <LogOut className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </motion.aside>
        )}
      </AnimatePresence>
    </>
  );
}
