'use client';

// Zen AI Terminal — a real command line inside the app.
// Real execution: run js, run py, sandbox. Real tools: git read, deobf.
// Virtual shell for app control: model, theme, tokens, memory, connect.

import { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { X, Terminal as TermIcon, Loader2 } from 'lucide-react';
import { useZen } from '@/lib/zen/store';
import { runJavaScript, runPython, isPyodideLoaded } from '@/lib/zen/executor';
import { readRepo, readRepoFile, deobfuscateJS } from '@/lib/zen/tools';
import { engineRespond } from '@/lib/zen/engine';
import { SEASONS } from '@/lib/zen/themes';
import * as fb from '@/lib/zen/firebase';

type Line = { kind: 'in' | 'out' | 'err' | 'ok'; text: string };

const HELP = `Zen AI Terminal — commands

  help                    this list
  clear                   wipe the screen
  model [mini|think|pro]  view or switch the chat model
  theme [auto|name]       view or set live theme (auto, thanksgiving, christmas,
                          newyear, halloween, valentine, summer, default)
  tokens / daily          token balance / claim daily grant
  memory list|add|clear   your long-term memory
  quote                   a thought to sit with
  zen <message>           talk to the built-in brain right here

  run js <code>           execute JavaScript in a sandboxed worker (real)
  run py <code>           execute Python via Pyodide (real, first run downloads ~10MB)
  sandbox <preset>        open the sandbox with a preset: snake, catch, calc, todo
  sandbox html <code>     open the sandbox with your HTML

  git read <owner/repo>   read a public GitHub repo (real fetch)
  git file <owner/repo> <path>   fetch one file's contents
  deobf <js code>         beautify + analyze obfuscated JavaScript (real)

  connect <service>       roblox, discord, vscode, github — bridge status
  download <1|2|3>        install an on-device AI model (needs WebGPU)
  sysinfo / date / whoami / echo <text>

  admin users|ban|unban|grant    (Firebase admins only)`;

export function TerminalPanel() {
  const [lines, setLines] = useState<Line[]>([
    { kind: 'ok', text: 'Zen AI Terminal v1.0 — real execution, local-only. Type `help`.' },
  ]);
  const [input, setInput] = useState('');
  const [history, setHistory] = useState<string[]>([]);
  const [histIdx, setHistIdx] = useState(-1);
  const [busy, setBusy] = useState(false);
  const outRef = useRef<HTMLDivElement>(null);
  const inRef = useRef<HTMLInputElement>(null);
  const season = useZen((s) => s.season);
  const accent = useZen((s) => s.settings.accent) || '#8b5cf6';

  const print = (...ls: Line[]) => setLines((prev) => [...prev, ...ls].slice(-400));

  useEffect(() => {
    outRef.current?.scrollTo({ top: outRef.current.scrollHeight });
  }, [lines]);

  useEffect(() => {
    if (inRef.current) inRef.current.focus();
  }, []);

  const execCommand = async (raw: string) => {
    const cmd = raw.trim();
    if (!cmd) return;
    print({ kind: 'in', text: cmd });
    const [head, ...rest] = cmd.split(/\s+/);
    const arg = rest.join(' ');

    switch (head) {
      case 'help':
        print({ kind: 'out', text: HELP });
        break;
      case 'clear':
        setLines([]);
        break;
      case 'about':
        print({ kind: 'out', text: 'Zen AI — on-device assistant. 3 minds, real tools, zero cloud brain.' });
        break;
      case 'whoami': {
        const u = useZen.getState().user;
        print({ kind: 'out', text: `${u?.name} (${u?.email}) — role: ${u?.role}, mode: ${useZen.getState().fbMode === 'live' ? 'firebase cloud' : 'local'}` });
        break;
      }
      case 'date':
        print({ kind: 'out', text: new Date().toString() });
        break;
      case 'echo':
        print({ kind: 'out', text: arg });
        break;
      case 'sysinfo': {
        const nav = navigator as any;
        const gpu = 'gpu' in nav;
        print({
          kind: 'out',
          text: [
            `device:    ${nav.userAgent.slice(0, 80)}`,
            `cores:     ${nav.hardwareConcurrency || '?'} · memory: ${nav.deviceMemory || '?'}GB`,
            `webgpu:    ${gpu ? 'available' : 'not available'}`,
            `pyodide:   ${isPyodideLoaded() ? 'loaded' : 'not loaded (downloads on first py run)'}`,
            `engine:    ${useZen.getState().engine.status}`,
            `season:    ${season}`,
            `tokens:    ${useZen.getState().tokens.balance}`,
          ].join('\n'),
        });
        break;
      }
      case 'model': {
        if (rest[0] && ['mini', 'think', 'pro'].includes(rest[0])) {
          const id = useZen.getState().activeChatId;
          if (id) useZen.getState().setChatMode(id, rest[0] as any);
          print({ kind: 'ok', text: `chat model → ${rest[0]}` });
        } else {
          const id = useZen.getState().activeChatId;
          const m = useZen.getState().chats.find((c) => c.id === id)?.mode || '(no chat)';
          print({ kind: 'out', text: `current: ${m} — try: model mini | think | pro` });
        }
        break;
      }
      case 'theme': {
        const valid = ['auto', ...Object.keys(SEASONS)];
        if (!rest[0]) {
          print({ kind: 'out', text: `current: ${useZen.getState().settings.themeOverride || 'auto'} (${season}) — options: ${valid.join(', ')}` });
        } else if (valid.includes(rest[0])) {
          useZen.getState().updateSettings({ themeOverride: rest[0] === 'auto' ? null : rest[0] });
          useZen.getState().refreshSeason();
          print({ kind: 'ok', text: `theme → ${rest[0]}` });
        } else {
          print({ kind: 'err', text: `unknown theme. options: ${valid.join(', ')}` });
        }
        break;
      }
      case 'tokens':
        print({ kind: 'out', text: `balance: ${useZen.getState().tokens.balance} (daily +500, claim with \`daily\`)` });
        break;
      case 'daily': {
        const ok = useZen.getState().claimDaily();
        print(ok ? { kind: 'ok', text: '+500 tokens claimed.' } : { kind: 'err', text: 'Already claimed today.' });
        break;
      }
      case 'memory': {
        const sub = rest[0];
        const st = useZen.getState();
        if (sub === 'list') {
          print({ kind: 'out', text: st.memory.length ? st.memory.map((m) => `- ${m.text}`).join('\n') : '(memory is empty)' });
        } else if (sub === 'add') {
          const text = rest.slice(1).join(' ');
          if (text) { st.addMemory(text); print({ kind: 'ok', text: 'remembered.' }); }
        } else if (sub === 'clear') {
          st.clearMemory();
          print({ kind: 'ok', text: 'memory wiped.' });
        } else {
          print({ kind: 'out', text: 'usage: memory list | memory add <text> | memory clear' });
        }
        break;
      }
      case 'quote': {
        const r = await engineRespond('quote', { mode: 'mini', memory: [], userName: 'friend', history: [] });
        print({ kind: 'ok', text: r.content.replace(/\*\*/g, '') });
        break;
      }
      case 'zen': {
        if (!arg) { print({ kind: 'err', text: 'usage: zen <message>' }); break; }
        setBusy(true);
        try {
          const st = useZen.getState();
          const reply = await engineRespond(arg, {
            mode: 'pro', memory: st.memory, userName: st.user?.name || 'friend', history: [],
          });
          print({ kind: 'out', text: reply.content.replace(/\*\*/g, '') });
        } finally {
          setBusy(false);
        }
        break;
      }
      case 'run': {
        if (rest[0] === 'js') {
          const code = rest.slice(1).join(' ');
          if (!code) { print({ kind: 'err', text: 'usage: run js console.log(2+2)' }); break; }
          setBusy(true);
          const r = await runJavaScript(code);
          print(r.ok ? { kind: 'ok', text: r.output } : { kind: 'err', text: `${r.error}\n${r.output}` });
          setBusy(false);
        } else if (rest[0] === 'py') {
          const code = rest.slice(1).join(' ');
          if (!code) { print({ kind: 'err', text: 'usage: run py print(2+2)' }); break; }
          setBusy(true);
          print({ kind: 'out', text: isPyodideLoaded() ? 'running…' : 'first run: loading Python runtime…' });
          const r = await runPython(code, (s) => print({ kind: 'out', text: s }));
          print(r.ok ? { kind: 'ok', text: r.output } : { kind: 'err', text: `${r.error}\n${r.output}` });
          setBusy(false);
        } else {
          print({ kind: 'err', text: 'usage: run js <code>  |  run py <code>' });
        }
        break;
      }
      case 'sandbox': {
        const st = useZen.getState();
        if (!rest[0]) { print({ kind: 'err', text: 'usage: sandbox <snake|catch|calc|todo>  |  sandbox html <code>' }); break; }
        if (rest[0] === 'html' || ['<'].includes(rest[0][0])) {
          const code = rest[0] === 'html' ? rest.slice(1).join(' ') : rest.join(' ');
          st.setSandboxInput({ tab: 'html', code });
        } else if (['snake', 'catch', 'calc', 'todo'].includes(rest[0])) {
          st.setSandboxInput({ tab: 'html', code: 'PRESET:' + rest[0] });
        } else {
          st.setSandboxInput({ tab: 'js', code: rest.join(' ') });
        }
        st.setPanel('sandbox');
        print({ kind: 'ok', text: 'sandbox opened →' });
        break;
      }
      case 'git': {
        if (rest[0] === 'read' && rest[1]) {
          setBusy(true);
          try {
            const info = await readRepo(rest[1]);
            print({
              kind: 'ok',
              text: `${info.full_name} ⭐${info.stars} · ${info.language}\n${info.description}\nfiles: ${info.fileCount}\ntop: ${info.topFiles.slice(0, 10).join(', ')}`,
            });
          } catch (e: any) {
            print({ kind: 'err', text: e.message });
          }
          setBusy(false);
        } else if (rest[0] === 'file' && rest[2]) {
          setBusy(true);
          try {
            const content = await readRepoFile(rest[1], rest.slice(2).join(' '));
            print({ kind: 'out', text: content.split('\n').slice(0, 50).join('\n') + (content.split('\n').length > 50 ? `\n… (${content.split('\n').length} lines total)` : '') });
          } catch (e: any) {
            print({ kind: 'err', text: e.message });
          }
          setBusy(false);
        } else {
          print({ kind: 'err', text: 'usage: git read owner/repo  |  git file owner/repo path/to/file.js' });
        }
        break;
      }
      case 'deobf': {
        const code = arg;
        if (!code) { print({ kind: 'err', text: 'usage: deobf <javascript code>' }); break; }
        setBusy(true);
        try {
          const r = await deobfuscateJS(code);
          print({ kind: 'ok', text: `beautified: ${r.stats.lines} lines (was ${r.stats.chars} chars, longest line ${r.stats.longestLine})` });
          if (r.suspicious.length) print({ kind: 'err', text: '⚠ suspicious: ' + r.suspicious.join(' · ') });
          print({ kind: 'out', text: r.beautified.split('\n').slice(0, 40).join('\n') });
        } catch (e: any) {
          print({ kind: 'err', text: e.message });
        }
        setBusy(false);
        break;
      }
      case 'connect': {
        const bridges: Record<string, string> = {
          roblox: 'Roblox Studio bridge — needs the Zen Bridge desktop agent installed on the same machine (see guide §7). The web app cannot attach to Studio by itself; the handshake will stay pending until the agent answers.',
          discord: 'Discord bridge — requires a bot token registered in Firebase Remote Config. Design doc is in the guide.',
          vscode: 'VS Code bridge — pair via `zen connect` inside the Zen Companion extension. Not bundled with this build.',
          github: 'GitHub tooling is built-in: try `git read facebook/react` or `git file owner/repo src/index.js`.',
        };
        print(bridges[rest[0]] ? { kind: 'out', text: bridges[rest[0]] } : { kind: 'err', text: 'unknown service. try: roblox | discord | vscode | github' });
        break;
      }
      case 'download': {
        const idx = parseInt(rest[0] || '', 10);
        const list = ['Qwen2.5-0.5B-Instruct-q4f16_1-MLC', 'Llama-3.2-1B-Instruct-q4f16_1-MLC', 'Qwen2.5-1.5B-Instruct-q4f16_1-MLC'];
        if (!idx || idx < 1 || idx > 3) { print({ kind: 'err', text: 'usage: download <1|2|3> — 1: Qwen 0.5B (~500MB), 2: Llama 1B (~900MB), 3: Qwen 1.5B (~1.4GB)' }); break; }
        setBusy(true);
        print({ kind: 'out', text: `downloading ${list[idx - 1]}… watch Settings → AI Engine for the progress bar.` });
        await useZen.getState().downloadModel(list[idx - 1]);
        const st = useZen.getState().engine;
        print(st.status === 'ready' ? { kind: 'ok', text: 'model installed — brain is now on-device.' } : { kind: 'err', text: st.error || 'download did not finish' });
        setBusy(false);
        break;
      }
      case 'admin': {
        if (useZen.getState().fbMode !== 'live') {
          print({ kind: 'err', text: 'admin commands need Firebase cloud mode (Settings → Firebase).' });
          break;
        }
        const sub = rest[0];
        if (sub === 'users') {
          const users = await fb.listUsers();
          print({ kind: 'out', text: users.map((u) => `${u.status === 'banned' ? '⛔' : '✅'} ${u.email} — ${u.role}`).join('\n') || '(no users yet)' });
        } else if (sub === 'ban' && rest[1]) {
          const u = await fb.findUserByEmail(rest[1]);
          if (u) { await fb.setUserStatus(u.uid, 'banned', rest.slice(2).join(' ') || 'banned via terminal'); print({ kind: 'ok', text: `banned ${u.email}` }); }
          else print({ kind: 'err', text: 'user not found' });
        } else if (sub === 'unban' && rest[1]) {
          const u = await fb.findUserByEmail(rest[1]);
          if (u) { await fb.setUserStatus(u.uid, 'active'); print({ kind: 'ok', text: `unbanned ${u.email}` }); }
          else print({ kind: 'err', text: 'user not found' });
        } else if (sub === 'grant' && rest[2]) {
          const u = await fb.findUserByEmail(rest[1]);
          if (u) { await fb.grantTokens(u.uid, parseInt(rest[2], 10) || 0); print({ kind: 'ok', text: `granted ${rest[2]} tokens to ${u.email}` }); }
          else print({ kind: 'err', text: 'user not found' });
        } else {
          print({ kind: 'err', text: 'usage: admin users | admin ban <email> [reason] | admin unban <email> | admin grant <email> <amount>' });
        }
        break;
      }
      default:
        print({ kind: 'err', text: `command not found: ${head} — type \`help\`` });
    }
  };

  const onSubmit = async () => {
    const cmd = input;
    setInput('');
    setHistory((h) => [cmd, ...h].slice(0, 50));
    setHistIdx(-1);
    await execCommand(cmd);
  };

  const onKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      onSubmit();
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      const next = Math.min(histIdx + 1, history.length - 1);
      if (next >= 0) { setHistIdx(next); setInput(history[next]); }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      const next = histIdx - 1;
      if (next < 0) { setHistIdx(-1); setInput(''); }
      else { setHistIdx(next); setInput(history[next]); }
    }
  };

  return (
    <motion.div
      initial={{ y: 60, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      exit={{ y: 60, opacity: 0 }}
      className="fixed bottom-0 left-0 right-0 z-50 md:left-[280px] h-[46vh] min-h-[320px] border-t border-white/15 bg-black/85 backdrop-blur-2xl flex flex-col"
    >
      <div className="flex items-center justify-between px-4 h-11 border-b border-white/10 shrink-0">
        <div className="flex items-center gap-2 text-sm text-white/70">
          <TermIcon className="w-4 h-4" style={{ color: accent }} />
          Zen Terminal <span className="text-white/30 text-xs">— real js / py / git</span>
        </div>
        <Button variant="ghost" size="icon" onClick={() => useZen.getState().setPanel(null)} className="h-8 w-8 text-white/50 hover:text-white" aria-label="Close terminal">
          <X className="w-4 h-4" />
        </Button>
      </div>

      <div ref={outRef} className="flex-1 overflow-y-auto zen-scroll px-4 py-3 font-mono text-[12px] leading-relaxed">
        {lines.map((l, i) => (
          <div
            key={i}
            className={`whitespace-pre-wrap break-words ${
              l.kind === 'in' ? 'text-emerald-300' : l.kind === 'err' ? 'text-red-300' : l.kind === 'ok' ? 'text-white/90' : 'text-white/60'
            }`}
          >
            {l.kind === 'in' ? <span className="text-white/40">zen@device:~$ </span> : null}
            {l.text}
          </div>
        ))}
        {busy && (
          <div className="flex items-center gap-2 text-white/40 mt-1">
            <Loader2 className="w-3 h-3 animate-spin" /> working…
          </div>
        )}
      </div>

      <div className="flex items-center gap-2 px-4 h-12 border-t border-white/10 shrink-0">
        <span className="font-mono text-xs text-white/40 shrink-0">zen@device:~$</span>
        <input
          ref={inRef}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={onKeyDown}
          className="flex-1 bg-transparent font-mono text-sm text-white outline-none placeholder:text-white/25"
          placeholder="type a command… (help)"
          aria-label="Terminal input"
          spellCheck={false}
        />
      </div>
    </motion.div>
  );
}
