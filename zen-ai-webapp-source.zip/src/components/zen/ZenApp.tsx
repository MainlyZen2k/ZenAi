'use client';

// ZenApp root: auth gate → ban screen → main shell (sidebar, chat, composer,
// terminal/sandbox/settings/admin panels) + season background + CSS vars.

import { useEffect, useRef } from 'react';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { AnimatePresence } from 'framer-motion';
import { Menu, Sparkles, Ban as BanIcon } from 'lucide-react';
import { useZen } from '@/lib/zen/store';
import { SEASONS } from '@/lib/zen/themes';
import { SeasonBackground } from './SeasonBackground';
import { AuthScreen } from './AuthScreen';
import { Sidebar } from './Sidebar';
import { ChatArea } from './ChatArea';
import { Composer } from './Composer';
import { TerminalPanel } from './TerminalPanel';
import { SandboxPanel } from './SandboxPanel';
import { SettingsPanel } from './SettingsPanel';
import { AdminPanel } from './AdminPanel';
import { ZenLogo } from './ZenLogo';
import {
  watchAuth, ensureUserProfile, logLogin, refreshBanStatus, hasConfigLive, initFirebase,
} from '@/lib/zen/firebase';
import type { FBConfig } from '@/lib/zen/types';

export function ZenApp() {
  const user = useZen((s) => s.user);
  const season = useZen((s) => s.season);
  const sidebarOpen = useZen((s) => s.sidebarOpen);
  const panel = useZen((s) => s.panel);
  const info = SEASONS[season] || SEASONS.default;
  const accent = useZen((s) => s.settings.accent) || info.accent;
  const { toast } = useToast();
  const bootRef = useRef(false);

  // boot: init store, firebase, auth listener, ban watcher
  useEffect(() => {
    if (bootRef.current) return;
    bootRef.current = true;
    useZen.getState().init();
    if (typeof window !== 'undefined' && window.innerWidth < 768) {
      useZen.getState().setSidebar(false);
    }

    const saved = localStorage.getItem('zen-fb-config');
    if (saved) {
      try {
        initFirebase(JSON.parse(saved) as FBConfig);
      } catch {
        /* bad config stays local */
      }
    }

    if (hasConfigLive()) {
      let loggedThisSession = false;
      watchAuth(async (uid, email, name) => {
        if (!uid) {
          useZen.getState().setUser(null);
          return;
        }
        try {
          const profile = await ensureUserProfile(uid, email, name);
          if (profile.status === 'banned') {
            useZen.getState().setUser(profile);
            return;
          }
          useZen.getState().setUser(profile);
          useZen.getState().setFbMode('live');
          if (!loggedThisSession) {
            loggedThisSession = true;
            logLogin(uid, { platform: navigator.platform || 'web', ua: navigator.userAgent.slice(0, 180) }).catch(() => {});
            toast({ title: `Welcome, ${profile.name}`, description: profile.role === 'admin' ? 'Admin account — admin panel is in the sidebar.' : 'Cloud sync active.' });
          }
          // periodic ban re-check (60s)
          const interval = setInterval(async () => {
            const fresh = await refreshBanStatus(uid);
            if (fresh && fresh.status === 'banned') {
              useZen.getState().setUser(fresh);
              clearInterval(interval);
            } else if (fresh && useZen.getState().user?.status === 'banned') {
              useZen.getState().setUser(fresh);
            }
          }, 60000);
        } catch (err: any) {
          useZen.getState().setFbMode('error', err?.message || 'profile load failed');
          useZen.getState().signInDemo();
        }
      });
    } else {
      // No firebase configured — auto local mode after a beat (lets user read the auth screen)
      const t = setTimeout(() => {
        if (!useZen.getState().user) useZen.getState().signInDemo();
      }, 600);
      return () => clearTimeout(t);
    }
  }, [toast]);

  // apply accent + season CSS vars to document
  useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty('--zen-accent', accent);
    root.style.setProperty('--zen-glow', info.glow);
    document.body.style.background = info.bgFrom;
  }, [accent, info.glow, info.bgFrom]);

  // create the first chat once user exists
  useEffect(() => {
    if (user && useZen.getState().chats.length === 0 && !useZen.getState().activeChatId) {
      useZen.getState().newChat();
    }
  }, [user]);

  // banned screen
  if (user?.status === 'banned') {
    return (
      <div className="min-h-dvh flex items-center justify-center p-4">
        <SeasonBackground />
        <div className="relative z-10 max-w-md w-full rounded-3xl border border-red-500/30 bg-black/60 backdrop-blur-2xl p-7 text-center space-y-4">
          <BanIcon className="w-12 h-12 mx-auto text-red-400" />
          <h1 className="text-2xl font-bold text-white">Account suspended</h1>
          <p className="text-sm text-white/60">
            {user.banReason ? `Reason: ${user.banReason}` : 'Your account has been suspended by an administrator.'}
          </p>
          <p className="text-xs text-white/40">If you believe this is a mistake, contact the Zen AI admin. You can sign out below.</p>
          <Button
            variant="outline"
            className="w-full bg-white/5 border-white/15 text-white"
            onClick={() => useZen.getState().logout()}
          >
            Sign out
          </Button>
        </div>
      </div>
    );
  }

  // auth screen
  if (!user) {
    return (
      <div className="min-h-dvh">
        <SeasonBackground />
        <AuthScreen />
      </div>
    );
  }

  // main shell
  return (
    <div className="h-dvh flex overflow-hidden relative">
      <SeasonBackground />
      <Sidebar />

      <div className="flex-1 flex flex-col min-w-0 relative z-10">
        {/* top bar */}
        <header className="flex items-center gap-3 px-4 h-14 border-b border-white/10 bg-black/20 backdrop-blur shrink-0">
          {!sidebarOpen && (
            <>
              <Button variant="ghost" size="icon" onClick={() => useZen.getState().setSidebar(true)} className="text-white/60 hover:text-white" aria-label="Open sidebar">
                <Menu className="w-5 h-5" />
              </Button>
              <ZenLogo size={26} accent={accent} />
            </>
          )}
          <div className="flex-1 min-w-0">
            <h1 className="text-sm font-semibold text-white truncate">
              {useZen.getState().chats.find((c) => c.id === useZen.getState().activeChatId)?.title || 'Zen AI'}
            </h1>
          </div>
          <div className="hidden sm:flex items-center gap-1.5 text-[11px] text-white/40">
            <Sparkles className="w-3 h-3" style={{ color: accent }} />
            {useZen.getState().engine.status === 'ready' ? 'on-device brain' : 'built-in brain'}
          </div>
          <div className="text-[11px] text-white/35">{info.emoji}</div>
        </header>

        <ChatArea />
        <Composer />
      </div>

      {/* panels */}
      <AnimatePresence>
        {panel === 'terminal' && <TerminalPanel key="term" />}
        {panel === 'sandbox' && <SandboxPanel key="sand" />}
        {(panel === 'settings' || panel === 'memory') && (
          <SettingsPanel key={panel === 'memory' ? 'mem' : 'set'} initialTab={panel === 'memory' ? 'memory' : 'profile'} />
        )}
        {panel === 'admin' && <AdminPanel key="admin" />}
      </AnimatePresence>
    </div>
  );
}
