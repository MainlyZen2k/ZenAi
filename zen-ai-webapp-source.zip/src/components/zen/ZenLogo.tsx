'use client';

// Zen AI logo — an enso (zen brush circle) with a "Z". Recolors via accent,
// design never changes. Used in sidebar, auth screen and chat avatars.

export function ZenLogo({ size = 36, accent = '#8b5cf6', className = '' }: {
  size?: number;
  accent?: string;
  className?: string;
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      className={className}
      aria-label="Zen AI logo"
    >
      <defs>
        <linearGradient id="zen-g" x1="8" y1="8" x2="56" y2="56" gradientUnits="userSpaceOnUse">
          <stop stopColor={accent} />
          <stop offset="1" stopColor={accent} stopOpacity="0.45" />
        </linearGradient>
      </defs>
      <rect width="64" height="64" rx="16" fill={accent} fillOpacity="0.12" />
      <path
        d="M46.5 18.5C42 13.6 34.9 12 28.8 14.4C19.5 18 14.7 28.7 18.3 38C21.9 47.3 32.6 52.1 41.9 48.5C44.6 47.4 46.9 45.7 48.7 43.6"
        stroke="url(#zen-g)"
        strokeWidth="5"
        strokeLinecap="round"
      />
      <path
        d="M25 24H39L25 40H39"
        stroke={accent}
        strokeWidth="4.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
