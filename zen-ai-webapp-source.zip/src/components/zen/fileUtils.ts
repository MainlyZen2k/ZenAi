'use client';

// Shared file helpers for the composer.

export async function readTextFile(file: File): Promise<string> {
  const raw = await file.text();
  return raw.slice(0, 24000);
}
