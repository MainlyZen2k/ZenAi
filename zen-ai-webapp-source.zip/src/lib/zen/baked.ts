// ============================================================
//  ZEN AI — OWNER SETUP FILE (the only file you may need to edit)
// ============================================================
//
// 1) FIREBASE — paste your full apiKey below (the one long string starting
//    with "AIza..." from Firebase console -> Project settings -> General ->
//    Your apps -> Web app -> Config). Everything else is already filled in.
//    Once apiKey is real, EVERY visitor gets a clean login screen — no
//    "Connect Firebase" paste screen, nothing to configure. This is safe:
//    the Firebase web config is public by design, security lives in your
//    Firestore rules, not in this file.
//
// 2) ADMIN — in src/lib/zen/firebase.ts put your own email inside
//    ADMIN_EMAILS: ["you@example.com"] — that account gets the Admin Panel.
//    Everyone else only ever sees the normal user app.
//
// 3) AI KEY (optional) — leave OWNER_CLOUD_KEY empty and each user enters
//    their own free Gemini key in Settings -> AI Engine (recommended).
//    Put a key there instead and every user's Mini/Think/Pro answers run on
//    YOUR shared free quota with zero setup for them.
//
// Advanced: environment variables (NEXT_PUBLIC_FB_* / NEXT_PUBLIC_CLOUD_*)
// override whatever is written here — handy on Vercel without re-uploading.

import type { CloudProvider, CloudSettings, FBConfig } from './types';

// ---------------- owner constants (edit these) ----------------

const OWNER_FB_CONFIG: FBConfig = {
  apiKey: 'AIzaSyBR8US1SkDARmEldgGAO3P3IN26H2OFMa4',
  authDomain: 'zenai-b5e85.firebaseapp.com',
  projectId: 'zenai-b5e85',
  storageBucket: 'zenai-b5e85.firebasestorage.app',
  messagingSenderId: '437762842164',
  appId: '1:437762842164:web:97513baedbb2f4dfa4b461',
};

/** Optional shared AI key. Empty = each user brings their own (recommended). */
const OWNER_CLOUD_KEY = '';
const OWNER_CLOUD_PROVIDER: CloudProvider = 'gemini';

// ---------------- baked values (no need to touch) ----------------

// A config counts as baked only when the apiKey was actually replaced —
// a leftover placeholder would silently break sign-in, so we ignore it.
function looksBaked(c: FBConfig): boolean {
  return Boolean(c.apiKey && c.projectId && c.appId) && !/paste|your_|todo|xxxx/i.test(c.apiKey);
}

const envFB: FBConfig | null = (() => {
  const apiKey = process.env.NEXT_PUBLIC_FB_API_KEY || '';
  const projectId = process.env.NEXT_PUBLIC_FB_PROJECT_ID || '';
  const appId = process.env.NEXT_PUBLIC_FB_APP_ID || '';
  if (!apiKey || !projectId || !appId) return null;
  return {
    apiKey,
    authDomain: process.env.NEXT_PUBLIC_FB_AUTH_DOMAIN || `${projectId}.firebaseapp.com`,
    projectId,
    storageBucket: process.env.NEXT_PUBLIC_FB_STORAGE_BUCKET || `${projectId}.firebasestorage.app`,
    messagingSenderId: process.env.NEXT_PUBLIC_FB_SENDER_ID || '',
    appId,
  };
})();

// Deployment env vars win; otherwise the constants above are used as-is.
export const BAKED_FB_CONFIG: FBConfig | null = (() => {
  if (envFB && looksBaked(envFB)) return envFB;
  return looksBaked(OWNER_FB_CONFIG) ? OWNER_FB_CONFIG : null;
})();

export const BAKED_CLOUD: Pick<CloudSettings, 'enabled' | 'provider' | 'apiKey' | 'baseUrl'> = {
  enabled: Boolean(OWNER_CLOUD_KEY || process.env.NEXT_PUBLIC_CLOUD_API_KEY),
  provider: OWNER_CLOUD_KEY
    ? OWNER_CLOUD_PROVIDER
    : (process.env.NEXT_PUBLIC_CLOUD_PROVIDER as CloudProvider) || 'gemini',
  apiKey: OWNER_CLOUD_KEY || process.env.NEXT_PUBLIC_CLOUD_API_KEY || '',
  baseUrl: process.env.NEXT_PUBLIC_CLOUD_BASE_URL || '',
};
