// Bake-in support: deployment-time configuration via environment variables.
//
// Set NEXT_PUBLIC_FB_* in your hosting dashboard (Vercel -> Settings ->
// Environment Variables, or a .env.local file for local dev) and every user
// gets a clean login screen — no "Connect Firebase" step, nothing to paste.
// Optional NEXT_PUBLIC_CLOUD_* preloads the AI key so Mini / Think / Pro all
// answer with a real model out of the box.
//
// Note: NEXT_PUBLIC_ values are visible in the shipped JS bundle. That is
// fine for the Firebase web config (security lives in the Firestore rules,
// not the key), but only bake a cloud key you are comfortable sharing —
// everyone using the app draws from that one shared quota.

import type { CloudProvider, CloudSettings, FBConfig } from './types';

export const BAKED_FB_CONFIG: FBConfig | null = (() => {
  const apiKey = process.env.NEXT_PUBLIC_FB_API_KEY || '';
  const projectId = process.env.NEXT_PUBLIC_FB_PROJECT_ID || '';
  const appId = process.env.NEXT_PUBLIC_FB_APP_ID || '';
  if (!apiKey || !projectId || !appId) return null;
  return {
    apiKey,
    authDomain: process.env.NEXT_PUBLIC_FB_AUTH_DOMAIN || `${projectId}.firebaseapp.com`,
    projectId,
    storageBucket: process.env.NEXT_PUBLIC_FB_STORAGE_BUCKET || `${projectId}.appspot.com`,
    messagingSenderId: process.env.NEXT_PUBLIC_FB_SENDER_ID || '',
    appId,
  };
})();

export const BAKED_CLOUD: Pick<CloudSettings, 'enabled' | 'provider' | 'apiKey' | 'baseUrl'> = {
  enabled: Boolean(process.env.NEXT_PUBLIC_CLOUD_API_KEY),
  provider: (process.env.NEXT_PUBLIC_CLOUD_PROVIDER as CloudProvider) || 'gemini',
  apiKey: process.env.NEXT_PUBLIC_CLOUD_API_KEY || '',
  baseUrl: process.env.NEXT_PUBLIC_CLOUD_BASE_URL || '',
};
