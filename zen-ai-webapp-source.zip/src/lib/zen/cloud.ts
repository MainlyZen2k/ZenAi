// Zen cloud brain: real LLM APIs with user-supplied keys.
// Providers: Google AI Studio Gemini (free tier, no credit card),
// OpenRouter (free model variants), and any OpenAI-compatible endpoint.
// The key never leaves this device except to the chosen provider.

import type { CloudProvider, CloudSettings, ModelMode } from './types';
import type { Source } from './tools';

export type CloudModelIds = 'modelMini' | 'modelThink' | 'modelPro';

export interface CloudProviderInfo {
  id: CloudProvider;
  label: string;
  blurb: string;
  keyUrl: string;
  keyUrlLabel: string;
  defaultModels: Record<CloudModelIds, string>;
  needsBaseUrl?: boolean;
  baseUrlPlaceholder?: string;
}

export const CLOUD_PROVIDERS: Record<CloudProvider, CloudProviderInfo> = {
  gemini: {
    id: 'gemini',
    label: 'Gemini (Google AI Studio)',
    blurb: 'Free tier with just a Google account — no credit card. Best pick for most people.',
    keyUrl: 'https://aistudio.google.com/apikey',
    keyUrlLabel: 'Get a free Gemini key',
    defaultModels: {
      modelMini: 'gemini-2.5-flash-lite',
      modelThink: 'gemini-2.5-flash',
      modelPro: 'gemini-2.5-flash',
    },
  },
  openrouter: {
    id: 'openrouter',
    label: 'OpenRouter',
    blurb: 'One key, many models. Models ending in ":free" cost nothing (~50 requests/day).',
    keyUrl: 'https://openrouter.ai/keys',
    keyUrlLabel: 'Get an OpenRouter key',
    defaultModels: {
      modelMini: 'meta-llama/llama-3.3-70b-instruct:free',
      modelThink: 'meta-llama/llama-3.3-70b-instruct:free',
      modelPro: 'meta-llama/llama-3.3-70b-instruct:free',
    },
  },
  custom: {
    id: 'custom',
    label: 'Custom (OpenAI-compatible)',
    blurb: 'Any OpenAI-style endpoint: Groq, Together, a self-hosted vLLM/Ollama server…',
    keyUrl: '',
    keyUrlLabel: '',
    needsBaseUrl: true,
    baseUrlPlaceholder: 'https://api.groq.com/openai/v1',
    defaultModels: {
      modelMini: 'llama-3.1-8b-instant',
      modelThink: 'llama-3.1-8b-instant',
      modelPro: 'llama-3.1-8b-instant',
    },
  },
};

export function defaultModelsFor(p: CloudProvider): Pick<CloudSettings, CloudModelIds> {
  return { ...CLOUD_PROVIDERS[p].defaultModels };
}

export interface CloudChatMessage {
  role: 'user' | 'assistant';
  content: string;
  images?: string[]; // data URLs, attached to the newest user message
}

export interface CloudStreamEvent {
  type: 'text' | 'thought';
  value: string;
}

export interface CloudStreamOpts {
  provider: CloudProvider;
  apiKey: string;
  model: string;
  baseUrl?: string;
  system: string;
  messages: CloudChatMessage[];
  mode: ModelMode;
  signal?: AbortSignal;
}

const MODE_PARAMS: Record<ModelMode, { temperature: number; maxTokens: number }> = {
  mini: { temperature: 0.6, maxTokens: 1024 },
  think: { temperature: 0.7, maxTokens: 2048 },
  pro: { temperature: 0.6, maxTokens: 3072 },
};

function friendlyError(status: number, detail: string): string {
  const d = detail.slice(0, 220);
  if (status === 400 && /api key|api_key/i.test(detail)) return 'That API key looks invalid. Double-check it in Settings → AI Engine.';
  if (status === 401 || status === 403) return `Key rejected (${status}). Check the key is active and for the right provider. ${d}`;
  if (status === 404) return `Model not found (${d}). Open Settings → AI Engine and pick a model the free tier offers.`;
  if (status === 429) return 'Free quota used up for now (rate limit). Wait a minute — or switch modes: Mini uses the smallest quota. Falling back to the built-in brain.';
  if (status >= 500) return `Provider hiccup (${status}). Try again in a moment.`;
  return `API error ${status}: ${d}`;
}

async function readSSE(
  res: Response,
  onEvent: (payload: string) => void,
  signal?: AbortSignal
): Promise<void> {
  const reader = res.body?.getReader();
  if (!reader) throw new Error('Streaming not supported by this browser/context');
  const decoder = new TextDecoder();
  let buf = '';
  while (true) {
    if (signal?.aborted) {
      try { await reader.cancel(); } catch { /* noop */ }
      return;
    }
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    const lines = buf.split('\n');
    buf = lines.pop() || '';
    for (const line of lines) {
      const t = line.trim();
      if (!t.startsWith('data:')) continue;
      const payload = t.slice(5).trim();
      if (!payload || payload === '[DONE]') continue;
      onEvent(payload);
    }
  }
}

// ---------------- Gemini ----------------

function geminiParts(content: string, images?: string[]): any[] {
  const parts: any[] = [];
  for (const dataUrl of images || []) {
    const m = dataUrl.match(/^data:(.+?);base64,(.*)$/);
    if (m) parts.push({ inline_data: { mime_type: m[1], data: m[2] } });
  }
  parts.push({ text: content });
  return parts;
}

// Gemini streams via SSE with thought summaries; bridge events into a
// queue-based async generator so callers can consume one clean stream.
async function* streamGeminiAdapter(opts: CloudStreamOpts): AsyncGenerator<CloudStreamEvent> {
  const url =
    `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(opts.model)}` +
    `:streamGenerateContent?alt=sse&key=${encodeURIComponent(opts.apiKey)}`;
  const params = MODE_PARAMS[opts.mode];
  const body: any = {
    systemInstruction: { parts: [{ text: opts.system }] },
    contents: opts.messages.map((m) => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: geminiParts(m.content, m.images),
    })),
    generationConfig: {
      temperature: params.temperature,
      maxOutputTokens: params.maxTokens,
      thinkingConfig: { includeThoughts: true },
    },
    safetySettings: ['HARM_CATEGORY_HARASSMENT', 'HARM_CATEGORY_HATE_SPEECH', 'HARM_CATEGORY_SEXUALLY_EXPLICIT', 'HARM_CATEGORY_DANGEROUS_CONTENT'].map(
      (category) => ({ category, threshold: 'BLOCK_ONLY_HIGH' })
    ),
  };

  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
    signal: opts.signal,
  });
  if (!res.ok) {
    let detail = '';
    try {
      const j = await res.json();
      detail = j?.error?.message || JSON.stringify(j).slice(0, 220);
    } catch { detail = await res.text().catch(() => ''); }
    throw new Error(friendlyError(res.status, detail));
  }

  const queue: CloudStreamEvent[] = [];
  let done = false;
  let error: unknown = null;
  const pump = readSSE(
    res,
    (payload) => {
      try {
        const chunk = JSON.parse(payload);
        const parts: any[] = chunk?.candidates?.[0]?.content?.parts || [];
        for (const p of parts) {
          if (typeof p.text === 'string' && p.text) {
            queue.push({ type: p.thought ? 'thought' : 'text', value: p.text });
          }
        }
      } catch { /* ignore malformed keepalives */ }
    },
    opts.signal
  )
    .then(() => { done = true; })
    .catch((e) => { error = e; done = true; });

  while (true) {
    if (queue.length) {
      yield queue.shift()!;
      continue;
    }
    if (done) break;
    await new Promise((r) => setTimeout(r, 8));
  }
  await pump.catch(() => {});
  if (error && !opts.signal?.aborted) throw error;
}

// ---------------- OpenAI-compatible (OpenRouter / custom) ----------------

function openAIContent(m: CloudChatMessage): any {
  if (m.images && m.images.length && m.role === 'user') {
    return [
      { type: 'text', text: m.content },
      ...m.images.map((url) => ({ type: 'image_url', image_url: { url } })),
    ];
  }
  return m.content;
}

async function* streamOpenAI(opts: CloudStreamOpts): AsyncGenerator<CloudStreamEvent> {
  const base = (
    opts.provider === 'openrouter'
      ? 'https://openrouter.ai/api/v1'
      : (opts.baseUrl || '').replace(/\/+$/, '')
  ).trim();
  if (!base) throw new Error('No base URL set for the custom provider (Settings → AI Engine).');

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${opts.apiKey}`,
  };
  if (opts.provider === 'openrouter') {
    headers['HTTP-Referer'] = typeof location !== 'undefined' ? location.origin : 'https://zen.ai';
    headers['X-Title'] = 'Zen AI';
  }

  const params = MODE_PARAMS[opts.mode];
  const res = await fetch(`${base}/chat/completions`, {
    method: 'POST',
    headers,
    body: JSON.stringify({
      model: opts.model,
      stream: true,
      temperature: params.temperature,
      max_tokens: params.maxTokens,
      messages: [
        { role: 'system', content: opts.system },
        ...opts.messages.map((m) => ({ role: m.role, content: openAIContent(m) })),
      ],
    }),
    signal: opts.signal,
  });
  if (!res.ok) {
    let detail = '';
    try {
      const j = await res.json();
      detail = j?.error?.message || j?.error?.metadata?.raw || JSON.stringify(j).slice(0, 220);
    } catch { detail = await res.text().catch(() => ''); }
    throw new Error(friendlyError(res.status, detail));
  }

  const queue: CloudStreamEvent[] = [];
  let done = false;
  let error: unknown = null;
  const pump = readSSE(
    res,
    (payload) => {
      try {
        const chunk = JSON.parse(payload);
        const delta = chunk?.choices?.[0]?.delta || {};
        const reasoning = delta.reasoning ?? delta.reasoning_content;
        if (typeof reasoning === 'string' && reasoning) queue.push({ type: 'thought', value: reasoning });
        if (typeof delta.content === 'string' && delta.content) queue.push({ type: 'text', value: delta.content });
      } catch { /* ignore */ }
    },
    opts.signal
  )
    .then(() => { done = true; })
    .catch((e) => { error = e; done = true; });

  while (true) {
    if (queue.length) {
      yield queue.shift()!;
      continue;
    }
    if (done) break;
    await new Promise((r) => setTimeout(r, 8));
  }
  await pump.catch(() => {});
  if (error && !opts.signal?.aborted) throw error;
}

// ---------------- public API ----------------

export function isCloudReady(cloud: { enabled: boolean; provider: CloudProvider; apiKey: string }): boolean {
  return !!(cloud.enabled && cloud.apiKey && cloud.apiKey.trim());
}

export function cloudModelFor(cloud: { provider: CloudProvider; modelMini: string; modelThink: string; modelPro: string }, mode: ModelMode): string {
  const perMode = { mini: cloud.modelMini, think: cloud.modelThink, pro: cloud.modelPro };
  return (perMode[mode] || '').trim() || CLOUD_PROVIDERS[cloud.provider].defaultModels[mode];
}

export function streamCloud(opts: CloudStreamOpts): AsyncGenerator<CloudStreamEvent> {
  return opts.provider === 'gemini' ? streamGeminiAdapter(opts) : streamOpenAI(opts);
}

export async function cloudTestKey(provider: CloudProvider, apiKey: string, baseUrl?: string): Promise<{ ok: boolean; detail: string }> {
  try {
    if (provider === 'gemini') {
      const res = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models?pageSize=1&key=${encodeURIComponent(apiKey)}`
      );
      if (res.ok) return { ok: true, detail: 'Key works — Gemini free tier is live.' };
      let detail = '';
      try { detail = (await res.json())?.error?.message || ''; } catch { /* noop */ }
      return { ok: false, detail: friendlyError(res.status, detail) };
    }
    if (provider === 'openrouter') {
      const res = await fetch('https://openrouter.ai/api/v1/auth/key', {
        headers: { Authorization: `Bearer ${apiKey}` },
      });
      if (res.ok) {
        const j = await res.json().catch(() => null);
        const limit = j?.data?.limit_remaining;
        return { ok: true, detail: `Key works.${typeof limit === 'number' ? ` Free requests left: ${limit}.` : ''}` };
      }
      return { ok: false, detail: friendlyError(res.status, 'Unauthorized — check the key.') };
    }
    // custom: try a models listing; failure is soft (some servers don't expose it)
    const base = (baseUrl || '').replace(/\/+$/, '');
    if (!base) return { ok: false, detail: 'Set the base URL first.' };
    const res = await fetch(`${base}/models`, { headers: { Authorization: `Bearer ${apiKey}` } });
    if (res.ok) return { ok: true, detail: 'Endpoint reachable — models listed OK.' };
    return { ok: false, detail: friendlyError(res.status, 'Endpoint responded with an error.') };
  } catch (err: any) {
    return { ok: false, detail: `Network error: ${String(err?.message || err).slice(0, 140)}` };
  }
}

// ---------------- system prompt ----------------

export function buildCloudSystem(args: {
  mode: ModelMode;
  memoryText: string;
  toolContext: string;
  userName: string;
  provider: CloudProvider;
}): string {
  const today = new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  const base =
    args.mode === 'mini'
      ? 'You are Zen-Mini, the fast mode of the Zen AI app. Answer in 1-3 short sentences unless the user clearly needs more. Friendly, warm, zero fluff.'
      : args.mode === 'think'
        ? 'You are Zen-Think, the reasoning mode of the Zen AI app. Think the problem through carefully, then give a clear, structured answer. Be honest about uncertainty.'
        : 'You are Zen-Pro, the expert mode of the Zen AI app (engineer + analyst). Produce thorough, well-structured answers with markdown. Code must be complete and runnable. State assumptions. Finish non-trivial answers with a short "Self-check:" line that verifies your claims or code.';

  const thinkTags =
    args.mode === 'think' && args.provider !== 'gemini'
      ? ' Start your reply with <thinking>…</thinking> containing 2-6 short reasoning lines, then the final answer outside the tags.'
      : '';

  return [
    `You are Zen AI, built into the Zen AI app used by ${args.userName}.`,
    base + thinkTags,
    `Today is ${today}.`,
    'Use markdown when it helps (code blocks, lists, bold). Never invent facts — say when you are unsure.',
    args.memoryText ? `\nThings you remember about the user:\n${args.memoryText}` : '',
    args.toolContext ? `\nLive tool results you just fetched for this question (treat as current data, cite naturally):\n${args.toolContext}` : '',
  ]
    .filter(Boolean)
    .join('\n');
}

// Strip leftover <thinking> tags if a model ignored instructions,
// routing their content into the thinking trace instead.
export function splitThinkingTags(raw: string): { thinking: string; content: string } {
  const m = raw.match(/<thinking>([\s\S]*?)<\/thinking>/i);
  if (!m) return { thinking: '', content: raw.replace(/<\/?thinking>/gi, '').trimStart() };
  const thinking = m[1].trim();
  const content = (raw.slice(0, m.index) + raw.slice(m.index + m[0].length)).trim();
  return { thinking, content };
}

// Re-export so the store can cite sources set by tool prefetch.
export type { Source };
