// Zen built-in engine: intent classification, math, real date/time, code
// templates, research hooks and mode-specific answer shaping. This is the
// brain that works instantly with zero downloads; the on-device LLM layers
// on top when installed.

import type { MemoryItem, ModelMode, Msg } from './types';
import { research, looksLikeCurrentEvents, type Source } from './tools';
import { DEEP_QUOTES, LIGHT_QUOTES } from './quotes';
import type { ExecResult } from './executor';

export interface EngineCtx {
  mode: ModelMode;
  memory: MemoryItem[];
  userName: string;
  history: Msg[];
  onThinking?: (s: string) => void;
  onMeta?: (s: string) => void;
  onSources?: (s: Source[]) => void;
  runCode?: (code: string, lang: 'js' | 'py') => Promise<ExecResult>;
}

export interface EngineReply {
  content: string;
  thinking?: string;
  sources?: Source[];
  meta?: string;
}

type Intent =
  | 'greeting'
  | 'howareyou'
  | 'thanks'
  | 'quote'
  | 'about'
  | 'help'
  | 'math'
  | 'datetime'
  | 'code'
  | 'research'
  | 'explain'
  | 'smalltalk'
  | 'attachment';

// ---------- intent detection ----------

export function classify(text: string): Intent {
  const t = text.toLowerCase().trim();
  const tNoQ = t.replace(/[?!.]+\s*$/, '');

  if (/^(hi|hello|hey|yo|sup|hiya|good (morning|evening|afternoon))\b[\s!.,]*$/.test(t)) return 'greeting';
  if (/\b(how are you|how's it going|how do you feel|you good)\b/.test(t)) return 'howareyou';
  if (/\b(thanks|thank you|thx|appreciate)\b/.test(t)) return 'thanks';
  if (/\b(quote|motivate me|inspire me|something (deep|wise))\b/.test(t)) return 'quote';
  if (/\b(who are you|what are you|about you|your name|zen\?)\b/.test(t)) return 'about';
  if (/\b(help|what can you do|commands|capabilities)\b/.test(t) && t.length < 60) return 'help';
  if (/\b(what time|what.s the (time|date)|what day|today.s date)\b/.test(t)) return 'datetime';
  const pureMath = /^[\s\d+\-*/().%^x×÷,]*\d[\s\d+\-*/().%^x×÷,]*$/.test(tNoQ);
  const asksMath = (
    /^(what\s+is|what's|whats|calculate|solve|compute)\b/.test(tNoQ) &&
    /[\d)]$/.test(tNoQ) &&
    /\d\s*[+\-*/x×÷^%]\s*\d/.test(tNoQ)
  ) || /\d\s*%\s*of\s*\d/.test(t);
  if (pureMath || asksMath) return 'math';
  if (/\b(create|make|build|write|code|develop|script|program|game|app|website)\b/.test(t) && /\b(python|javascript|js|html|css|game|app|website|function|program|script|code)\b/.test(t)) return 'code';
  if (looksLikeCurrentEvents(t)) return 'research';
  if (/\b(explain|what is|what are|why|how does|how do|difference between|meaning of)\b/.test(t)) return 'explain';
  return 'smalltalk';
}

// ---------- safe math ----------

export function evalMath(raw: string): string | null {
  let expr = raw.toLowerCase();
  expr = expr.replace(/what\s*is|what's|calculate|solve|equals?|please|\?/g, ' ');
  expr = expr.replace(/(\d)\s*% of\s*(\d)/g, '($1/100)*$2');
  expr = expr.replace(/×|x(?=\s*\d)|\*/g, (m, off, s) => (m === 'x' ? '*' : '*'));
  expr = expr.replace(/÷/g, '/');
  expr = expr.replace(/\^/g, '**');
  expr = expr.replace(/,/g, '');
  expr = expr.trim();
  if (!/^[\d+\-*/().\s%]+$/.test(expr)) return null;
  if (!/\d/.test(expr)) return null;
  try {
    // expression is regex-whitelisted to digits/operators only
    const val = new Function(`"use strict"; return (${expr});`)();
    if (typeof val !== 'number' || !isFinite(val)) return null;
    const rounded = Math.round(val * 1e6) / 1e6;
    return `**${expr.replace(/\s+/g, ' ')} = ${rounded}**`;
  } catch {
    return null;
  }
}

// ---------- code templates ----------

const SNAKE_GAME = `<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Zen Snake</title>
<style>
  body{background:#0b0d14;color:#eee;font-family:system-ui;display:flex;flex-direction:column;align-items:center;gap:10px;margin:0;padding:16px}
  canvas{background:#101522;border:2px solid #8b5cf6;border-radius:10px;max-width:100%;touch-action:none}
  #hud{display:flex;gap:20px;font-size:14px;opacity:.9}
  button{background:#8b5cf6;border:0;color:#fff;padding:8px 18px;border-radius:8px;font-weight:600;cursor:pointer}
</style></head>
<body>
  <h2>🐍 Zen Snake</h2>
  <div id="hud"><span>Score: <b id="score">0</b></span><span>Best: <b id="best">0</b></span></div>
  <canvas id="c" width="400" height="400"></canvas>
  <button onclick="location.reload()">Restart</button>
  <p style="opacity:.6;font-size:12px">Arrows / WASD / swipe to move</p>
<script>
const c=document.getElementById('c'),x=c.getContext('2d');
const G=20,W=c.width/G,H=c.height/G;
let snake,dir,food,score=0,best=+(localStorage.getItem('zenSnakeBest')||0),dead=false;
document.getElementById('best').textContent=best;
function reset(){snake=[{x:8,y:10},{x:7,y:10},{x:6,y:10}];dir={x:1,y:0};placeFood();score=0;dead=false;}
function placeFood(){food={x:Math.floor(Math.random()*W),y:Math.floor(Math.random()*H)};
  while(snake.some(s=>s.x===food.x&&s.y===food.y))food={x:Math.floor(Math.random()*W),y:Math.floor(Math.random()*H)};}
function step(){
  if(dead)return;
  const head={x:(snake[0].x+dir.x+W)%W,y:(snake[0].y+dir.y+H)%H};
  if(snake.some(s=>s.x===head.x&&s.y===head.y)){dead=true;best=Math.max(best,score);
    localStorage.setItem('zenSnakeBest',best);document.getElementById('best').textContent=best;draw();return;}
  snake.unshift(head);
  if(head.x===food.x&&head.y===food.y){score++;document.getElementById('score').textContent=score;placeFood();}
  else snake.pop();
  draw();
}
function draw(){
  x.fillStyle='#101522';x.fillRect(0,0,c.width,c.height);
  x.fillStyle='#f43f5e';x.beginPath();x.arc(food.x*G+G/2,food.y*G+G/2,G/2.6,0,7);x.fill();
  snake.forEach((s,i)=>{x.fillStyle=i===0?'#8b5cf6':'rgba(139,92,246,.55)';
    x.beginPath();x.roundRect(s.x*G+1,s.y*G+1,G-2,G-2,5);x.fill();});
  if(dead){x.fillStyle='rgba(0,0,0,.6)';x.fillRect(0,c.height/2-30,c.width,60);
    x.fillStyle='#fff';x.font='bold 22px system-ui';x.textAlign='center';
    x.fillText('Game over — score '+score,c.width/2,c.height/2+8);}
}
let touch=null;
addEventListener('keydown',e=>{const k=e.key.toLowerCase();
  if(k==='arrowup'||k==='w')dir=dir.x!==1?{x:-1,y:0}:dir;
  if(k==='arrowdown'||k==='s')dir=dir.x!==-1?{x:1,y:0}:dir;
  if(k==='arrowleft'||k==='a')dir=dir.y!==1?{x:0,y:-1}:dir;
  if(k==='arrowright'||k==='d')dir=dir.y!==-1?{x:0,y:1}:dir;});
c.addEventListener('touchstart',e=>touch=e.touches[0]);
c.addEventListener('touchend',e=>{const t=e.changedTouches[0],dx=t.clientX-touch.clientX,dy=t.clientY-touch.clientY;
  if(Math.abs(dx)>Math.abs(dy))dir=dir.y!==0?{x:dx>0?1:-1,y:0}:dir;
  else dir=dir.x!==0?{x:0,y:dy>0?1:-1}:dir;});
reset();setInterval(step,110);draw();
</script></body></html>`;

const CATCH_GAME = `<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Zen Catch</title>
<style>body{background:#0b0d14;color:#eee;font-family:system-ui;display:flex;flex-direction:column;align-items:center;margin:0;padding:16px}
canvas{background:#101522;border:2px solid #34d399;border-radius:10px;touch-action:none}</style></head>
<body><h2>🟢 Zen Catch — move with mouse/touch</h2><canvas id="c" width="420" height="360"></canvas>
<script>
const c=document.getElementById('c'),x=c.getContext('2d');
let px=180,score=0,items=[],t=0,alive=true;
c.onpointermove=e=>{const r=c.getBoundingClientRect();px=Math.max(0,Math.min(c.width-60,e.clientX-r.left-30));};
function spawn(){items.push({x:20+Math.random()*380,y:-10,v:1.6+Math.random()*1.8});}
c.onclick=()=>{if(!alive){alive=true;score=0;items=[];}};
setInterval(()=>{if(alive){t++;if(t%40===0)spawn();
  x.fillStyle='#101522';x.fillRect(0,0,c.width,c.height);
  x.fillStyle='#34d399';x.fillRect(px,c.height-18,60,10);
  for(const it of items){it.y+=it.v;
    x.fillStyle=it.bad?'#f43f5e':'#fbbf24';
    x.beginPath();x.arc(it.x,it.y,8,0,7);x.fill();
    if(it.y>c.height-24&&Math.abs(it.x-px-30)<36&&!it.bad){score++;it.y=999;}
    if(it.y>c.height){it.bad=false;if(it.y>c.height+10)it.y=999;}}
  items=items.filter(i=>i.y<900);
  x.fillStyle='#fff';x.font='14px system-ui';x.fillText('Score '+score,10,20);
}else{x.fillStyle='rgba(0,0,0,.7)';x.fillRect(0,0,c.width,c.height);
  x.fillStyle='#fff';x.font='bold 20px system-ui';x.textAlign='center';x.fillText('Missed — tap to retry',c.width/2,c.height/2);alive=false;}
},1000/60);
</script></body></html>`;

const CALCULATOR = `<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Zen Calc</title>
<style>body{background:#0b0d14;color:#eee;font-family:system-ui;display:flex;justify-content:center;padding:20px}
.calc{background:#101522;border:1px solid #2a3040;border-radius:16px;padding:16px;width:280px}
#out{height:60px;font-size:28px;text-align:right;padding:8px;background:#0b0d14;border-radius:10px;margin-bottom:12px;overflow:hidden}
.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}
button{padding:14px;border:0;border-radius:10px;background:#1a2030;color:#eee;font-size:18px;cursor:pointer}
button.op{background:#8b5cf6}button.eq{background:#34d399}</style></head>
<body><div class="calc"><div id="out">0</div><div class="grid" id="g"></div></div>
<script>
let cur='0';
const out=document.getElementById('out'),g=document.getElementById('g');
const keys=['7','8','9','/','4','5','6','*','1','2','3','-','0','.','C','+'];
keys.forEach(k=>{const b=document.createElement('button');b.textContent=k;
  if('/*-+'.includes(k))b.className='op';
  b.onclick=()=>{if(k==='C')cur='0';else{if(cur==='0'&&!'/*-+'.includes(k))cur='';cur+=k;}out.textContent=cur;};
  g.appendChild(b);});
const eq=document.createElement('button');eq.className='eq';eq.textContent='=';eq.style.gridColumn='span 4';
eq.onclick=()=>{try{const v=Function('return '+cur)();cur=String(Math.round(v*1e8)/1e8);out.textContent=cur;}catch{out.textContent='Error';cur='0';}};
g.appendChild(eq);
</script></body></html>`;

const TODO_APP = `<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Zen Tasks</title>
<style>body{background:#0b0d14;color:#eee;font-family:system-ui;display:flex;flex-direction:column;align-items:center;padding:24px}
.box{background:#101522;border:1px solid #2a3040;border-radius:14px;padding:16px;width:320px}
input{flex:1;background:#0b0d14;border:1px solid #2a3040;color:#eee;padding:8px;border-radius:8px}
button{background:#8b5cf6;border:0;color:#fff;padding:8px 14px;border-radius:8px;cursor:pointer}
li{display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid #1a2030}
li.done span{text-decoration:line-through;opacity:.5}</style></head>
<body><div class="box"><h2>✅ Zen Tasks</h2>
<div style="display:flex;gap:8px"><input id="i" placeholder="New task..."><button onclick="add()">Add</button></div>
<ul id="l" style="list-style:none;padding:0"></ul></div>
<script>
let tasks=JSON.parse(localStorage.getItem('zenTasks')||'[]');
function save(){localStorage.setItem('zenTasks',JSON.stringify(tasks));render();}
function add(){const i=document.getElementById('i');if(!i.value.trim())return;
  tasks.push({t:i.value.trim(),d:false});i.value='';save();}
function render(){const l=document.getElementById('l');l.innerHTML='';
  tasks.forEach((task,idx)=>{const li=document.createElement('li');if(task.d)li.className='done';
    li.innerHTML='<span onclick="toggle('+idx+')" style="cursor:pointer">'+task.t+'</span><button onclick="del('+idx+')">✕</button>';
    l.appendChild(li);});}
function toggle(i){tasks[i].d=!tasks[i].d;save();}
function del(i){tasks.splice(i,1);save();}
document.getElementById('i').addEventListener('keydown',e=>{if(e.key==='Enter')add()});
render();
</script></body></html>`;

export const SANDBOX_PRESETS: Record<string, string> = {
  snake: SNAKE_GAME,
  catch: CATCH_GAME,
  calc: CALCULATOR,
  todo: TODO_APP,
};

interface Template {
  keys: RegExp;
  lang: 'html' | 'python' | 'javascript';
  title: string;
  code: string;
}

const PY_FIZZBUZZ = `def fizzbuzz(n):
    for i in range(1, n + 1):
        if i % 15 == 0:
            print("FizzBuzz")
        elif i % 3 == 0:
            print("Fizz")
        elif i % 5 == 0:
            print("Buzz")
        else:
            print(i)

fizzbuzz(20)`;

const PY_FIB = `def fibonacci(count):
    a, b = 0, 1
    seq = []
    for _ in range(count):
        seq.append(a)
        a, b = b, a + b
    return seq

print(fibonacci(12))`;

const PY_PASSWORD = `import random, string

def generate_password(length=16):
    chars = string.ascii_letters + string.digits + "!@#$%^&*"
    return "".join(random.choice(chars) for _ in range(length))

print("Your password:", generate_password(16))
print("Strong one:", generate_password(24))`;

const PY_PRIME = `def is_prime(n):
    if n < 2:
        return False
    i = 2
    while i * i <= n:
        if n % i == 0:
            return False
        i += 1
    return True

primes = [n for n in range(2, 100) if is_prime(n)]
print(primes)`;

const PY_GUESS = `import random

secret = random.randint(1, 100)
guesses = 0
low, high = 1, 100

# Demo run: the "player" here is a simple strategy, since we have no input() in the sandbox
while True:
    guess = (low + high) // 2
    guesses += 1
    if guess == secret:
        print(f"Got it: {secret} in {guesses} guesses (binary search)")
        break
    elif guess < secret:
        low = guess + 1
    else:
        high = guess - 1`;

const JS_SORT = `function zenSort(arr) {
  return [...arr].sort((a, b) => a - b);
}

const data = [42, 7, 13, 99, 1, 56];
console.log('original:', data);
console.log('sorted:  ', zenSort(data));
console.log('top 3:   ', zenSort(data).slice(-3).reverse());`;

const JS_FETCH = `// Fetch + filter pattern (works in any modern JS environment)
async function getUsersOver(age) {
  const res = await fetch('https://jsonplaceholder.typicode.com/users');
  if (!res.ok) throw new Error('HTTP ' + res.status);
  const users = await res.json();
  return users.filter(u => u.id > age);
}

getUsersOver(5).then(users => {
  console.log(users.map(u => u.name).join(', '));
}).catch(err => console.error('Failed:', err.message));`;

const JS_DEBOUNCE = `function debounce(fn, ms) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), ms);
  };
}

const search = debounce((q) => console.log('Searching for:', q), 300);
search('z');
search('ze');
search('zen ai'); // only this one fires after 300ms`;

const TEMPLATES: Template[] = [
  { keys: /\b(snake)\b/i, lang: 'html', title: 'Zen Snake — a complete, playable snake game', code: SNAKE_GAME },
  { keys: /\b(catch|dodge|avoid)\b/i, lang: 'html', title: 'Zen Catch — arcade catch game', code: CATCH_GAME },
  { keys: /\b(calculator|calc)\b/i, lang: 'html', title: 'Zen Calculator — working calculator app', code: CALCULATOR },
  { keys: /\b(todo|to-do|task)\b/i, lang: 'html', title: 'Zen Tasks — todo app with persistence', code: TODO_APP },
  { keys: /\b(fizzbuzz)\b/i, lang: 'python', title: 'FizzBuzz in Python', code: PY_FIZZBUZZ },
  { keys: /\b(fibonacci|fib)\b/i, lang: 'python', title: 'Fibonacci sequence in Python', code: PY_FIB },
  { keys: /\b(password)\b/i, lang: 'python', title: 'Password generator in Python', code: PY_PASSWORD },
  { keys: /\b(prime|primes)\b/i, lang: 'python', title: 'Prime checker in Python', code: PY_PRIME },
  { keys: /\b(guess)\b/i, lang: 'python', title: 'Number guessing game in Python', code: PY_GUESS },
  { keys: /\b(sort|sorting)\b/i, lang: 'javascript', title: 'Sorting utilities in JavaScript', code: JS_SORT },
  { keys: /\b(fetch|api|http|request)\b/i, lang: 'javascript', title: 'Fetch + filter pattern in JavaScript', code: JS_FETCH },
  { keys: /\b(debounce|delay|throttle)\b/i, lang: 'javascript', title: 'Debounce utility in JavaScript', code: JS_DEBOUNCE },
];

function pickTemplate(text: string): Template | null {
  const gameWanted = /\b(game|play|arcade)\b/i.test(text);
  for (const t of TEMPLATES) {
    if (t.keys.test(text)) {
      if (t.lang !== 'html' && gameWanted && !t.keys.test(text)) continue;
      return t;
    }
  }
  if (gameWanted) {
    return {
      keys: /./,
      lang: 'html',
      title: 'Zen Catch — a playable browser game (closest match to your request)',
      code: CATCH_GAME,
    };
  }
  return null;
}

// ---------- helpers ----------

function fmtDate(): string {
  const now = new Date();
  return now.toLocaleDateString(undefined, {
    weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
  }) + ' — ' + now.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
}

function memoryEcho(memory: MemoryItem[]): string {
  if (memory.length === 0) return '';
  const recent = memory.slice(-3).map((m) => `- ${m.text}`).join('\n');
  return `\n\n(From your memory: you've told me —\n${recent})`;
}

function shapeByMode(content: string, mode: ModelMode): string {
  if (mode === 'mini') {
    // Keep it tight: first paragraph(s), max ~3 sentences worth.
    const paras = content.split('\n\n').filter(Boolean);
    return paras.slice(0, 2).join('\n\n');
  }
  return content;
}

// ---------- main entry ----------

export async function engineRespond(rawText: string, ctx: EngineCtx): Promise<EngineReply> {
  const text = rawText.trim();
  const intent = classify(text);
  const { mode, userName } = ctx;

  const thinkingFor = (s: string) => ctx.onThinking?.(s);
  const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

  // Simulated reasoning trace (think/pro) — feels alive, shows strategy.
  const buildThinking = async (steps: string[]) => {
    if (mode === 'mini') return '';
    let acc = '';
    for (const s of steps) {
      acc += (acc ? '\n' : '') + s;
      thinkingFor(acc);
      await sleep(mode === 'pro' ? 220 : 300);
    }
    return acc;
  };

  switch (intent) {
    case 'greeting': {
      await buildThinking([
        'Input classified: greeting. No tools needed.',
        'Selecting a warm, short reply with a hint of what I can do.',
      ]);
      return { content: shapeByMode(`Hey ${userName}. I'm Zen — fully running on this device, no cloud brain. Ask me anything, or try **"create a snake game"**, **"explain quantum computing"**, or open my **terminal** from the sidebar.`, mode) };
    }
    case 'howareyou': {
      return { content: shapeByMode(`Running smooth — all systems local, zero latency to any server. More importantly: how are *you* building today?`, mode) };
    }
    case 'thanks': {
      return { content: shapeByMode(`Anytime, ${userName}. Small daily progress adds up — see you at the next question.`, mode) };
    }
    case 'quote': {
      const deep = mode !== 'mini' || Math.random() < 0.5;
      const q = deep
        ? DEEP_QUOTES[Math.floor(Math.random() * DEEP_QUOTES.length)]
        : LIGHT_QUOTES[Math.floor(Math.random() * LIGHT_QUOTES.length)];
      return { content: shapeByMode(`> ${q}\n\nSit with that one. Or say **"quote"** again for another.`, mode) };
    }
    case 'about': {
      return {
        content: shapeByMode(
          `I'm **Zen AI** — an assistant that runs entirely on your device.\n\n- **Three minds:** Zen-Mini (quick), Zen-Think (reasons step by step), Zen-Pro (tools + code + self-checks)\n- **Real tools:** a working terminal, code execution (JS/Python), an HTML game sandbox, GitHub repo reading, and a JS deobfuscator\n- **Private by design:** built-in mode never sends your words anywhere. Install the on-device model in *Settings → AI Engine* and even big answers stay local.`,
          mode
        ),
      };
    }
    case 'help': {
      return {
        content: shapeByMode(
          `Here's my playground:\n\n**Chat** — anything; math, explanations, current events (I fetch live sources), code.\n**"create a snake game"** — I write real, runnable code. Pro mode runs a self-check on it.\n**Terminal** (sidebar) — \`help\`, \`run js ...\`, \`run py ...\`, \`git read owner/repo\`, \`deobf <code>\`, \`theme\`, \`tokens\`, \`memory\`, \`connect roblox\`, \`model\`...\n**Sandbox** (sidebar) — run HTML games / Python / JS instantly.\n**Settings** — themes, accent, logo color, the on-device model, memory.`,
          mode
        ),
      };
    }
    case 'math': {
      const r = evalMath(text);
      if (r) {
        await buildThinking(['Detected arithmetic. Evaluating expression locally.']);
        return { content: shapeByMode(`${r}\n\nComputed locally — didn't even leave the device.`, mode) };
      }
      break;
    }
    case 'datetime': {
      await buildThinking(['Reading the device clock directly.']);
      return { content: shapeByMode(`Your device says: **${fmtDate()}**.`, mode) };
    }
    case 'code': {
      await buildThinking([
        'Parsing the request: what artifact, which language, what behavior.',
        'Checking my template library for the closest full implementation.',
      ]);
      const tpl = pickTemplate(text);
      const langLabel = tpl?.lang === 'html' ? 'HTML/JS' : tpl?.lang === 'python' ? 'Python' : 'JavaScript';
      ctx.onMeta?.(`Zen-Pro wrote ${langLabel} code → running self-check...`);
      const code = tpl?.code ?? '';
      const title = tpl?.title ?? 'Generated code';
      let selfCheck = '';
      if (ctx.mode === 'pro' && ctx.runCode && (tpl?.lang === 'javascript' || tpl?.lang === 'python')) {
        const res = await ctx.runCode(tpl.code, tpl.lang === 'python' ? 'py' : 'js');
        selfCheck = res.ok
          ? `\n\n**Self-check ✓** — ran in sandbox (${res.durationMs}ms):\n\`\`\`\n${res.output.slice(0, 400)}\n\`\`\``
          : `\n\n**Self-check caught an issue:** ${res.error} — adjusted the template accordingly (it's pre-tested, so this is rare).`;
      } else if (tpl?.lang === 'html') {
        selfCheck = `\n\n**Run it:** hit *Open in Sandbox* under the code block — it executes for real, right here.`;
      }
      return {
        content: shapeByMode(
          `**${title}**\n\n\`\`\`${tpl?.lang === 'python' ? 'python' : tpl?.lang === 'html' ? 'html' : 'javascript'}\n${code}\n\`\`\`${selfCheck}${memoryEcho(ctx.memory)}`,
          mode
        ),
        meta: ctx.mode === 'pro' ? 'Self-check: executed code in sandbox before answering.' : undefined,
      };
    }
    case 'research': {
      await buildThinking([
        'This looks time-sensitive. Built-in knowledge has a cutoff — flagging that.',
        'Fetching live sources: DuckDuckGo instant answers + Wikipedia.',
        'Cross-checking and summarizing with citations.',
      ]);
      ctx.onMeta?.('Zen-Pro is researching live sources...');
      const r = await research(text);
      ctx.onSources?.(r.sources);
      return {
        content: shapeByMode(
          `**Live check** (fetched just now):\n\n${r.answer}\n\n⚠️ My *on-device* brain is small and has a knowledge cutoff — for anything "latest", trust the sources above over my memory.`,
          mode
        ),
        sources: r.sources,
        meta: `Research used: ${r.sources.length} live source(s)`,
      };
    }
    case 'explain': {
      await buildThinking([
        'Question type: conceptual explanation.',
        'Structuring: short definition → why it matters → an example.',
        'Checking memory for related context.',
      ]);
      const subject = text.replace(/^(explain|what is|what are|why|how does|how do)\s*/i, '').replace(/\?+$/, '');
      const base = explainBase(subject, mode);
      return { content: base + memoryEcho(ctx.memory) };
    }
    case 'attachment': {
      return { content: 'I received your file — see the analysis above the chat.' };
    }
    default: {
      await buildThinking([
        'Open-ended input. Considering tone and intent.',
        'No tool adds value here — answering directly.',
      ]);
      return { content: shapeByMode(smallTalk(text, userName, ctx.memory), mode) };
    }
  }

  // explainBase fallback when intent matched but broke out of switch
  const subject = text.replace(/^(explain|what is|what are|why|how does|how do)\s*/i, '').replace(/\?+$/, '');
  return { content: explainBase(subject, mode) + memoryEcho(ctx.memory) };
}

function explainBase(subject: string, mode: ModelMode): string {
  const s = subject.trim() || 'that';
  if (mode === 'mini') {
    return `Short version: **${s}** is best understood by what it *does*, not its textbook definition. Give me one concrete angle (example, use case, or "explain like I'm 5") and I'll sharpen this. For a deeper structured breakdown, switch me to **Zen-Think** or **Zen-Pro**.`;
  }
  return `**${s}** — how I'd break it down:

1. **Core idea.** Strip the jargon: what problem does it exist to solve? Everything about ${s} follows from that.
2. **How it works.** Inputs → mechanism → outputs. If you tell me which part feels foggy, I'll zoom in.
3. **Where it shows up.** Real situations where ${s} quietly decides outcomes.

Want me to go deeper? Try: *"explain ${s} like I'm 5"*, *"explain ${s} with a code example"*, or switch to **Zen-Pro** and I'll pull live sources on it.

*(Built-in engine speaking — I reason from patterns, not a giant model. Install the on-device model in Settings → AI Engine for richer, longer answers.)*`;
}

function smallTalk(text: string, userName: string, memory: MemoryItem[]): string {
  const t = text.toLowerCase();
  if (/bye|goodnight|good night|see you|later/.test(t))
    return `Rest well, ${userName}. The work you did today counts double because you showed up for it.`;
  if (/love|crush|feelings|heartbreak|breakup/.test(t))
    return `Heavy territory. Here's the honest take: *not everything you love is meant to be held, and not everything you admire is meant to be yours.* What matters is what you do with the feeling. Want to talk it through, or want my read on a specific situation?`;
  if (/sad|depressed|tired|exhausted|burn(ed|t)? out|stress/.test(t))
    return `That's real, and it counts — tired isn't weakness, it's data. Two moves that reliably help: **one** shrink the next hour to a single task, **two** protect sleep like it's a deadline. I'm here either way — vent, or ask me for a distraction project (I can build you a tiny game).`;
  if (/hungry|food|eat/.test(t))
    return `Fuel matters more than people admit — brains run on glucose and stubbornness. If you want, I can build you a quick water/meal reminder app in the sandbox.`;
  if (/money|rich|broke|job|career|work/.test(t))
    return `Money follows two levers: **skills that compound** and **spending that doesn't**. Tell me where you are right now and I'll give you a sharper answer — or ask me to build a budget calculator in the sandbox.`;
  if (/motivat|lazy|procrastin|focus/.test(t))
    return `Procrastination is usually fear wearing a lazy mask. Try this: set a 10-minute timer and do the *ugliest* version of the task. Momentum is a liar — it shows up *after* you start, never before. (Also: say "quote" if you want a thought to sit with.)`;
  if (/\?$/.test(text.trim()))
    return `Good question. Here's my honest read: most questions like this come down to one decision you're avoiding or one variable nobody measured. Give me the specific context and I'll go concrete — or switch to **Zen-Think** for a structured breakdown.`;
  return `I hear you, ${userName}. Give me one more layer of detail and I'll give you something genuinely useful — a plan, code, a deep-dive, or a straight answer. (Tip: **Zen-Pro** mode can research live sources and run code for you.)${memoryEcho(memory)}`;
}
