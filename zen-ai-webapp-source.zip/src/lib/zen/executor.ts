// Real sandboxed execution: JavaScript (Web Worker), Python (Pyodide via CDN),
// and HTML (iframe sandbox). No compilers/decompilers — as agreed.

export interface ExecResult {
  ok: boolean;
  output: string;
  error?: string;
  durationMs: number;
}

// ---------------- JavaScript ----------------

export function runJavaScript(code: string, timeoutMs = 8000): Promise<ExecResult> {
  return new Promise((resolve) => {
    const start = performance.now();
    const workerSrc = `
      const logs = [];
      const fmt = (v) => {
        if (typeof v === 'string') return v;
        try { return JSON.stringify(v, null, 2); } catch { return String(v); }
      };
      const console = {
        log: (...a) => logs.push(a.map(fmt).join(' ')),
        info: (...a) => logs.push('[info] ' + a.map(fmt).join(' ')),
        warn: (...a) => logs.push('[warn] ' + a.map(fmt).join(' ')),
        error: (...a) => logs.push('[error] ' + a.map(fmt).join(' ')),
      };
      self.onerror = (m) => { postMessage({ ok: false, output: logs.join('\\n'), error: String(m) }); };
      self.onmessage = (e) => {
        try {
          const fn = new Function('console', '"use strict";' + e.data);
          const result = fn(console);
          if (result !== undefined) logs.push('=> ' + fmt(result));
          postMessage({ ok: true, output: logs.join('\\n') });
        } catch (err) {
          postMessage({ ok: false, output: logs.join('\\n'), error: (err && err.message) || String(err) });
        }
      };
    `;
    const blob = new Blob([workerSrc], { type: 'application/javascript' });
    const url = URL.createObjectURL(blob);
    const worker = new Worker(url);
    let done = false;

    const finish = (r: ExecResult) => {
      if (done) return;
      done = true;
      worker.terminate();
      URL.revokeObjectURL(url);
      resolve(r);
    };

    worker.onmessage = (e: MessageEvent) => {
      finish({
        ok: e.data.ok,
        output: e.data.output || '(no output)',
        error: e.data.error,
        durationMs: Math.round(performance.now() - start),
      });
    };
    worker.onerror = () =>
      finish({
        ok: false,
        output: '(no output)',
        error: 'Worker crashed',
        durationMs: Math.round(performance.now() - start),
      });

    setTimeout(() => {
      finish({
        ok: false,
        output: '(timed out)',
        error: `Execution exceeded ${timeoutMs}ms and was terminated.`,
        durationMs: timeoutMs,
      });
    }, timeoutMs);

    worker.postMessage(code);
  });
}

// ---------------- Python (Pyodide) ----------------

let pyodideInstance: any = null;
let pyodideLoading: Promise<any> | null = null;
const PYODIDE_VERSION = '0.26.4';
const PYODIDE_URL = `https://cdn.jsdelivr.net/pyodide/v${PYODIDE_VERSION}/full/`;

export function isPyodideLoaded(): boolean {
  return pyodideInstance !== null;
}

export async function ensurePyodide(onProgress?: (s: string) => void): Promise<any> {
  if (pyodideInstance) return pyodideInstance;
  if (pyodideLoading) return pyodideLoading;

  pyodideLoading = (async () => {
    onProgress?.('Loading Python runtime (~10MB, first time only)...');
    await new Promise<void>((resolve, reject) => {
      const existing = document.querySelector<HTMLScriptElement>('script[data-pyodide]');
      if (existing) {
        existing.addEventListener('load', () => resolve());
        existing.addEventListener('error', () => reject(new Error('Failed to load Pyodide script')));
        if ((window as any).loadPyodide) resolve();
        return;
      }
      const s = document.createElement('script');
      s.src = `${PYODIDE_URL}pyodide.js`;
      s.dataset.pyodide = '1';
      s.onload = () => resolve();
      s.onerror = () => reject(new Error('Failed to load Pyodide script (offline?)'));
      document.head.appendChild(s);
    });
    onProgress?.('Booting CPython (WASM)...');
    const loader = (window as any).loadPyodide;
    if (!loader) throw new Error('Pyodide loader unavailable');
    pyodideInstance = await loader({ indexURL: PYODIDE_URL });
    onProgress?.('Python ready.');
    return pyodideInstance;
  })();

  try {
    return await pyodideLoading;
  } catch (e) {
    pyodideLoading = null;
    throw e;
  }
}

export async function runPython(
  code: string,
  onProgress?: (s: string) => void
): Promise<ExecResult> {
  const start = performance.now();
  try {
    const py = await ensurePyodide(onProgress);
    let out = '';
    py.setStdout({ batched: (s: string) => (out += s + '\n') });
    py.setStderr({ batched: (s: string) => (out += '[stderr] ' + s + '\n') });
    const result = await py.runPythonAsync(code);
    if (result !== undefined && result !== null) out += `=> ${result.toString()}\n`;
    return {
      ok: true,
      output: out.trim() || '(no output)',
      durationMs: Math.round(performance.now() - start),
    };
  } catch (err: any) {
    return {
      ok: false,
      output: '(python error)',
      error: String(err?.message || err).split('\n').slice(-12).join('\n'),
      durationMs: Math.round(performance.now() - start),
    };
  }
}

// ---------------- HTML sandbox ----------------

export function buildSandboxDoc(html: string): string {
  // Force dark-friendly default when the snippet doesn't style itself.
  const hasBodyStyle = /<body[^>]*style=|<style/i.test(html);
  const inject = hasBodyStyle
    ? ''
    : `<style>body{background:#0e1118;color:#e6e9f2;font-family:system-ui,sans-serif;padding:12px}</style>`;
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">${inject}</head><body>${html}</body></html>`;
}

export function detectLanguage(code: string): 'python' | 'javascript' | 'html' | 'unknown' {
  const t = code.trim().toLowerCase();
  if (t.startsWith('<!doctype') || t.startsWith('<html') || t.startsWith('<div') || t.startsWith('<canvas'))
    return 'html';
  if (/^\s*(def |class |import \w+|from \w+ import|print\(|\w+\s*=\s*\[)/.test(t) || /\bprint\s*\(/.test(t) === true && !/\bfunction\b|\bconst\b|\blet\b|\bconsole\./.test(t))
    return 'python';
  if (/\b(function|const|let|var|console\.|=>)\b/.test(t)) return 'javascript';
  return 'unknown';
}
