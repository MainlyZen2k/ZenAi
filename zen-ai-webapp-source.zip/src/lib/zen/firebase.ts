// Firebase layer: email + Google auth, Firestore sync, ban enforcement and
// login logging. If no Firebase config is provided the app runs in Local
// Demo mode (everything in localStorage) so it works out of the box.

import { initializeApp, getApps, type FirebaseApp } from 'firebase/app';
import {
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  GoogleAuthProvider,
  signOut as fbSignOut,
  onAuthStateChanged,
  updateProfile,
  type Auth,
} from 'firebase/auth';
import {
  getFirestore,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  collection,
  addDoc,
  query,
  where,
  getDocs,
  orderBy,
  serverTimestamp,
  type Firestore,
} from 'firebase/firestore';
import type { FBConfig, ZenUser, AdminUserRow } from './types';

export const FIREBASE_ERRORS: Record<string, string> = {
  'auth/invalid-email': 'That email looks malformed.',
  'auth/user-not-found': 'No account with that email.',
  'auth/wrong-password': 'Wrong password.',
  'auth/invalid-credential': 'Wrong email or password.',
  'auth/email-already-in-use': 'That email already has an account — sign in instead.',
  'auth/weak-password': 'Password needs 6+ characters.',
  'auth/popup-closed-by-user': 'Google window closed before finishing.',
  'auth/unauthorized-domain': 'This domain isn\'t authorized in Firebase → Auth → Settings → Authorized domains.',
  'auth/operation-not-allowed': 'Enable this sign-in method in Firebase → Auth → Sign-in method.',
  'auth/network-request-failed': 'Network error reaching Firebase.',
};

export function prettyFBError(code: string): string {
  return FIREBASE_ERRORS[code] || code.replace('auth/', '').replace(/-/g, ' ');
}

let app: FirebaseApp | null = null;
let auth: Auth | null = null;
let fs: Firestore | null = null;

export function isConfigured(): boolean {
  return app !== null;
}

/** True when Firebase has been initialized (config entered). */
export function hasConfigLive(): boolean {
  return isConfigured();
}

export function initFirebase(cfg: FBConfig): boolean {
  try {
    app = getApps().length ? getApps()[0] : initializeApp(cfg);
    auth = getAuth(app);
    fs = getFirestore(app);
    return true;
  } catch {
    app = null;
    auth = null;
    fs = null;
    return false;
  }
}

export function getAuthInstance(): Auth | null {
  return auth;
}

// Admin allowlist — put your own email here to auto-promote yourself,
// or promote manually from the Firebase console (users/{uid}.role = "admin").
export const ADMIN_EMAILS: string[] = [];

// ---------------- auth flows ----------------

export async function emailSignIn(email: string, password: string): Promise<void> {
  if (!auth) throw new Error('Firebase not configured');
  await signInWithEmailAndPassword(auth, email, password);
}

export async function emailSignUp(email: string, password: string, name: string): Promise<void> {
  if (!auth) throw new Error('Firebase not configured');
  const cred = await createUserWithEmailAndPassword(auth, email, password);
  if (name) await updateProfile(cred.user, { displayName: name });
}

export async function googleSignIn(): Promise<void> {
  if (!auth) throw new Error('Firebase not configured');
  const provider = new GoogleAuthProvider();
  await signInWithPopup(auth, provider);
}

export async function signOutUser(): Promise<void> {
  if (auth) await fbSignOut(auth);
}

export function watchAuth(cb: (uid: string | null, email: string, name: string) => void): () => void {
  if (!auth) {
    cb(null, '', '');
    return () => {};
  }
  return onAuthStateChanged(auth, (u) => {
    cb(u?.uid ?? null, u?.email ?? '', u?.displayName || u?.email?.split('@')[0] || 'Zen User');
  });
}

// ---------------- user profile / ban system ----------------

export async function ensureUserProfile(uid: string, email: string, name: string): Promise<ZenUser> {
  if (!fs) throw new Error('Firestore not ready');
  const ref = doc(fs, 'users', uid);
  const snap = await getDoc(ref);
  if (!snap.exists()) {
    const role: ZenUser['role'] = ADMIN_EMAILS.includes(email.toLowerCase()) ? 'admin' : 'user';
    const profile: ZenUser = { uid, email, name, role, status: 'active' };
    await setDoc(ref, { ...profile, createdAt: serverTimestamp() });
    return profile;
  }
  const data = snap.data() as any;
  return {
    uid,
    email: data.email || email,
    name: data.name || name,
    role: data.role === 'admin' ? 'admin' : 'user',
    status: data.status === 'banned' ? 'banned' : 'active',
    banReason: data.banReason,
    photoUrl: data.photoUrl,
  };
}

export async function logLogin(uid: string, meta: { platform: string; ua: string }): Promise<void> {
  if (!fs) return;
  try {
    await addDoc(collection(fs, 'loginLogs'), {
      uid,
      ts: serverTimestamp(),
      ...meta,
    });
  } catch {
    /* logging must never block login */
  }
}

export async function refreshBanStatus(uid: string): Promise<ZenUser | null> {
  if (!fs) return null;
  const snap = await getDoc(doc(fs, 'users', uid));
  if (!snap.exists()) return null;
  const d = snap.data() as any;
  return {
    uid,
    email: d.email || '',
    name: d.name || '',
    role: d.role === 'admin' ? 'admin' : 'user',
    status: d.status === 'banned' ? 'banned' : 'active',
    banReason: d.banReason,
  };
}

// ---------------- admin panel ----------------

export async function listUsers(): Promise<AdminUserRow[]> {
  if (!fs) throw new Error('Firestore not ready');
  const snap = await getDocs(query(collection(fs, 'users'), orderBy('createdAt', 'desc')));
  return snap.docs.map((d) => {
    const v = d.data() as any;
    return {
      uid: d.id,
      email: v.email || '',
      name: v.name || '',
      role: v.role || 'user',
      status: v.status || 'active',
      banReason: v.banReason,
      createdAt: v.createdAt?.toMillis?.(),
    };
  });
}

export async function setUserStatus(uid: string, status: 'active' | 'banned', reason?: string): Promise<void> {
  if (!fs) throw new Error('Firestore not ready');
  await updateDoc(doc(fs, 'users', uid), {
    status,
    banReason: status === 'banned' ? reason || 'No reason given' : '',
  });
}

export async function setUserRole(uid: string, role: 'user' | 'admin'): Promise<void> {
  if (!fs) throw new Error('Firestore not ready');
  await updateDoc(doc(fs, 'users', uid), { role });
}

export async function grantTokens(uid: string, amount: number): Promise<void> {
  if (!fs) throw new Error('Firestore not ready');
  const ref = doc(fs, 'users', uid);
  const snap = await getDoc(ref);
  const cur = (snap.data() as any)?.tokens ?? 0;
  await setDoc(ref, { tokens: cur + amount }, { merge: true });
}

export async function fetchRemoteTokens(uid: string): Promise<number | null> {
  if (!fs) return null;
  const snap = await getDoc(doc(fs, 'users', uid));
  return (snap.data() as any)?.tokens ?? null;
}

export async function saveRemoteTokens(uid: string, balance: number): Promise<void> {
  if (!fs) return;
  await setDoc(doc(fs, 'users', uid), { tokens: balance }, { merge: true });
}

// ---------------- chat + memory sync (per user) ----------------

export async function syncChatsToCloud(uid: string, chats: unknown): Promise<void> {
  if (!fs) return;
  await setDoc(doc(fs, 'users', uid, 'data', 'chats'), { chats: JSON.stringify(chats) }, { merge: true });
}

export async function loadChatsFromCloud(uid: string): Promise<unknown | null> {
  if (!fs) return null;
  const snap = await getDoc(doc(fs, 'users', uid, 'data', 'chats'));
  if (!snap.exists()) return null;
  try {
    return JSON.parse((snap.data() as any).chats);
  } catch {
    return null;
  }
}

export async function syncMemoryToCloud(uid: string, memory: unknown): Promise<void> {
  if (!fs) return;
  await setDoc(doc(fs, 'users', uid, 'data', 'memory'), { memory: JSON.stringify(memory) }, { merge: true });
}

export async function loadMemoryFromCloud(uid: string): Promise<unknown | null> {
  if (!fs) return null;
  const snap = await getDoc(doc(fs, 'users', uid, 'data', 'memory'));
  if (!snap.exists()) return null;
  try {
    return JSON.parse((snap.data() as any).memory);
  } catch {
    return null;
  }
}

export async function findUserByEmail(email: string): Promise<AdminUserRow | null> {
  if (!fs) throw new Error('Firestore not ready');
  const snap = await getDocs(query(collection(fs, 'users'), where('email', '==', email.toLowerCase())));
  if (snap.empty) return null;
  const d = snap.docs[0];
  const v = d.data() as any;
  return {
    uid: d.id,
    email: v.email,
    name: v.name || '',
    role: v.role || 'user',
    status: v.status || 'active',
    banReason: v.banReason,
    tokens: v.tokens,
  };
}
