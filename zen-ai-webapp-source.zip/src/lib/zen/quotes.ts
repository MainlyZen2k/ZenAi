// Deep, thought-provoking + light motivational quotes for Zen AI's greetings.
// Deep ones make you stop and think; light ones nudge without preaching.

export const DEEP_QUOTES: string[] = [
  "Not everything you love is meant to be held, and not everything you admire is meant to be yours.",
  "Why are you seeking validation from a world that crucified a perfect man?",
  "You are not behind. You are just counting someone else's milestones as your failures.",
  "The grave is the richest place on earth — most people die with their best song still unsung.",
  "You don't fear failure. You fear being seen trying and failing anyway.",
  "Comfort is the slowest way to lose everything you wanted.",
  "Nobody is coming to save you. That news is either terrible or the freest thing you'll ever hear.",
  "You've survived 100% of the days you swore you wouldn't.",
  "Discipline is choosing what you want most over what you want now — and it's a muscle, not a mood.",
  "Some doors close so you stop knocking on walls.",
  "The version of you that you keep postponing doesn't get built by motivation. It gets built on the days you don't feel like it.",
  "Being misunderstood is the tax on thinking differently. Pay it.",
  "You can't heal in the same environment that made you sick.",
  "Almost everything you're afraid of has already happened to someone who turned out fine.",
  "Time doesn't wait. It just quietly subtracts.",
  "Your comfort zone is a beautiful place, but nothing ever grows there.",
  "The person who chases two rabbits catches neither.",
  "Rock bottom has a floor you build with your own excuses — or a floor you stand on to push up.",
  "People aren't against you. They're for themselves. Learn the difference and you'll stop bleeding.",
  "Silence isn't empty. It's full of answers.",
  "A river cuts through rock not because of power, but because of persistence.",
  "You were not born to just pay bills and scroll until you sleep.",
  "The mask you wear to be liked is the reason you feel unknown.",
  "Everything you've ever wanted is sitting on the other side of a conversation you're avoiding.",
  "Losing yourself in someone else's expectations is still losing.",
  "Don't mistake a full calendar for a full life.",
  "The wound is the place where the light enters you.",
  "Some storms exist to clear your path, not to block it.",
  "If you're the smartest person in the room, you're paying tuition to the wrong room.",
  "Your future is watching you through the choices you make today.",
];

export const LIGHT_QUOTES: string[] = [
  "Small daily progress adds up to big results.",
  "The secret of getting ahead is getting started.",
  "One page a day still finishes the book.",
  "Show up today. Future-you is watching and taking notes.",
  "You don't need a perfect plan. You need a first move.",
  "Momentum beats motivation — start ugly, fix it moving.",
  "Progress is progress, even at 1%.",
  "Today is another blank page. Try to write something you're proud of.",
  "The best time to plant a tree was 20 years ago. The second best is right now.",
  "Done is better than perfect — but started beats done.",
  "Consistency turns talent into skill and skill into mastery.",
  "Tiny steps still leave footprints.",
  "Every expert was once a disaster who kept going.",
  "Rest is part of the work, not a break from it.",
  "Make today so good yesterday gets jealous.",
];

export const GREETINGS: string[] = [
  "Welcome back",
  "Hey",
  "Good to see you",
  "Look who's here",
  "Back again",
  "The mind returns",
  "Ready when you are",
  "You showed up",
];

// Rotates without repeating until the pool is exhausted.
const lastUsed: { deep: string[]; light: string[]; greeting: string[] } = {
  deep: [],
  light: [],
  greeting: [],
};

function pickNoRepeat(pool: string[], used: string[]): string {
  const remaining = pool.filter((q) => !used.includes(q));
  const source = remaining.length > 0 ? remaining : pool;
  const choice = source[Math.floor(Math.random() * source.length)];
  used.push(choice);
  if (used.length > Math.floor(pool.length * 0.6)) used.shift();
  return choice;
}

export function dailyQuote(): { text: string; tone: 'deep' | 'light' } {
  const tone: 'deep' | 'light' = Math.random() < 0.6 ? 'deep' : 'light';
  const text =
    tone === 'deep'
      ? pickNoRepeat(DEEP_QUOTES, lastUsed.deep)
      : pickNoRepeat(LIGHT_QUOTES, lastUsed.light);
  return { text, tone };
}

export function greeting(name: string): string {
  const g = pickNoRepeat(GREETINGS, lastUsed.greeting);
  return `${g}, ${name}.`;
}
