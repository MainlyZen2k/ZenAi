'use client';

import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type {
  Chat,
  CloudSettings,
  MemoryItem,
  ModelMode,
  Msg,
  Settings,
  EngineState,
  FBMode,
  ZenUser,
  TokenState,
} from './types';
import { engineRespond, classify } from './engine';
import { runJavaScript, runPython, type ExecResult } from './executor';
import * as webllm from './webllm';
import * as cloudLib from './cloud';
import { research, looksLikeCurrentEvents, readRepo, deobfuscateJS } from './tools';
import * as fb from './firebase';
import { detectSeason, SEASONS } from './themes';
import { dailyQuote } from './quotes';

export const TOKEN_COSTS: Record<ModelMode, number> = { mini: 1, think: 4, pro: 10 };
export const DAILY_GRANT = 500;
export const START_TOKENS = 10000;

const uid = () => Math.random().toString(36).slice(2) + Date.now().toString(36);

export function todayKey(): string {
  return new Date().toISOString().slice(0, 10);
}

interface ZenStore {
  // data
  chats: Chat[];
  activeChatId: string | null;
  memory: MemoryItem[];
  settings: Settings;
  tokens: TokenState;
  // auth
  user: ZenUser | null;
  fbMode: FBMode;
  fbError: string | null;
  // engine
  engine: EngineState;
  season: string;
  // ui
  sidebarOpen: boolean;
  panel: null | 'terminal' | 'sandbox' | 'settings' | 'admin' | 'memory';
  generating: boolean;
  lastQuote: { text: string; tone: 'deep' | 'light' } | null;
  sandboxInput: { tab: 'html' | 'js' | 'py'; code: string } | null;

  // actions
  init: () => void;
  setFbMode: (m: FBMode, err?: string) => void;
  setUser: (u: ZenUser | null) => void;
  newChat: () => void;
  openChat: (id: string) => void;
  deleteChat: (id: string) => void;
  renameChat: (id: string, title: string) => void;
  setChatMode: (id: string, mode: ModelMode) => void;
  send: (text: string, attachments?: { name: string; type: string; size: number; dataUrl?: string; text?: string }[]) => Promise<void>;
  stop: () => void;
  claimDaily: () => boolean;
  spendTokens: (n: number) => boolean;
  addTokens: (n: number) => void;
  setTokens: (n: number) => void;
  addMemory: (text: string, tag?: string) => void;
  deleteMemory: (id: string) => void;
  clearMemory: () => void;
  updateSettings: (patch: Partial<Settings>) => void;
  updateCloud: (patch: Partial<CloudSettings>) => void;
  setSidebar: (open: boolean) => void;
  setPanel: (p: ZenStore['panel']) => void;
  setSandboxInput: (v: { tab: 'html' | 'js' | 'py'; code: string } | null) => void;
  downloadModel: (id: string) => Promise<void>;
  deleteModel: (id: string) => Promise<void>;
  refreshSeason: () => void;
  rerollQuote: () => void;
  signInDemo: () => void;
  logout: () => Promise<void>;
}

let stopFlag = false;
let cloudAbort: AbortController | null = null;

const CLOUD_DEFAULTS: CloudSettings = {
  enabled: true,
  provider: 'gemini',
  apiKey: '',
  ...cloudLib.defaultModelsFor('gemini'),
  baseUrl: '',
};

const DEFAULT_SETTINGS: Settings = {
  accent: '',
  effects: 'high',
  themeOverride: null,
  engineMode: 'auto',
  reduceMotion: false,
  engineModelId: null,
  cloud: CLOUD_DEFAULTS,
};

export const useZen = create<ZenStore>()(
  persist(
    (set, get) => ({
      chats: [],
      activeChatId: null,
      memory: [],
      settings: DEFAULT_SETTINGS,
      tokens: { balance: START_TOKENS, claimedAt: null },
      user: null,
      fbMode: 'none',
      fbError: null,
      engine: { status: 'idle', modelId: null, progress: 0, progressText: '', error: null },
      season: 'default',
      sidebarOpen: true,
      panel: null,
      generating: false,
      lastQuote: null,
      sandboxInput: null,

      init: () => {
        get().refreshSeason();
        if (!get().lastQuote) get().rerollQuote();
        const season = SEASONS[get().season];
        if (!get().settings.accent) {
          set((s) => ({ settings: { ...s.settings, accent: season.accent } }));
        }
        // Rehydrate engine state marker
        if (webllm.hasWebGPU()) {
          set((s) => ({
            engine: s.engine.status === 'idle' ? { ...s.engine, status: 'idle', progressText: 'WebGPU available' } : s.engine,
          }));
        } else {
          set((s) => ({ engine: { ...s.engine, status: 'no-webgpu', progressText: 'WebGPU not available on this browser' } }));
        }
      },

      setFbMode: (m, err) => set({ fbMode: m, fbError: err ?? null }),
      setUser: (u) => set({ user: u }),

      newChat: () => {
        const chat: Chat = {
          id: uid(),
          title: 'New chat',
          msgs: [],
          createdAt: Date.now(),
          updatedAt: Date.now(),
          mode: get().chats.length === 0 ? 'pro' : get().chats[0]?.mode || 'mini',
        };
        set((s) => ({ chats: [chat, ...s.chats], activeChatId: chat.id }));
        webllm.resetConversation();
      },

      openChat: (id) => {
        set({ activeChatId: id });
        webllm.resetConversation();
      },

      deleteChat: (id) => {
        set((s) => {
          const chats = s.chats.filter((c) => c.id !== id);
          const activeChatId = s.activeChatId === id ? chats[0]?.id ?? null : s.activeChatId;
          return { chats, activeChatId };
        });
      },

      renameChat: (id, title) =>
        set((s) => ({
          chats: s.chats.map((c) => (c.id === id ? { ...c, title } : c)),
        })),

      setChatMode: (id, mode) =>
        set((s) => ({
          chats: s.chats.map((c) => (c.id === id ? { ...c, mode } : c)),
        })),

      send: async (text, attachments) => {
        const state = get();
        const active = state.chats.find((c) => c.id === state.activeChatId);
        if (!active || state.generating) return;
        if (!text.trim() && !(attachments && attachments.length)) return;

        const mode = active.mode;

        // tokens
        if (!get().spendTokens(TOKEN_COSTS[mode])) {
          set({ panel: 'settings' });
          return;
        }

        stopFlag = false;
        set({ generating: true });

        const userMsg: Msg = {
          id: uid(),
          role: 'user',
          content: text,
          ts: Date.now(),
          attachments,
        };

        const aiId = uid();
        const aiMsg: Msg = { id: aiId, role: 'assistant', content: '', ts: Date.now(), mode };

        set((s) => ({
          chats: s.chats.map((c) =>
            c.id === active.id
              ? {
                  ...c,
                  title:
                    c.msgs.length === 0 && text
                      ? text.slice(0, 38).replace(/\n/g, ' ') || c.title
                      : c.title,
                  msgs: [...c.msgs, userMsg, aiMsg],
                  updatedAt: Date.now(),
                }
              : c
          ),
        }));

        const patchAI = (patch: Partial<Msg>) =>
          set((s) => ({
            chats: s.chats.map((c) =>
              c.id === active.id
                ? { ...c, msgs: c.msgs.map((m) => (m.id === aiId ? { ...m, ...patch } : m)) }
                : c
            ),
          }));

        try {
          // Memory capture: "remember that ..."
          const rem = text.match(/remember (that |this )?(.{3,240})/i);
          if (rem) {
            get().addMemory(rem[2].trim(), 'asked');
          }

          const useDevice =
            (get().settings.engineMode === 'device' && webllm.isReady()) ||
            (get().settings.engineMode === 'auto' && webllm.isReady());

          // ---- cloud brain: real LLM via the user's own API key (priority) ----
          const cloud = get().settings.cloud;
          const runCloud = async () => {
            const controller = new AbortController();
            cloudAbort = controller;
            const model = cloudLib.cloudModelFor(cloud, mode);
            const providerLabel = cloudLib.CLOUD_PROVIDERS[cloud.provider].label.split(' (')[0];
            patchAI({ meta: `Cloud brain: ${model} · ${providerLabel}`, thinking: '' });

            // live tools first (research / GitHub / deobfuscate) — Pro keeps its powers
            let toolContext = '';
            let sources: { title: string; url: string }[] = [];
            const gh = text.match(/github\.com\/([A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+)/);
            const wantsResearch = classify(text) === 'research' || looksLikeCurrentEvents(text);
            const wantsDeobf = /deobfuscat|unminif|beautif/i.test(text);

            const jobs: Promise<void>[] = [];
            if (gh) {
              jobs.push(
                readRepo(gh[1])
                  .then((r) => {
                    toolContext += `\nGitHub repo ${r.full_name} — ${r.description}\nLanguage: ${r.language} · stars: ${r.stars} · files: ${r.fileCount}\nTop files: ${r.topFiles.slice(0, 15).join(', ')}\n${r.readMe ? 'README:\n' + r.readMe.slice(0, 2200) : ''}`;
                  })
                  .catch(() => {})
              );
            }
            if (wantsResearch) {
              jobs.push(
                research(text)
                  .then((r) => {
                    if (r.sources.length) {
                      toolContext += `\nLive web research results:\n${r.answer.slice(0, 2800)}`;
                      sources = r.sources;
                    }
                  })
                  .catch(() => {})
              );
            }
            if (wantsDeobf) {
              const fence = text.match(/```(?:js|javascript)?\s*([\s\S]+?)```/);
              if (fence) {
                jobs.push(
                  deobfuscateJS(fence[1])
                    .then((r) => {
                      toolContext += `\nBeautified code:\n${r.beautified.slice(0, 2200)}\nSuspicious patterns: ${r.suspicious.join('; ') || 'none found'}`;
                    })
                    .catch(() => {})
                );
              }
            }
            if (jobs.length) {
              patchAI({ meta: `Cloud brain: ${model} · fetching live tools…`, thinking: '' });
              await Promise.race([
                Promise.all(jobs),
                new Promise((r) => setTimeout(r, 12000)),
              ]);
              if (sources.length) patchAI({ sources });
            }

            const imgs = (attachments || [])
              .map((a) => a.dataUrl)
              .filter((u): u is string => !!u)
              .slice(0, 3);
            const history = [...active.msgs, userMsg]
              .slice(-12)
              .map((m, idx, arr) => {
                const isLast = idx === arr.length - 1;
                const attText = isLast
                  ? (m.attachments || [])
                      .map((a) =>
                        a.text
                          ? `\n[attached ${a.name}]:\n${a.text.slice(0, 3500)}`
                          : `\n[attached file: ${a.name}]`
                      )
                      .join('')
                  : '';
                return {
                  role: m.role === 'user' ? ('user' as const) : ('assistant' as const),
                  content: (m.content || '') + attText,
                  images: isLast ? imgs : undefined,
                };
              })
              .filter((m) => m.content.trim() || (m.images && m.images.length));

            const memoryText = get()
              .memory.slice(-8)
              .map((m) => `- ${m.text}`)
              .join('\n');

            const system = cloudLib.buildCloudSystem({
              mode,
              memoryText,
              toolContext: toolContext.trim(),
              userName: get().user?.name?.split(' ')[0] || 'friend',
              provider: cloud.provider,
            });

            let acc = '';
            let thought = '';
            for await (const ev of cloudLib.streamCloud({
              provider: cloud.provider,
              apiKey: cloud.apiKey.trim(),
              model,
              baseUrl: cloud.baseUrl,
              system,
              messages: history,
              mode,
              signal: controller.signal,
            })) {
              if (stopFlag) {
                controller.abort();
                break;
              }
              if (ev.type === 'thought') {
                thought += ev.value;
                patchAI({ thinking: thought });
              } else {
                acc += ev.value;
                patchAI({ content: acc });
              }
            }

            const split = cloudLib.splitThinkingTags(acc);
            const content = (split.content || acc).trim();
            const thinking = (thought || split.thinking || '').trim();
            patchAI({
              content,
              thinking: thinking || undefined,
              meta: `Cloud brain: ${model}${jobs.length ? ' · live tools used' : ' · ' + providerLabel}`,
            });
            if (!content) throw new Error('Cloud model returned an empty answer');
          };

          let cloudDone = false;
          if (cloudLib.isCloudReady(cloud)) {
            try {
              await runCloud();
              cloudDone = true;
            } catch (err: any) {
              if (stopFlag) {
                cloudDone = true;
              } else {
                const msg = String(err?.message || err).slice(0, 160);
                patchAI({
                  meta: `Cloud brain failed — ${msg} Falling back to the built-in engine.`,
                });
              }
            }
          }

          if (!cloudDone && useDevice) {
            // ---- on-device LLM path ----
            patchAI({ meta: `On-device model: ${webllm.currentModelId() || 'local'}` });
            const history = [...active.msgs, userMsg]
              .slice(-8)
              .map((m) => ({
                role: m.role === 'user' ? ('user' as const) : ('assistant' as const),
                content:
                  (m.content || '') +
                  (m.attachments?.map((a) => `\n[attached file: ${a.name}]`).join('') || ''),
              }))
              .filter((m) => m.content.trim().length > 0);

            const memoryBlock = get().memory.length
              ? `\n\nThings you remember about the user:\n${get()
                  .memory.slice(-8)
                  .map((m) => `- ${m.text}`)
                  .join('\n')}`
              : '';

            const sys =
              webllm.MODE_SYSTEM_PROMPTS[mode] +
              `\nYou are Zen AI, running fully offline on the user's device. Be honest that your knowledge has a cutoff. Prefer concrete answers.${memoryBlock}`;

            let acc = '';
            try {
              for await (const chunk of webllm.generate(
                { system: sys, messages: history, onChunk: () => {} },
                mode
              )) {
                if (stopFlag) {
                  webllm.interrupt();
                  break;
                }
                acc += chunk;
                patchAI({ content: acc });
              }
            } catch (err: any) {
              patchAI({ content: acc + `\n\n*(engine hiccup: ${String(err?.message || err).slice(0, 120)})*` });
            }
            if (!acc) patchAI({ content: '*(empty response — try rephrasing)*' });
          } else if (!cloudDone) {
            // ---- built-in engine path ----
            if (get().settings.engineMode === 'device') {
              patchAI({
                meta: 'On-device model not downloaded yet — using built-in engine. Install it in Settings → AI Engine.',
              });
            }
            const exec = async (code: string, lang: 'js' | 'py'): Promise<ExecResult> => {
              get().spendTokens(5);
              const r = lang === 'py' ? await runPython(code) : await runJavaScript(code);
              return r;
            };
            const reply = await engineRespond(text, {
              mode,
              memory: get().memory,
              userName: get().user?.name?.split(' ')[0] || 'friend',
              history: active.msgs.slice(-6),
              onThinking: (t) => patchAI({ thinking: t }),
              onMeta: (m) => patchAI({ meta: m }),
              onSources: (s) => patchAI({ sources: s }),
              runCode: exec,
            });
            // typewriter reveal
            const full = reply.content;
            const step = Math.max(3, Math.round(full.length / 60));
            let i = 0;
            while (i < full.length) {
              if (stopFlag) {
                i = full.length;
                break;
              }
              i = Math.min(full.length, i + step);
              patchAI({ content: full.slice(0, i) });
              await new Promise((r) => setTimeout(r, 16));
            }
            const finalPatch: Partial<Msg> = { content: full };
            // don't clobber the streamed thinking trace / meta / sources
            if (reply.thinking) finalPatch.thinking = reply.thinking;
            if (reply.sources) finalPatch.sources = reply.sources;
            if (reply.meta) finalPatch.meta = reply.meta;
            patchAI(finalPatch);
          }
        } finally {
          cloudAbort = null;
          set((s) => ({
            generating: false,
            chats: s.chats.map((c) => (c.id === active.id ? { ...c, updatedAt: Date.now() } : c)),
          }));
          // cloud sync (fire and forget)
          if (get().fbMode === 'live' && get().user) {
            const u = get().user!;
            fb.syncChatsToCloud(u.uid, get().chats).catch(() => {});
          }
        }
      },

      stop: () => {
        stopFlag = true;
        webllm.interrupt();
        cloudAbort?.abort();
      },

      claimDaily: () => {
        const t = get().tokens;
        if (t.claimedAt === todayKey()) return false;
        set({ tokens: { balance: t.balance + DAILY_GRANT, claimedAt: todayKey() } });
        return true;
      },

      spendTokens: (n) => {
        const t = get().tokens;
        if (t.balance < n) return false;
        set({ tokens: { ...t, balance: t.balance - n } });
        if (get().fbMode === 'live' && get().user) {
          fb.saveRemoteTokens(get().user!.uid, t.balance - n).catch(() => {});
        }
        return true;
      },

      addTokens: (n) => {
        const t = get().tokens;
        set({ tokens: { ...t, balance: t.balance + n } });
      },

      setTokens: (n) => set({ tokens: { ...get().tokens, balance: Math.max(0, n) } }),

      addMemory: (text, tag) => {
        const item: MemoryItem = { id: uid(), text, ts: Date.now(), tag };
        set((s) => ({ memory: [...s.memory, item] }));
        if (get().fbMode === 'live' && get().user) {
          fb.syncMemoryToCloud(get().user!.uid, get().memory).catch(() => {});
        }
      },

      deleteMemory: (id) => set((s) => ({ memory: s.memory.filter((m) => m.id !== id) })),
      clearMemory: () => set({ memory: [] }),

      updateSettings: (patch) =>
        set((s) => ({ settings: { ...s.settings, ...patch } })),

      updateCloud: (patch) =>
        set((s) => ({
          settings: {
            ...s.settings,
            cloud: { ...(s.settings.cloud || CLOUD_DEFAULTS), ...patch },
          },
        })),

      setSidebar: (open) => set({ sidebarOpen: open }),
      setPanel: (p) => set({ panel: p }),
      setSandboxInput: (v) => set({ sandboxInput: v }),

      downloadModel: async (id) => {
        if (get().engine.status === 'downloading' || get().engine.status === 'loading') return;
        await webllm.loadModel(id, (patch) =>
          set((s) => ({ engine: { ...s.engine, ...patch } }))
        );
        if (get().engine.status === 'ready') {
          get().updateSettings({ engineModelId: id });
        }
      },

      deleteModel: async (id) => {
        await webllm.deleteModelCache(id);
        if (get().settings.engineModelId === id) {
          get().updateSettings({ engineModelId: null });
        }
        set((s) => ({
          engine: { ...s.engine, status: 'idle', modelId: null, progress: 0, progressText: 'Model deleted' },
        }));
      },

      refreshSeason: () => {
        const override = get().settings.themeOverride;
        const id = override || detectSeason().id;
        set({ season: id });
      },

      rerollQuote: () => set({ lastQuote: dailyQuote() }),

      signInDemo: () => {
        set({
          user: {
            uid: 'local-demo',
            email: 'you@local.device',
            name: 'Zen User',
            role: 'admin',
            status: 'active',
          },
          fbMode: 'none',
        });
        if (!get().lastQuote) get().rerollQuote();
      },

      logout: async () => {
        try {
          await fb.signOutUser();
        } catch {
          /* ignore */
        }
        set({ user: null });
      },
    }),
    {
      name: 'zen-ai-store',
      partialize: (s) => ({
        chats: s.chats,
        activeChatId: s.activeChatId,
        memory: s.memory,
        settings: s.settings,
        tokens: s.tokens,
        season: s.season,
      }),
      // older saved settings gain new fields (e.g. cloud) without data loss
      merge: (persisted, current) => {
        const p = (persisted || {}) as Partial<ZenStore>;
        const pSettings = (p.settings || {}) as Partial<Settings>;
        return {
          ...current,
          ...p,
          settings: {
            ...DEFAULT_SETTINGS,
            ...pSettings,
            cloud: { ...DEFAULT_SETTINGS.cloud, ...(pSettings.cloud || {}) },
          },
        } as ZenStore;
      },
    }
  )
);
