import type { SeasonInfo } from './types';

// Auto-season engine: the app looks at the real date on the device and picks
// the live theme. Users can override any season from Settings > Appearance.

export const SEASONS: Record<string, SeasonInfo> = {
  default: {
    id: 'default',
    label: 'Zen Calm',
    emoji: '🧘',
    particle: 'zen',
    bgFrom: '#0b0d14',
    bgTo: '#101625',
    glow: '#7c9cff',
    accent: '#8b5cf6',
    greetings: ['The mind is quiet. Ask anything.'],
  },
  valentine: {
    id: 'valentine',
    label: 'Valentine',
    emoji: '💗',
    particle: 'hearts',
    bgFrom: '#170a12',
    bgTo: '#1f0d18',
    glow: '#ff6b9d',
    accent: '#ff6b9d',
    greetings: ['Something warm is in the air.'],
  },
  halloween: {
    id: 'halloween',
    label: 'Halloween',
    emoji: '🎃',
    particle: 'bats',
    bgFrom: '#0d0a14',
    bgTo: '#150f1e',
    glow: '#ff8c42',
    accent: '#ff8c42',
    greetings: ['The veil is thin tonight...'],
  },
  thanksgiving: {
    id: 'thanksgiving',
    label: 'Thanksgiving',
    emoji: '🦃',
    particle: 'leaves',
    bgFrom: '#120c08',
    bgTo: '#1a120a',
    glow: '#ff9f43',
    accent: '#e8833a',
    greetings: [
      'Grateful you stopped by.',
      'Falling leaves, rising ideas.',
      'Warm thoughts, warm answers.',
    ],
  },
  christmas: {
    id: 'christmas',
    label: 'Christmas',
    emoji: '❄️',
    particle: 'snow',
    bgFrom: '#0a0d16',
    bgTo: '#0e1420',
    glow: '#9fd8ff',
    accent: '#63b3ed',
    greetings: ['Let it snow, let it think.'],
  },
  newyear: {
    id: 'newyear',
    label: 'New Year',
    emoji: '🎆',
    particle: 'fireworks',
    bgFrom: '#0b0a16',
    bgTo: '#120f22',
    glow: '#c084fc',
    accent: '#a78bfa',
    greetings: ['New year. Same curiosity. Bigger questions.'],
  },
  summer: {
    id: 'summer',
    label: 'Summer',
    emoji: '🌞',
    particle: 'sun',
    bgFrom: '#0f0d08',
    bgTo: '#171208',
    glow: '#ffd166',
    accent: '#ffb347',
    greetings: ['Bright days, bright answers.'],
  },
};

function thanksgivingDate(year: number): Date {
  // 4th Thursday of November
  const d = new Date(year, 10, 1);
  const day = d.getDay(); // 0 sun .. 4 thu
  const firstThursday = 1 + ((4 - day + 7) % 7);
  return new Date(year, 10, firstThursday + 21);
}

export function detectSeason(now: Date = new Date()): SeasonInfo {
  const m = now.getMonth(); // 0-11
  const day = now.getDate();
  const y = now.getFullYear();

  if (m === 11 && day >= 26) return SEASONS.newyear;
  if (m === 0 && day <= 7) return SEASONS.newyear;
  if (m === 11) return SEASONS.christmas;
  if (m === 10) return SEASONS.thanksgiving;
  if (m === 9) return SEASONS.halloween;
  if (m === 1 && day >= 7 && day <= 14) return SEASONS.valentine;
  if (m >= 5 && m <= 7) return SEASONS.summer;

  // exact-day extras
  const tg = thanksgivingDate(y);
  if (m === tg.getMonth() && day === tg.getDate()) {
    const s = { ...SEASONS.thanksgiving };
    s.greetings = ['Happy Thanksgiving. 🦃 Pass the questions, not just the turkey.'];
    return s;
  }
  if (m === 11 && day === 25) {
    const s = { ...SEASONS.christmas };
    s.greetings = ['Merry Christmas. 🎄 Even AI takes this moment to appreciate you.'];
    return s;
  }
  if (m === 0 && day === 1) {
    const s = { ...SEASONS.newyear };
    s.greetings = ['Happy New Year. 🎆 Chapter one, page one.'];
    return s;
  }
  return SEASONS.default;
}

export const ACCENTS: { name: string; value: string }[] = [
  { name: 'Zen Purple', value: '#8b5cf6' },
  { name: 'Ember', value: '#ff7a45' },
  { name: 'Mind Teal', value: '#2dd4bf' },
  { name: 'Sakura', value: '#ff6b9d' },
  { name: 'Signal Green', value: '#34d399' },
  { name: 'Solar', value: '#fbbf24' },
  { name: 'Crimson', value: '#f43f5e' },
  { name: 'Sky', value: '#38bdf8' },
];
