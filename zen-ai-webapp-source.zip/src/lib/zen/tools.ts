// Zen AI tools: keyless web research (Wikipedia), GitHub repo reader,
// and a JavaScript deobfuscator/beautifier for reading minified code.

export interface Source {
  title: string;
  url: string;
}

export interface ResearchResult {
  answer: string;
  sources: Source[];
}

// ---------------- Research ----------------

export async function research(query: string): Promise<ResearchResult> {
  const q = query.trim().slice(0, 240);
  const sources: Source[] = [];
  const parts: string[] = [];

  // 1) Wikipedia search + summary (CORS-enabled, no key)
  try {
    const searchUrl = `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(
      q
    )}&srlimit=3&format=json&origin=*`;
    const res = await fetch(searchUrl);
    if (res.ok) {
      const data = await res.json();
      const hits: any[] = data?.query?.search || [];
      for (const hit of hits.slice(0, 2)) {
        const title = hit.title as string;
        try {
          const sumRes = await fetch(
            `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(title)}`
          );
          if (sumRes.ok) {
            const sum = await sumRes.json();
            if (sum.extract) {
              parts.push(sum.extract as string);
              sources.push({ title, url: sum.content_urls?.desktop?.page || `https://en.wikipedia.org/wiki/${encodeURIComponent(title)}` });
            }
          }
        } catch {
          /* ignore individual failures */
        }
      }
    }
  } catch {
    /* offline / blocked */
  }

  // 2) DuckDuckGo Instant Answer API (keyless; works in many browsers)
  try {
    const res = await fetch(
      `https://api.duckduckgo.com/?q=${encodeURIComponent(q)}&format=json&no_html=1&skip_disambig=1`
    );
    if (res.ok) {
      const data = await res.json();
      if (data.AbstractText) {
        parts.unshift(`${data.AbstractText}`);
        if (data.AbstractURL)
          sources.unshift({ title: data.Heading || 'DuckDuckGo', url: data.AbstractURL });
      }
    }
  } catch {
    /* ignore */
  }

  if (parts.length === 0) {
    return {
      answer: `I couldn't reach live sources right now (offline or blocked network). Here's what I can offer from built-in knowledge: treat anything time-sensitive as approximate — my built-in knowledge has a cutoff, and I can't verify "latest" events without a live connection.`,
      sources: [],
    };
  }

  const answer =
    parts.join('\n\n') +
    '\n\n(Summary of what live sources say right now. My on-device model adds reasoning on top of this.)';
  return { answer, sources };
}

export function looksLikeCurrentEvents(text: string): boolean {
  const t = text.toLowerCase();
  return (
    /\b(who is the (current|next)|latest|recent|today|this (week|month|year)|news|election|president|price of|score|weather|stock|release date|winner)\b/.test(
      t
    ) ||
    /\b20(2[5-9]|3\d)\b/.test(t)
  );
}

// ---------------- GitHub ----------------

export interface RepoInfo {
  name: string;
  full_name: string;
  description: string;
  language: string;
  stars: number;
  default_branch: string;
  fileCount: number;
  topFiles: string[];
  readMe?: string;
}

export async function readRepo(slug: string): Promise<RepoInfo> {
  const clean = slug.replace(/^https?:\/\/github\.com\//i, '').replace(/\.git$/, '').trim();
  const [owner, repo] = clean.split('/');
  if (!owner || !repo) throw new Error('Use: owner/repo');

  const metaRes = await fetch(`https://api.github.com/repos/${owner}/${repo}`);
  if (!metaRes.ok) throw new Error(`GitHub says ${metaRes.status} — check owner/repo`);
  const meta = await metaRes.json();

  let fileCount = 0;
  let topFiles: string[] = [];
  try {
    const treeRes = await fetch(
      `https://api.github.com/repos/${owner}/${repo}/git/trees/${encodeURIComponent(
        meta.default_branch
      )}?recursive=1`
    );
    if (treeRes.ok) {
      const tree = await treeRes.json();
      const files: string[] = (tree.tree || [])
        .filter((n: any) => n.type === 'blob')
        .map((n: any) => n.path as string);
      fileCount = files.length;
      topFiles = files.slice(0, 25);
    }
  } catch {
    /* ignore */
  }

  let readMe: string | undefined;
  try {
    const rmRes = await fetch(
      `https://raw.githubusercontent.com/${owner}/${repo}/${encodeURIComponent(
        meta.default_branch
      )}/README.md`
    );
    if (rmRes.ok) readMe = (await rmRes.text()).slice(0, 4000);
  } catch {
    /* ignore */
  }

  return {
    name: meta.name,
    full_name: meta.full_name,
    description: meta.description || '(no description)',
    language: meta.language || 'unknown',
    stars: meta.stargazers_count || 0,
    default_branch: meta.default_branch,
    fileCount,
    topFiles,
    readMe,
  };
}

export async function readRepoFile(slug: string, path: string): Promise<string> {
  const clean = slug.replace(/^https?:\/\/github\.com\//i, '').replace(/\.git$/, '').trim();
  const [owner, repo] = clean.split('/');
  const branch = 'HEAD';
  const res = await fetch(
    `https://raw.githubusercontent.com/${owner}/${repo}/${branch}/${path.replace(/^\/+/, '')}`
  );
  if (!res.ok) throw new Error(`Could not fetch ${path} (${res.status})`);
  return res.text();
}

// ---------------- Deobfuscator ----------------

export interface DeobfReport {
  beautified: string;
  stats: { lines: number; chars: number; longestLine: number; strings: number };
  suspicious: string[];
}

export async function deobfuscateJS(code: string): Promise<DeobfReport> {
  let beautified = code;
  try {
    const mod = await import('js-beautify/js/lib/beautify');
    beautified = (mod as any).js(code, { indent_size: 2, space_in_empty_paren: false });
  } catch {
    // fallback: naive newline insertion after ; and { }
    beautified = code.replace(/;/g, ';\n').replace(/\{/g, '{\n').replace(/\}/g, '\n}\n');
  }

  const lines = beautified.split('\n');
  const suspicious: string[] = [];
  const checks: [RegExp, string][] = [
    [/\beval\s*\(/, 'eval() — dynamic code execution'],
    [/document\.write\s*\(/, 'document.write — DOM injection'],
    [/atob\s*\(|btoa\s*\(/, 'base64 encode/decode — possibly hidden payloads'],
    [/\\x[0-9a-f]{2}/i, 'hex-escaped strings — common obfuscation'],
    [/String\.fromCharCode/, 'charcode string building'],
    [/debugger/, 'debugger statement — anti-inspection trick'],
    [/fetch\s*\(\s*['"`]http/, 'remote fetch — calls home somewhere'],
    [/WebSocket\s*\(/, 'WebSocket connection'],
    [/localStorage|sessionStorage/, 'storage access'],
    [/Function\s*\(\s*['"`]/, 'Function() constructor — dynamic code'],
  ];
  for (const [re, label] of checks) if (re.test(beautified)) suspicious.push(label);

  return {
    beautified,
    stats: {
      lines: lines.length,
      chars: code.length,
      longestLine: Math.max(...lines.map((l) => l.length)),
      strings: (code.match(/['"`]/g) || []).length,
    },
    suspicious,
  };
}
