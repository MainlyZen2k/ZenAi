export type ModelMode = 'mini' | 'think' | 'pro';

export interface Attachment {
  name: string;
  type: string;
  size: number;
  dataUrl?: string;
  text?: string;
}

export interface Msg {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  ts: number;
  mode?: ModelMode;
  tokens?: number;
  attachments?: Attachment[];
  thinking?: string;
  meta?: string;
  sources?: { title: string; url: string }[];
}

export interface Chat {
  id: string;
  title: string;
  msgs: Msg[];
  createdAt: number;
  updatedAt: number;
  mode: ModelMode;
}

export interface MemoryItem {
  id: string;
  text: string;
  ts: number;
  tag?: string;
}

export interface FBConfig {
  apiKey: string;
  authDomain: string;
  projectId: string;
  storageBucket: string;
  messagingSenderId: string;
  appId: string;
}

export type FBMode = 'none' | 'live' | 'connecting' | 'error';

export interface ZenUser {
  uid: string;
  email: string;
  name: string;
  role: 'user' | 'admin';
  status: 'active' | 'banned';
  banReason?: string;
  photoUrl?: string;
}

export interface TokenState {
  balance: number;
  claimedAt: string | null; // YYYY-MM-DD of last daily claim
}

export type CloudProvider = 'gemini' | 'openrouter' | 'custom';

export interface CloudSettings {
  enabled: boolean;
  provider: CloudProvider;
  apiKey: string;
  modelMini: string;
  modelThink: string;
  modelPro: string;
  baseUrl: string; // only used by the 'custom' provider
}

export interface Settings {
  accent: string;
  effects: 'off' | 'low' | 'high';
  themeOverride: string | null;
  engineMode: 'auto' | 'builtin' | 'device';
  reduceMotion: boolean;
  engineModelId: string | null;
  cloud: CloudSettings;
}

export type EngineStatus =
  | 'idle'
  | 'no-webgpu'
  | 'downloading'
  | 'loading'
  | 'ready'
  | 'generating'
  | 'error';

export interface EngineState {
  status: EngineStatus;
  modelId: string | null;
  progress: number; // 0..1
  progressText: string;
  error: string | null;
}

export interface AdminUserRow {
  uid: string;
  email: string;
  name: string;
  role: string;
  status: string;
  banReason?: string;
  tokens?: number;
  createdAt?: number;
}

export interface SeasonInfo {
  id: string;
  label: string;
  emoji: string;
  particle:
    | 'leaves'
    | 'snow'
    | 'fireworks'
    | 'hearts'
    | 'bats'
    | 'sun'
    | 'zen';
  bgFrom: string;
  bgTo: string;
  glow: string;
  accent: string;
  greetings: string[];
}
