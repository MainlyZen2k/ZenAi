// On-device LLM engine (WebLLM + WebGPU). The model downloads once onto the
// device and then runs 100% locally — no API keys, no server.

import type { EngineState } from './types';

type WebLLMModule = any;

let mod: WebLLMModule | null = null;
let engine: any = null;
let loadingModelId: string | null = null;

// Small, phone-friendly models from WebLLM's prebuilt list.
export const MODEL_CATALOG = [
  {
    id: 'Qwen2.5-0.5B-Instruct-q4f16_1-MLC',
    label: 'Qwen 0.5B',
    size: '~500 MB',
    note: 'Fastest, runs on almost anything',
  },
  {
    id: 'Llama-3.2-1B-Instruct-q4f16_1-MLC',
    label: 'Llama 3.2 1B',
    size: '~900 MB',
    note: 'Good balance of speed and quality',
  },
  {
    id: 'Qwen2.5-1.5B-Instruct-q4f16_1-MLC',
    label: 'Qwen 1.5B',
    size: '~1.4 GB',
    note: 'Smartest of the three, slower',
  },
];

export function hasWebGPU(): boolean {
  return typeof navigator !== 'undefined' && 'gpu' in navigator;
}

async function ensureModule(): Promise<WebLLMModule> {
  if (mod) return mod;
  mod = await import('@mlc-ai/web-llm');
  return mod;
}

export async function listAvailableModels(): Promise<string[]> {
  const m = await ensureModule();
  const all: string[] = (m.prebuiltAppConfig?.model_list || []).map(
    (r: any) => r.model_id as string
  );
  return MODEL_CATALOG.filter((c) => all.includes(c.id)).map((c) => c.id);
}

export async function loadModel(
  modelId: string,
  onState: (s: Partial<EngineState>) => void
): Promise<void> {
  const m = await ensureModule();
  loadingModelId = modelId;
  onState({ status: 'downloading', modelId, progress: 0, error: null });

  try {
    engine = await m.CreateMLCEngine(modelId, {
      initProgressCallback: (report: any) => {
        const text: string = report.text || '';
        let progress = report.progress || 0;
        // Distinguish download vs compile/shard-load phases
        const isFetching = /fetch|download|cache/i.test(text);
        onState({
          status: isFetching ? 'downloading' : 'loading',
          modelId,
          progress,
          progressText: text.replace(/\[.*?\]/g, '').trim().slice(0, 90),
        });
        if (progress >= 1 && !isFetching) onState({ status: 'loading' });
      },
    });
    if (loadingModelId !== modelId) {
      // user switched while loading
      return;
    }
    onState({ status: 'ready', modelId, progress: 1, progressText: 'Model ready (on-device)' });
  } catch (err: any) {
    onState({
      status: 'error',
      error: String(err?.message || err).slice(0, 300),
      modelId: null,
    });
    engine = null;
  } finally {
    loadingModelId = null;
  }
}

export function isReady(): boolean {
  return engine !== null;
}

export function currentModelId(): string | null {
  return engine?._loadedModelId ?? engine?.modelId ?? null;
}

export function interrupt(): void {
  try {
    engine?.interruptGenerate?.();
  } catch {
    /* noop */
  }
}

export function resetConversation(): void {
  try {
    engine?.resetChat?.();
  } catch {
    /* noop */
  }
}

export interface GenerateOpts {
  system: string;
  messages: { role: 'user' | 'assistant'; content: string }[];
  temperature?: number;
  maxTokens?: number;
  onChunk: (text: string) => void;
}

const MODE_PARAMS: Record<string, { temperature: number; maxTokens: number }> = {
  mini: { temperature: 0.5, maxTokens: 300 },
  think: { temperature: 0.7, maxTokens: 700 },
  pro: { temperature: 0.7, maxTokens: 900 },
};

export async function* generate(
  opts: GenerateOpts,
  mode: string
): AsyncGenerator<string> {
  if (!engine) throw new Error('Engine not loaded');
  const params = MODE_PARAMS[mode] || MODE_PARAMS.mini;
  const chunks = await engine.chat.completions.create({
    messages: [{ role: 'system', content: opts.system }, ...opts.messages],
    stream: true,
    temperature: opts.temperature ?? params.temperature,
    max_tokens: opts.maxTokens ?? params.maxTokens,
  });
  for await (const chunk of chunks) {
    const delta = chunk?.choices?.[0]?.delta?.content || '';
    if (delta) yield delta;
  }
}

export async function deleteModelCache(modelId: string): Promise<void> {
  // WebLLM caches models in IndexedDB + Cache Storage; drop both.
  try {
    const m = await ensureModule();
    if (typeof m.deleteModelAllInfoInCache === 'function') {
      await m.deleteModelAllInfoInCache(modelId);
      return;
    }
  } catch {
    /* fall through to manual cleanup */
  }
  try {
    const dbs = await indexedDB.databases?.();
    for (const db of dbs || []) {
      if (db.name && /webllm|mlc/i.test(db.name)) indexedDB.deleteDatabase(db.name);
    }
  } catch {
    /* ignore */
  }
}

export const MODE_SYSTEM_PROMPTS: Record<string, string> = {
  mini:
    'You are Zen-Mini, a fast, concise AI. Answer in 1-3 short sentences. No preamble, no lists unless asked. Friendly, a little warm, zero fluff.',
  think:
    'You are Zen-Think, a thoughtful AI. Before the final answer, briefly reason inside <thinking>...</thinking> tags (2-5 short lines), then give a clear structured answer. Be honest about uncertainty.',
  pro:
    'You are Zen-Pro, a professional AI engineer and analyst. Produce thorough, well-structured answers. When writing code, make it complete and runnable. State assumptions explicitly. Prefer precision over verbosity.',
};
